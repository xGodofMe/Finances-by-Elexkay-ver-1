import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Define bill status types here for use in the schema
export type BillStatus = "paid" | "upcoming" | "active" | "hidden" | "skip" | "due" | "auto";

export const bills = pgTable("bills", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  amount: text("amount").notNull(),
  dueDay: text("dueDay").notNull(),
  method: text("method").notNull(),
  hidden: boolean("hidden").default(false),
  autoDraft: boolean("autoDraft").default(false),
  status: text("status"),
  isAnnual: boolean("isAnnual").default(false),
  annualMonth: text("annualMonth"), // Store month number as string (1-12)
  annualYear: text("annualYear"),   // Store year as string (e.g., "2025")
  // Website URL
  website: text("website"),
  // Credentials fields
  username: text("username"),
  email: text("email"),
  password: text("password"),
  // Additional payment field
  additionalPayment: text("additionalPayment").default("0"),
  userId: integer("userId").notNull()
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  paymentStrategy: text("paymentStrategy").notNull().default("Proactive"), // Actual column is camelCase
  payFrequency: text("payFrequency").notNull().default("Bi-Weekly"), // Actual column is camelCase
  lastPayDate: text("lastPayDate").notNull(), // Actual column is camelCase
  billingCushion: text("billingCushion").notNull().default("2"), // Actual column is camelCase
  resetDate: integer("resetdate").default(1), // Day of month (1-28) - this one is lowercase, confirmed
  autoResetEnabled: boolean("autoresetenabled").default(true), // Actual column is autoresetenabled (all lowercase)
  userId: integer("userId").notNull() // Actual column is camelCase
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("isAdmin").default(false), // IMPORTANT: Using camelCase to match actual database column
  isDemoAccount: boolean("is_demo_account").default(false), // Flag to identify demo accounts
  // Profile information - Note: using snake_case for column names to match database
  firstName: text("first_name"),
  lastName: text("last_name"),
  phoneticLastName: text("phonetic_last_name"), // Phonetic breakdown of the last name for correct pronunciation
  email: text("email"),
  title: text("title"), // Custom title (Mr., Mrs., Dr., etc.)
  // Auto-logout settings
  autoLogout: boolean("auto_logout").default(true),
  inactivityTimeout: integer("inactivity_timeout").default(15), // In minutes
  lastActive: timestamp("last_active"),
});

// Stock tracking
export const stocks = pgTable("stocks", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  symbol: text("symbol").notNull(),
  companyName: text("companyName"),
  price: text("price"),
  change: text("change"),
  changePercent: text("changePercent"),
  lastUpdated: timestamp("lastUpdated").defaultNow(),
  hidden: boolean("hidden").default(false),
  isWatching: boolean("isWatching").default(true),
});

// News tracking
export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  title: text("title").notNull(),
  source: text("source").notNull(),
  url: text("url").notNull(),
  publishedAt: timestamp("publishedAt").defaultNow(),
  hidden: boolean("hidden").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
  isDemoAccount: true,
});

export const insertBillSchema = createInsertSchema(bills).omit({
  id: true,
  userId: true,
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
  userId: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertBill = z.infer<typeof insertBillSchema>;
export type Bill = typeof bills.$inferSelect;

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;

// Create the insert schema for stocks
export const insertStockSchema = createInsertSchema(stocks).omit({
  id: true,
  userId: true,
  lastUpdated: true,
});

export type InsertStock = z.infer<typeof insertStockSchema>;
export type Stock = typeof stocks.$inferSelect;

// Create the insert schema for news
export const insertNewsSchema = createInsertSchema(news).omit({
  id: true,
  userId: true,
  publishedAt: true,
});

export type InsertNews = z.infer<typeof insertNewsSchema>;
export type News = typeof news.$inferSelect;

// Suggestions table for user feedback
export const suggestions = pgTable("suggestions", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull().default("feature"), // "feature", "bug", "improvement"
  status: text("status").notNull().default("new"), // "new", "reviewing", "implemented", "rejected"
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt"),
  resolved: boolean("resolved").default(false),
  adminResponse: text("adminResponse"),
});

export const insertSuggestionSchema = createInsertSchema(suggestions).omit({
  id: true,
  userId: true,
  createdAt: true,
  updatedAt: true,
  status: true,
  adminResponse: true,
});

export type InsertSuggestion = z.infer<typeof insertSuggestionSchema>;
export type Suggestion = typeof suggestions.$inferSelect;
