import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Set up a global link handler to fix Android compatibility issues
document.addEventListener('click', (e) => {
  // Find if the click target is or contains an anchor
  const target = e.target as HTMLElement;
  const anchor = target.tagName === 'A' ? target : target.closest('a');
  
  if (anchor && (anchor as HTMLAnchorElement).href && (anchor as HTMLAnchorElement).target === '_blank') {
    e.preventDefault();
    
    // Add https protocol if not present
    let url = (anchor as HTMLAnchorElement).href;
    if (!/^https?:\/\//i.test(url)) {
      url = 'https://' + url;
    }
    
    // Open with window.open for better compatibility on mobile devices
    window.open(url, '_blank', 'noopener,noreferrer');
  }
}, false);

createRoot(document.getElementById("root")!).render(<App />);
