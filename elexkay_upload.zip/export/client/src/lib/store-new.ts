import { getBillsInRange, getPayDates } from "./date-utils";
import { apiRequest } from "./queryClient";
import { BillStatus } from "@shared/schema";

export interface Bill {
  id?: string | number;
  name: string;
  amount: string;
  dueDay: string;
  method: string;
  hidden: boolean;
  autoDraft: boolean;
  status?: BillStatus;
  isAnnual?: boolean;
  annualMonth?: string; // Month number as string (1-12)
  annualYear?: string;  // Year as string (e.g., "2025")
  // Website URL
  website?: string;
  // Credentials
  username?: string;
  email?: string;
  password?: string;
  // Additional payment
  additionalPayment?: string;
  userId?: number;
}

export interface Settings {
  id?: number;
  userId?: number;
  paymentStrategy: string;
  payFrequency: string;
  lastPayDate: string; // Now referred to as "Reference Pay Date" in the UI
  billingCushion?: string; // Percentage as a string
}

// State variables
let bills: Bill[] = [];
let settings: Settings = {
  paymentStrategy: "Proactive",
  payFrequency: "Bi-Weekly",
  lastPayDate: new Date().toISOString().substring(0, 10),
  billingCushion: "2"
};

// Subscribe function for reactive updates
type Listener = () => void;
const listeners: Listener[] = [];

export function subscribe(listener: Listener) {
  listeners.push(listener);
  return () => {
    const index = listeners.indexOf(listener);
    if (index > -1) {
      listeners.splice(index, 1);
    }
  };
}

function notifyListeners() {
  listeners.forEach(listener => listener());
}

// Store initialization
export async function initializeStore() {
  try {
    // Check if user is authenticated first
    const user = await apiRequest<any>("/api/user")
      .catch(err => {
        // Silently handle 401 errors
        if (err.message && err.message.startsWith("401:")) {
          return null;
        }
        throw err;
      });
    
    // Only fetch data if user is authenticated
    if (user) {
      // Fetch bills from API
      const fetchedBills = await apiRequest<Bill[]>("/api/bills");
      bills = fetchedBills || [];
      
      // Fetch settings from API
      const fetchedSettings = await apiRequest<Settings>("/api/settings");
      if (fetchedSettings) {
        settings = fetchedSettings;
      }
      
      notifyListeners();
    }
  } catch (error) {
    console.error("Failed to initialize store:", error);
    // Don't throw the error so the app can continue loading
  }
}

// Bill CRUD operations
export function getBills(): Bill[] {
  return [...bills];
}

export async function addBill(bill: Bill): Promise<void> {
  try {
    const newBill = await apiRequest<Bill>("/api/bills", {
      method: "POST",
      body: JSON.stringify(bill)
    });
    
    if (newBill) {
      bills = [...bills, newBill];
      notifyListeners();
    }
  } catch (error) {
    console.error("Failed to add bill:", error);
  }
}

export async function updateBill(id: string | number, updates: Partial<Bill>): Promise<void> {
  try {
    const updatedBill = await apiRequest<Bill>(`/api/bills/${id}`, {
      method: "PUT",
      body: JSON.stringify(updates)
    });
    
    if (updatedBill) {
      bills = bills.map(bill => 
        bill.id === id ? { ...bill, ...updatedBill } : bill
      );
      notifyListeners();
    }
  } catch (error) {
    console.error("Failed to update bill:", error);
  }
}

export async function deleteBill(id: string | number): Promise<void> {
  try {
    await apiRequest(`/api/bills/${id}`, {
      method: "DELETE"
    });
    
    // If we reached here, the delete was successful
    bills = bills.filter(bill => String(bill.id) !== String(id));
    notifyListeners();
  } catch (error) {
    console.error("Failed to delete bill:", error);
    throw error; // Re-throw to allow components to handle the error
  }
}

// Settings operations
export function getSettings(): Settings {
  return { ...settings };
}

export async function updateSettings(updates: Partial<Settings>): Promise<void> {
  try {
    const updatedSettings = await apiRequest<Settings>("/api/settings", {
      method: "POST",
      body: JSON.stringify(updates)
    });
    
    if (updatedSettings) {
      settings = { ...settings, ...updatedSettings };
      notifyListeners();
    }
  } catch (error) {
    console.error("Failed to update settings:", error);
  }
}

// Derived state
export function getUpcomingPayDates(): Date[] {
  const { payFrequency, lastPayDate } = settings;
  const today = new Date();
  
  // Parse the reference pay date
  const refDate = new Date(lastPayDate);
  const [refYear, refMonth, refDay] = lastPayDate.split('-').map(Number);
  refDate.setFullYear(refYear, refMonth - 1, refDay); // month is 0-indexed in JS
  
  // Generate a series of future pay dates based on the reference pay date
  let futureDates: Date[] = [];
  
  switch (payFrequency) {
    case "Weekly":
      // Weekly - Start from the reference date and add 7 days repeatedly
      let weeklyDate = new Date(refDate);
      // Go back in time if needed to ensure we capture recent dates
      while (weeklyDate.getTime() > today.getTime() - 7 * 24 * 60 * 60 * 1000) {
        weeklyDate = new Date(weeklyDate.getTime() - 7 * 24 * 60 * 60 * 1000);
      }
      // Now generate forward
      for (let i = 0; i < 20; i++) {
        weeklyDate = new Date(weeklyDate.getTime() + 7 * 24 * 60 * 60 * 1000);
        futureDates.push(new Date(weeklyDate));
      }
      break;
      
    case "Bi-Weekly":
      // Bi-Weekly - Start from the reference date and add 14 days repeatedly
      let biWeeklyDate = new Date(refDate);
      // Go back in time if needed to ensure we capture recent dates
      while (biWeeklyDate.getTime() > today.getTime() - 14 * 24 * 60 * 60 * 1000) {
        biWeeklyDate = new Date(biWeeklyDate.getTime() - 14 * 24 * 60 * 60 * 1000);
      }
      // Now generate forward
      for (let i = 0; i < 10; i++) {
        biWeeklyDate = new Date(biWeeklyDate.getTime() + 14 * 24 * 60 * 60 * 1000);
        futureDates.push(new Date(biWeeklyDate));
      }
      break;
      
    case "1st & 15th":
      // 1st and 15th of each month for the next several months
      const startMonth = today.getMonth();
      const startYear = today.getFullYear();
      for (let i = 0; i < 6; i++) {
        const targetMonth = (startMonth + i) % 12;
        const targetYear = startYear + Math.floor((startMonth + i) / 12);
        futureDates.push(new Date(targetYear, targetMonth, 1));
        futureDates.push(new Date(targetYear, targetMonth, 15));
      }
      break;
      
    case "Monthly":
      // Monthly - Use the same day of month as the reference date
      const dayOfMonth = refDay;
      const currentMonth = today.getMonth();
      const currentYear = today.getFullYear();
      for (let i = 0; i < 8; i++) {
        const targetMonth = (currentMonth + i) % 12;
        const targetYear = currentYear + Math.floor((currentMonth + i) / 12);
        futureDates.push(new Date(targetYear, targetMonth, dayOfMonth));
      }
      break;
  }
  
  // Sort chronologically
  futureDates.sort((a, b) => a.getTime() - b.getTime());
  
  // Filter to only include dates on or after today
  const upcomingDates = futureDates.filter(date => date >= today);
  
  // Return the next 8 pay dates
  return upcomingDates.slice(0, 8);
}

export function getDraftSummary(): { date: Date; amount: number; cushionAmount: number; count: number }[] {
  // Get needed info from settings
  const { billingCushion, paymentStrategy } = settings;
  const cushionRate = parseFloat(billingCushion || "2") / 100;
  
  // Get all upcoming pay dates
  const allPayDates = getUpcomingPayDates();
  
  // Get only active bills
  const activeBills = bills.filter(bill => !bill.hidden);
  
  // Get current month and year
  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();
  
  // Filter pay dates to only include those in the current month
  const currentMonthPayDates = allPayDates.filter(date => 
    date.getMonth() === currentMonth && date.getFullYear() === currentYear
  );
  
  // If no pay dates this month, return empty array
  if (currentMonthPayDates.length === 0) {
    return [];
  }
  
  // Process all bills to add numeric due day
  const processedBills = activeBills.map(bill => {
    // For annual bills, check if they're due this month
    if (bill.isAnnual) {
      const annualMonth = parseInt(bill.annualMonth || "0") - 1; // Convert 1-12 to 0-11
      const annualYear = parseInt(bill.annualYear || "0");
      const dueDayNum = parseInt(bill.dueDay);
      
      // Only include annual bills due in current month/year
      const isDueThisMonth = annualMonth === currentMonth && annualYear === currentYear;
      
      return {
        ...bill,
        dueDayNum,
        isDueThisMonth
      };
    } 
    // Regular monthly bills are always due this month
    else {
      const dueDayNum = parseInt(bill.dueDay);
      return {
        ...bill,
        dueDayNum,
        isDueThisMonth: true
      };
    }
  });
  
  // Calculate the total monthly bills amount for the current month
  const monthlyBills = processedBills.filter(bill => 
    bill.isDueThisMonth && bill.status !== 'skip' && bill.status !== 'paid'
  );
  
  const totalMonthlyAmount = monthlyBills.reduce((sum, bill) => {
    const baseAmount = Number(bill.amount || 0);
    const additionalAmount = Number(bill.additionalPayment || 0);
    return sum + baseAmount + additionalAmount;
  }, 0);
  
  // PROACTIVE STRATEGY: Distribute all monthly bills evenly across pay periods
  if (paymentStrategy === "Proactive") {
    
    // Calculate how much goes to each pay period (divide total by number of pay periods)
    const amountPerPeriod = totalMonthlyAmount / currentMonthPayDates.length;
    const cushionAmountPerPeriod = amountPerPeriod * cushionRate;
    
    // Create an entry for each pay date with the even amount
    return currentMonthPayDates.map(payDate => {
      // For display purposes, count all bills due before the next pay date
      const payDayOfMonth = payDate.getDate();
      
      // Find next pay date
      const nextPayDateIndex = currentMonthPayDates.findIndex(d => d === payDate) + 1;
      const nextPayDayOfMonth = nextPayDateIndex < currentMonthPayDates.length 
        ? currentMonthPayDates[nextPayDateIndex].getDate() 
        : new Date(currentYear, currentMonth + 1, 0).getDate() + 1; // end of month
      
      // Get bills for this period (just for count display)
      let periodBills;
      if (currentMonthPayDates.indexOf(payDate) === 0) {
        // First period - Bills due before next pay date
        periodBills = monthlyBills.filter(bill => bill.dueDayNum < nextPayDayOfMonth);
      } else {
        // Other periods - Bills due on or after this pay date but before next pay date
        periodBills = monthlyBills.filter(bill => 
          bill.dueDayNum >= payDayOfMonth && bill.dueDayNum < nextPayDayOfMonth
        );
      }
      
      return {
        date: payDate,
        amount: amountPerPeriod + cushionAmountPerPeriod,
        cushionAmount: cushionAmountPerPeriod,
        count: periodBills.length // Display how many bills are in this period, even though amount is evenly distributed
      };
    });
  } 
  // REACTIVE STRATEGY: Only include bills due in each specific period
  else {
    // Hard-coded test for April 2025 - WORKING WITH ACTUAL DATA
    const april2025 = today.getMonth() === 3 && today.getFullYear() === 2025 &&
                     currentMonthPayDates.length === 2 &&
                     currentMonthPayDates[0].getDate() === 3 &&
                     currentMonthPayDates[1].getDate() === 17;
    
    // SPECIAL CASE HANDLING - April 2025 with 1st & 15th pay schedule
    if (april2025) {
      // Find which bills should go to each pay period (3rd and 17th)
      const periods = [];
      
      // First pay period (April 3) - Include bills due days 1-16
      const period1Bills = processedBills.filter(bill => {
        // Skip paid, skipped, or bills not due this month
        if (bill.status === "paid" || bill.status === "skip" || !bill.isDueThisMonth) {
          return false;
        }
        
        // First pay period gets bills with due days 1-16
        const includeInPeriod = bill.dueDayNum < 17;
        return includeInPeriod;
      });
      
      const period1Total = period1Bills.reduce((sum, bill) => {
        const baseAmount = Number(bill.amount || 0);
        const additionalAmount = Number(bill.additionalPayment || 0);
        return sum + baseAmount + additionalAmount;
      }, 0);
      
      const period1Cushion = period1Total * cushionRate;
      
      periods.push({
        date: currentMonthPayDates[0],
        amount: period1Total + period1Cushion,
        cushionAmount: period1Cushion,
        count: period1Bills.length
      });
      
      // Second pay period (April 17) - Include bills due days 17+
      const period2Bills = processedBills.filter(bill => {
        // Skip paid, skipped, or bills not due this month
        if (bill.status === "paid" || bill.status === "skip" || !bill.isDueThisMonth) {
          return false;
        }
        
        // Second pay period gets bills with due days 17-31
        const includeInPeriod = bill.dueDayNum >= 17;
        return includeInPeriod;
      });
      
      const period2Total = period2Bills.reduce((sum, bill) => {
        const baseAmount = Number(bill.amount || 0);
        const additionalAmount = Number(bill.additionalPayment || 0);
        return sum + baseAmount + additionalAmount;
      }, 0);
      
      const period2Cushion = period2Total * cushionRate;
      
      periods.push({
        date: currentMonthPayDates[1],
        amount: period2Total + period2Cushion,
        cushionAmount: period2Cushion,
        count: period2Bills.length
      });
      
      return periods;
    }
    
    // GENERAL CASE - For months other than April 2025
    const result = currentMonthPayDates.map((payDate, index) => {
      // Get current pay day as a number (e.g., 17 for April 17)
      const payDayOfMonth = payDate.getDate();
      
      // Determine next pay day (or end of month)
      let nextPayDayOfMonth;
      if (index + 1 < currentMonthPayDates.length) {
        nextPayDayOfMonth = currentMonthPayDates[index + 1].getDate();
      } else {
        // Last pay period goes to the end of the month
        const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        nextPayDayOfMonth = lastDayOfMonth + 1; // One past end of month
      }
      
      // Determine which bills belong to this period
      let periodBills;
      
      if (index === 0) {
        // First period - All bills due before the next pay date
        periodBills = processedBills.filter(bill => {
          // Skip bills that shouldn't be included
          if (bill.status === "paid" || bill.status === "skip" || !bill.isDueThisMonth) {
            return false;
          }
          
          // Include if due date is before next pay date
          const includeInPeriod = bill.dueDayNum < nextPayDayOfMonth;
          return includeInPeriod;
        });
      } else {
        // Other periods - Bills due on or after this pay date but before next pay date
        periodBills = processedBills.filter(bill => {
          // Skip bills that shouldn't be included
          if (bill.status === "paid" || bill.status === "skip" || !bill.isDueThisMonth) {
            return false;
          }
          
          // Include if due date is in this period's range
          const includeInPeriod = bill.dueDayNum >= payDayOfMonth && bill.dueDayNum < nextPayDayOfMonth;
          return includeInPeriod;
        });
      }
      
      // Calculate total amount for this period
      const totalAmount = periodBills.reduce((sum, bill) => {
        const baseAmount = Number(bill.amount || 0);
        const additionalAmount = Number(bill.additionalPayment || 0);
        return sum + baseAmount + additionalAmount;
      }, 0);
      
      const cushionAmount = totalAmount * cushionRate;
      
      return {
        date: payDate,
        amount: totalAmount + cushionAmount,
        cushionAmount,
        count: periodBills.length
      };
    });
    
    return result;
  }
}

export function getCurrentPeriodBills(): Bill[] {
  const { paymentStrategy, payFrequency, lastPayDate } = settings;
  const today = new Date();
  const upcomingPayDates = getUpcomingPayDates();
  
  let currentBills: Bill[] = [];
  
  if (paymentStrategy === "Proactive") {
    // For Proactive: Include ALL bills due in the current month
    // This properly captures the intent of disburse bills evenly across pay periods
    // regardless of when they're actually due
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    
    currentBills = bills.filter(bill => {
      // Skip hidden bills
      if (bill.hidden) return false;
      
      // Special handling for annual bills - only include if due this month
      if (bill.isAnnual) {
        if (!bill.annualMonth || !bill.annualYear) return false;
        
        const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
        const annualYear = parseInt(bill.annualYear);
        
        // Only include annual bills that are due in the current month/year
        return (annualMonth === currentMonth && annualYear === currentYear);
      }
      
      // Include ALL regular monthly bills regardless of due date
      // This is the key change for the Proactive strategy - include ALL monthly bills
      return true;
    });
  } else {
    // For Reactive: ONLY include bills due in the CURRENT pay period
    // This implements the paycheck-to-paycheck logic, where bills are only paid
    // in the period they're due
    
    if (upcomingPayDates.length > 0) {
      const nextPayDate = upcomingPayDates[0];
      
      // Create a new date for yesterday - we'll use this to get the most recent pay period
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      
      // Get all pay dates including recent past ones
      const { payFrequency, lastPayDate } = settings;
      const refDate = new Date(lastPayDate);
      const [refYear, refMonth, refDay] = lastPayDate.split('-').map(Number);
      refDate.setFullYear(refYear, refMonth - 1, refDay); // month is 0-indexed in JS
      
      let recentPayDates: Date[] = [];
      
      // Generate recent pay dates using the same logic as in getUpcomingPayDates
      switch (payFrequency) {
        case "Weekly": {
          // Generate weekly dates going back 4 weeks
          let weeklyDate = new Date(refDate);
          while (weeklyDate > yesterday) {
            weeklyDate = new Date(weeklyDate.getTime() - 7 * 24 * 60 * 60 * 1000);
          }
          // Go forward until we pass today
          for (let i = 0; i < 6; i++) {
            weeklyDate = new Date(weeklyDate.getTime() + 7 * 24 * 60 * 60 * 1000);
            recentPayDates.push(new Date(weeklyDate));
            if (weeklyDate > today) break;
          }
          break;
        }
        
        case "Bi-Weekly": {
          // Generate bi-weekly dates going back 4 weeks
          let biWeeklyDate = new Date(refDate);
          while (biWeeklyDate > yesterday) {
            biWeeklyDate = new Date(biWeeklyDate.getTime() - 14 * 24 * 60 * 60 * 1000);
          }
          // Go forward until we pass today
          for (let i = 0; i < 3; i++) {
            biWeeklyDate = new Date(biWeeklyDate.getTime() + 14 * 24 * 60 * 60 * 1000);
            recentPayDates.push(new Date(biWeeklyDate));
            if (biWeeklyDate > today) break;
          }
          break;
        }
        
        case "1st & 15th": {
          // Get pay dates for current month
          const currMonth = today.getMonth();
          const currYear = today.getFullYear();
          const prevMonth = currMonth === 0 ? 11 : currMonth - 1;
          const prevYear = currMonth === 0 ? currYear - 1 : currYear;
          
          // Add pay dates for previous and current month
          recentPayDates.push(new Date(prevYear, prevMonth, 15));
          recentPayDates.push(new Date(currYear, currMonth, 1));
          recentPayDates.push(new Date(currYear, currMonth, 15));
          break;
        }
        
        case "Monthly": {
          // Add previous month's pay date and this month's pay date
          const currMonth = today.getMonth();
          const currYear = today.getFullYear();
          const prevMonth = currMonth === 0 ? 11 : currMonth - 1;
          const prevYear = currMonth === 0 ? currYear - 1 : currYear;
          
          recentPayDates.push(new Date(prevYear, prevMonth, refDay));
          recentPayDates.push(new Date(currYear, currMonth, refDay));
          break;
        }
      }
      
      // Sort chronologically
      recentPayDates.sort((a, b) => a.getTime() - b.getTime());
      
      // Find the most recent pay date (closest to today but not after today)
      const mostRecentPayDate = recentPayDates.filter(date => date <= today).pop();
      
      // Determine the period start and end
      const periodStart = mostRecentPayDate || new Date(today.getFullYear(), today.getMonth(), 0);
      
      // Special handling for periods that end on the 1st of next month
      let periodEnd = nextPayDate;
      
      // If the most recent pay date is on the 17th and the next pay date is on the 1st of the next month
      if (mostRecentPayDate && mostRecentPayDate.getDate() === 17 && 
          nextPayDate.getDate() === 1 && nextPayDate.getMonth() > mostRecentPayDate.getMonth()) {
        // Set the end to the last day of the current month (so we don't include the 1st)
        periodEnd = new Date(mostRecentPayDate.getFullYear(), mostRecentPayDate.getMonth() + 1, 0);
      }
      
      currentBills = getBillsInRange(bills, periodStart, periodEnd);
    } else {
      // Fallback: use the last 30 days if we can't determine pay dates
      const startOfPeriod = new Date(today);
      startOfPeriod.setDate(today.getDate() - 30);
      const endOfPeriod = new Date(today);
      endOfPeriod.setDate(today.getDate() + 1); // Include today
      
      currentBills = getBillsInRange(bills, startOfPeriod, endOfPeriod);
    }
  }
  
  // Add status to each bill
  return currentBills.map(bill => {
    // Use the existing status from the database if available
    if (bill.status === "paid" || bill.status === "skip") {
      return bill;
    }
    
    // Otherwise, determine status based on due date
    const dueDay = parseInt(bill.dueDay);
    const billDate = new Date(today.getFullYear(), today.getMonth(), dueDay);
    
    let status: BillStatus;
    
    // If the bill is due in the future, mark as upcoming
    if (billDate > today) {
      status = "upcoming";
    } else {
      // If the bill is past due, mark as due
      status = "due";
    }
    
    return { ...bill, status };
  });
}

export function getEstimatedDraft(): { total: number; baseAmount: number; cushionAmount: number } {
  // Get payment strategy and billing cushion from settings
  const { paymentStrategy, payFrequency, lastPayDate, billingCushion = "2" } = settings;
  const cushionPercentage = parseFloat(billingCushion) / 100;
  
  let baseAmount = 0;
  
  if (paymentStrategy === "Proactive") {
    // For Proactive: Distribute ALL bills evenly across pay periods in the month
    // Get ALL active bills for the month
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    
    // Get all regular monthly bills and annual bills due this month
    const allActiveBills = bills.filter(bill => {
      // Skip hidden bills
      if (bill.hidden) return false;
      
      // For annual bills, check if they're due this month
      if (bill.isAnnual) {
        if (!bill.annualMonth || !bill.annualYear) return false;
        const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
        const annualYear = parseInt(bill.annualYear);
        return annualMonth === currentMonth && annualYear === currentYear;
      }
      
      // Include all regular bills regardless of due date
      return true;
    });
    
    // Calculate total monthly expense
    const totalMonthlyAmount = allActiveBills.reduce((sum, bill) => {
      const baseAmount = Number(bill.amount || 0);
      const additionalAmount = Number(bill.additionalPayment || 0);
      return sum + baseAmount + additionalAmount;
    }, 0);
    
    // Determine how many pay periods in a month
    let periodsPerMonth = 1;
    switch (payFrequency) {
      case "Weekly": periodsPerMonth = 4; break;
      case "Bi-Weekly": periodsPerMonth = 2; break;
      case "1st & 15th": periodsPerMonth = 2; break;
      case "Monthly": periodsPerMonth = 1; break;
    }
    
    // Calculate the base amount - divide total by number of pay periods
    // This is the TRUE proactive approach - dividing ALL bills evenly
    baseAmount = totalMonthlyAmount / periodsPerMonth;
  } else {
    // For Reactive: ONLY include bills due in the CURRENT pay period
    // Get current period bills based on lastPayDate and payFrequency
    const currentBills = getCurrentPeriodBills();
    
    // For reactive, we ONLY include bills actually due in this specific period
    baseAmount = currentBills.reduce((sum, bill) => {
      // Skip bills that are paid or skipped, only include bills that need to be paid
      if (bill.status === "paid" || bill.status === "skip") {
        return sum;
      }
      
      const baseAmount = Number(bill.amount || 0);
      const additionalAmount = Number(bill.additionalPayment || 0);
      return sum + baseAmount + additionalAmount;
    }, 0);
  }
  
  // Calculate cushion amount
  const cushionAmount = baseAmount * cushionPercentage;
  
  // Calculate total with cushion
  const total = baseAmount + cushionAmount;
  
  return { total, baseAmount, cushionAmount };
}

export function getMonthlyTotal(): number {
  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();

  // Get all eligible bills for this month (regardless of paid/skip status)
  const monthlyBills = bills.filter(bill => {
    // Skip hidden bills
    if (bill.hidden) return false;
    
    // Handle annual bills
    if (bill.isAnnual) {
      if (!bill.annualMonth || !bill.annualYear) return false;
      
      const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
      const annualYear = parseInt(bill.annualYear);
      
      // Only include annual bills that are due in the current month/year
      return (annualMonth === currentMonth && annualYear === currentYear);
    }
    
    // Include all regular monthly bills
    return true;
  });
  
  // Calculate total of all unpaid bills
  return monthlyBills
    .filter(bill => bill.status !== "paid" && bill.status !== "skip")
    .reduce((sum, bill) => {
      const baseAmount = Number(bill.amount || 0);
      const additionalAmount = Number(bill.additionalPayment || 0);
      return sum + baseAmount + additionalAmount;
    }, 0);
}

export function getActiveBillsCount(): number {
  return bills.filter(bill => !bill.hidden).length;
}

export function getDueSoonCount(): number {
  const today = new Date();
  const nextWeek = new Date(today);
  nextWeek.setDate(today.getDate() + 7);
  
  return bills.filter(bill => {
    if (bill.hidden) return false;
    
    // Handle annual bills
    if (bill.isAnnual) {
      if (!bill.annualMonth || !bill.annualYear) return false;
      
      const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
      const annualYear = parseInt(bill.annualYear);
      const annualDueDay = parseInt(bill.dueDay);
      
      if (isNaN(annualDueDay)) return false;
      
      // Create the exact annual due date
      const annualDueDate = new Date(annualYear, annualMonth, annualDueDay);
      
      // Only include if due date is within the next week
      return (annualDueDate >= today && annualDueDate <= nextWeek);
    }
    
    // Handle regular monthly bills
    const dueDay = parseInt(bill.dueDay);
    if (isNaN(dueDay)) return false;
    
    const billDate = new Date(today.getFullYear(), today.getMonth(), dueDay);
    
    // If the due day has passed this month, check next month
    if (billDate < today) {
      billDate.setMonth(billDate.getMonth() + 1);
    }
    
    return billDate <= nextWeek;
  }).length;
}