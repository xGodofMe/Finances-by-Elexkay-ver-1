import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Safely open external URLs to be compatible with all devices including Android
 * This fixes the "could not find an appropriate application" error on some Android devices
 */
export function safeOpenExternalUrl(url: string): void {
  // Add https protocol if not present
  if (!/^https?:\/\//i.test(url)) {
    url = 'https://' + url;
  }
  
  // Use window.open with explicit options
  try {
    window.open(url, '_blank', 'noopener,noreferrer');
  } catch (error) {
    console.error('Failed to open URL:', error);
    
    // Fallback method for Android
    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.click();
  }
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(value);
}

export function getOrdinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
}
