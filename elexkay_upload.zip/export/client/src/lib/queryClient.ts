import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest<T = any>(
  method: string,
  url: string,
  data?: any
): Promise<T>;
export async function apiRequest<T = any>(
  url: string,
  options?: RequestInit
): Promise<T>;
export async function apiRequest<T = any>(
  methodOrUrl: string,
  urlOrOptions?: string | RequestInit,
  data?: any
): Promise<T | null> {
  // Handle overloaded function signatures
  let url: string;
  let options: RequestInit = {};

  if (typeof urlOrOptions === 'string') {
    // First signature: apiRequest(method, url, data?)
    url = urlOrOptions;
    options = {
      method: methodOrUrl,
      body: data ? JSON.stringify(data) : undefined,
      headers: {
        'Content-Type': 'application/json'
      }
    };
  } else {
    // Second signature: apiRequest(url, options?)
    url = methodOrUrl;
    options = urlOrOptions || {};
  }

  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    credentials: "include",
  });

  await throwIfResNotOk(res);
  
  // For 204 No Content or 200 OK with empty or text-only responses, return null instead of trying to parse JSON
  if (res.status === 204 || (res.status === 200 && res.headers.get('content-type')?.includes('text/plain'))) {
    return null as any;
  }
  
  // Check if the response is empty
  const text = await res.text();
  if (!text) {
    return null as any;
  }
  
  // For all other responses, parse JSON
  try {
    return JSON.parse(text) as T;
  } catch (error) {
    // If parsing fails but the response was successful, just return null
    if (res.ok) {
      return null as any;
    }
    throw new Error(`Error parsing JSON response: ${error}`);
  }
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    
    // For 204 No Content or 200 OK with empty or text-only responses, return null
    if (res.status === 204 || (res.status === 200 && res.headers.get('content-type')?.includes('text/plain'))) {
      return null;
    }
    
    // Check if the response is empty
    const text = await res.text();
    if (!text) {
      return null;
    }
    
    // Parse JSON
    try {
      return JSON.parse(text);
    } catch (error) {
      // If parsing fails but the response was successful, just return null
      if (res.ok) {
        return null;
      }
      throw new Error(`Error parsing JSON response: ${error}`);
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
