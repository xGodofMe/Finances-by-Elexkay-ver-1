import { getBillsInRange, getPayDates } from "./date-utils";
import { apiRequest } from "./queryClient";
import { BillStatus } from "@shared/schema";

export interface Bill {
  id?: string | number;
  name: string;
  amount: string;
  dueDay: string;
  method: string;
  hidden: boolean;
  autoDraft: boolean;
  status?: BillStatus;
  isAnnual?: boolean;
  annualMonth?: string; // Month number as string (1-12)
  annualYear?: string;  // Year as string (e.g., "2025")
  // Website URL
  website?: string;
  // Credentials
  username?: string;
  email?: string;
  password?: string;
  // Additional payment
  additionalPayment?: string;
  userId?: number;
}

export interface Settings {
  id?: number;
  userId?: number;
  paymentStrategy: string;
  payFrequency: string;
  lastPayDate: string; // Now referred to as "Reference Pay Date" in the UI
  billingCushion?: string; // Percentage as a string
  resetDate?: number; // Day of month to reset bill status (1-28)
  autoResetEnabled?: boolean; // Whether auto reset is enabled
}

// State variables
let bills: Bill[] = [];
let settings: Settings = {
  paymentStrategy: "Proactive",
  payFrequency: "Bi-Weekly",
  lastPayDate: new Date().toISOString().substring(0, 10),
  billingCushion: "2",
  resetDate: 1,
  autoResetEnabled: true
};

// Mock date for testing
let mockDate: Date | null = null;

// Get the current date (real or mocked)
export function getCurrentDate(): Date {
  return mockDate || new Date();
}

// Set a mock date for testing
export function setMockDate(date: Date | null): void {
  mockDate = date;
  notifyListeners(); // Refresh UI when mock date changes
}

// Subscribe function for reactive updates
type Listener = () => void;
const listeners: Listener[] = [];

export function subscribe(listener: Listener) {
  listeners.push(listener);
  return () => {
    const index = listeners.indexOf(listener);
    if (index > -1) {
      listeners.splice(index, 1);
    }
  };
}

function notifyListeners() {
  listeners.forEach(listener => listener());
}

// Store initialization
export async function initializeStore() {
  try {
    // Check if user is authenticated first
    const user = await apiRequest<any>("/api/user")
      .catch(err => {
        // Silently handle 401 errors
        if (err.message && err.message.startsWith("401:")) {
          return null;
        }
        throw err;
      });
    
    // Only fetch data if user is authenticated
    if (user) {
      // Fetch bills from API
      const fetchedBills = await apiRequest<Bill[]>("/api/bills");
      bills = fetchedBills || [];
      
      // Fetch settings from API
      const fetchedSettings = await apiRequest<Settings>("/api/settings");
      if (fetchedSettings) {
        settings = fetchedSettings;
      }
      
      notifyListeners();
    }
  } catch (error) {
    console.error("Failed to initialize store:", error);
    // Don't throw the error so the app can continue loading
  }
}

// Bill CRUD operations
// Get bills from local store (fast but may not have latest data)
export function getBills(): Bill[] {
  return [...bills];
}

// Get bills from server (ensures we have the latest data)
// Check if bills need to be reset based on reset date
export async function checkAndResetBillStatus(): Promise<void> {
  try {
    const { resetDate, autoResetEnabled } = settings;
    
    // Skip if auto reset is disabled
    if (!autoResetEnabled) return;
    
    // Get current date
    const today = getCurrentDate();
    const currentDay = today.getDate();
    
    // Check if today is the reset date
    if (resetDate && currentDay === resetDate) {
      // Get the last reset check date from localStorage
      const lastResetCheck = localStorage.getItem('lastResetCheck');
      
      if (lastResetCheck) {
        const lastDate = new Date(lastResetCheck);
        // If we already checked today, don't reset again
        if (
          lastDate.getDate() === today.getDate() && 
          lastDate.getMonth() === today.getMonth() && 
          lastDate.getFullYear() === today.getFullYear()
        ) {
          return;
        }
      }
      
      // Store current date as last reset check
      localStorage.setItem('lastResetCheck', today.toISOString());
      
      // Reset all bill statuses to "upcoming"
      for (const bill of bills) {
        if (bill.status === "paid" || bill.status === "skip") {
          await updateBill(bill.id!, { status: "upcoming" });
        }
      }
    }
  } catch (error) {
    console.error("Failed to check and reset bill status:", error);
  }
}

export async function fetchBills(): Promise<Bill[]> {
  try {
    const fetchedBills = await apiRequest<Bill[]>("/api/bills");
    if (fetchedBills) {
      bills = fetchedBills; // Update the local store
      
      // Check if bills need to be reset
      await checkAndResetBillStatus();
      
      notifyListeners();
      return fetchedBills;
    }
    return [];
  } catch (error) {
    console.error("Failed to fetch bills:", error);
    return [...bills]; // Fall back to local data if server request fails
  }
}

export async function addBill(bill: Bill): Promise<void> {
  try {
    const newBill = await apiRequest<Bill>("/api/bills", {
      method: "POST",
      body: JSON.stringify(bill)
    });
    
    if (newBill) {
      bills = [...bills, newBill];
      notifyListeners();
    }
  } catch (error) {
    console.error("Failed to add bill:", error);
  }
}

export async function updateBill(id: string | number, updates: Partial<Bill>): Promise<void> {
  try {
    const updatedBill = await apiRequest<Bill>(`/api/bills/${id}`, {
      method: "PUT",
      body: JSON.stringify(updates)
    });
    
    if (updatedBill) {
      bills = bills.map(bill => 
        bill.id === id ? { ...bill, ...updatedBill } : bill
      );
      notifyListeners();
    }
  } catch (error) {
    console.error("Failed to update bill:", error);
  }
}

export async function deleteBill(id: string | number): Promise<void> {
  try {
    await apiRequest(`/api/bills/${id}`, {
      method: "DELETE"
    });
    
    // If we reached here, the delete was successful
    bills = bills.filter(bill => String(bill.id) !== String(id));
    notifyListeners();
  } catch (error) {
    console.error("Failed to delete bill:", error);
    throw error; // Re-throw to allow components to handle the error
  }
}

// Settings operations
export function getSettings(): Settings {
  return { ...settings };
}

export async function updateSettings(updates: Partial<Settings>): Promise<void> {
  try {
    // Ensure the lastPayDate is properly formatted if it exists
    let formattedUpdates = {...updates};
    
    if (updates.lastPayDate) {
      // Check the type of lastPayDate and format accordingly
      if (typeof updates.lastPayDate === 'object' && updates.lastPayDate !== null) {
        // It's a Date object
        try {
          formattedUpdates.lastPayDate = (updates.lastPayDate as Date).toISOString().split('T')[0];
        } catch (err) {
          console.error('Error formatting date object:', err);
        }
      } 
      // If it's an ISO date string that includes time
      else if (typeof updates.lastPayDate === 'string' && updates.lastPayDate.includes('T')) {
        formattedUpdates.lastPayDate = updates.lastPayDate.split('T')[0];
      }
      // Otherwise keep it as is, assuming it's already in YYYY-MM-DD format
    }
    
    console.log('Sending formatted settings update:', formattedUpdates);
    
    const updatedSettings = await apiRequest<Settings>("/api/settings", {
      method: "POST",
      body: JSON.stringify(formattedUpdates)
    });
    
    console.log('Received settings from server:', updatedSettings);
    
    if (updatedSettings) {
      settings = { ...settings, ...updatedSettings };
      notifyListeners();
    }
  } catch (error) {
    console.error("Failed to update settings:", error);
    throw error; // Re-throw to allow handling in the component
  }
}

// Derived state
export function getUpcomingPayDates(): Date[] {
  const { payFrequency, lastPayDate } = settings;
  
  if (!lastPayDate) {
    // If no reference pay date is set, return an empty array
    console.log("No reference pay date configured");
    return [];
  }
  
  const today = getCurrentDate();
  
  try {
    // Parse the reference pay date - handle both ISO and simple date formats
    let refDate: Date;
    let refYear: number, refMonth: number, refDay: number;
    
    if (lastPayDate.includes('T')) {
      // ISO format like "2025-04-03T10:00:00.000Z"
      refDate = new Date(lastPayDate);
      refYear = refDate.getFullYear();
      refMonth = refDate.getMonth();
      refDay = refDate.getDate();
    } else {
      // Simple format like "2025-4-3"
      [refYear, refMonth, refDay] = lastPayDate.split('-').map(Number);
      
      // Validate the date parts
      if (isNaN(refYear) || isNaN(refMonth) || isNaN(refDay)) {
        console.error("Invalid date format in lastPayDate", lastPayDate);
        return [];
      }
      
      refDate = new Date(refYear, refMonth - 1, refDay); // month is 0-indexed in JS
    }
    
    // Generate a series of future pay dates based on the reference pay date
    let futureDates: Date[] = [];
    
    // Always include the exact reference day in the result
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    const refDayThisMonth = new Date(currentYear, currentMonth, refDay);
    
    // If reference day hasn't passed yet this month, include it
    if (refDayThisMonth >= today) {
      futureDates.push(new Date(refDayThisMonth));
    }
    
    switch (payFrequency) {
      case "Weekly":
        // Weekly - Start from the reference date and add 7 days repeatedly
        let weeklyDate = new Date(refDate);
        // Go back in time if needed to ensure we capture recent dates
        while (weeklyDate.getTime() > today.getTime() - 7 * 24 * 60 * 60 * 1000) {
          weeklyDate = new Date(weeklyDate.getTime() - 7 * 24 * 60 * 60 * 1000);
        }
        // Now generate forward
        for (let i = 0; i < 20; i++) {
          weeklyDate = new Date(weeklyDate.getTime() + 7 * 24 * 60 * 60 * 1000);
          futureDates.push(new Date(weeklyDate));
        }
        break;
        
      case "Bi-Weekly":
        // Bi-Weekly - Start from the exact reference date and add 14 days repeatedly
        let biWeeklyDate = new Date(refDate);
        
        console.log('Bi-weekly calculation starting with reference date:', biWeeklyDate.toDateString());
        
        // First, ensure the exact reference date is included if it's today or in the future
        if (biWeeklyDate >= today) {
          console.log('Including reference date in pay dates:', biWeeklyDate.toDateString());
          futureDates.push(new Date(biWeeklyDate));
        }
        
        // Go back in time by one pay period if needed to ensure we capture the most recent past date
        // This helps with calculations that need to know the previous pay date
        const twoWeeksAgo = new Date(today);
        twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
        
        // Find the most recent pay date (could be in the past)
        let recentPayDate = new Date(biWeeklyDate);
        while (recentPayDate > today) {
          recentPayDate.setDate(recentPayDate.getDate() - 14);
        }
        
        // Now generate forward from the most recent date (whether past, present or future)
        let nextPayDate = new Date(recentPayDate);
        for (let i = 0; i < 10; i++) {
          nextPayDate.setDate(nextPayDate.getDate() + 14);
          console.log('Adding bi-weekly pay date:', nextPayDate.toDateString());
          futureDates.push(new Date(nextPayDate));
        }
        break;
        
      case "Semi-Monthly":
        // 1st and 15th of each month for the next several months
        const startMonth = today.getMonth();
        const startYear = today.getFullYear();
        for (let i = 0; i < 6; i++) {
          const targetMonth = (startMonth + i) % 12;
          const targetYear = startYear + Math.floor((startMonth + i) / 12);
          futureDates.push(new Date(targetYear, targetMonth, 1));
          futureDates.push(new Date(targetYear, targetMonth, 15));
        }
        break;
        
      case "Monthly":
        // Monthly - Use the same day of month as the reference date
        const dayOfMonth = refDay;
        
        // Generate future dates using the reference day
        for (let i = 0; i < 8; i++) {
          const targetMonth = (currentMonth + i) % 12;
          const targetYear = currentYear + Math.floor((currentMonth + i) / 12);
          // Check if the day is valid for the month
          const lastDayOfMonth = new Date(targetYear, targetMonth + 1, 0).getDate();
          const validDay = Math.min(dayOfMonth, lastDayOfMonth);
          futureDates.push(new Date(targetYear, targetMonth, validDay));
        }
        break;
    }
    
    // Sort chronologically
    futureDates.sort((a, b) => a.getTime() - b.getTime());
    
    // Remove duplicates (in case we added the reference date separately)
    futureDates = futureDates.filter((date, index, self) =>
      index === self.findIndex(d => d.getDate() === date.getDate() && 
                                    d.getMonth() === date.getMonth() &&
                                    d.getFullYear() === date.getFullYear())
    );
    
    // Filter to only include dates on or after today
    const upcomingDates = futureDates.filter(date => date >= today);
    
    // Return the next 8 pay dates
    return upcomingDates.slice(0, 8);
  } catch (error) {
    console.error("Error calculating upcoming pay dates:", error);
    return [];
  }
}

// Get draft summary for the current month based on reference date and pay frequency
export function getDraftSummary(): { date: Date; amount: number; cushionAmount: number; count: number }[] {
  const { paymentStrategy, payFrequency, lastPayDate, billingCushion } = settings;
  
  if (!lastPayDate) {
    console.log("No reference pay date configured for draft summary");
    return [];
  }
  
  const cushionPercentage = parseFloat(billingCushion || "2") / 100;
  
  try {
    // Get current month and year
    const today = getCurrentDate();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    
    // Parse the reference pay date - handle both ISO and simple date formats
    let referenceDate: Date;
    let refYear: number, refMonth: number, refDay: number;
    
    if (lastPayDate.includes('T')) {
      // ISO format like "2025-04-03T10:00:00.000Z"
      referenceDate = new Date(lastPayDate);
      refYear = referenceDate.getFullYear();
      refMonth = referenceDate.getMonth();
      refDay = referenceDate.getDate();
    } else {
      // Simple format like "2025-4-3"
      [refYear, refMonth, refDay] = lastPayDate.split('-').map(Number);
      
      // Validate the date parts
      if (isNaN(refYear) || isNaN(refMonth) || isNaN(refDay)) {
        console.error("Invalid date format in lastPayDate for draft summary", lastPayDate);
        return [];
      }
      
      referenceDate = new Date(refYear, refMonth - 1, refDay); // month is 0-indexed in JS
    }
    
    console.log(`Current month/year: ${currentMonth + 1}/${currentYear}, Reference Pay Date: ${referenceDate.toDateString()}`);
    
    // Get all upcoming pay dates (may include dates from other months)
    const allPayDates = getUpcomingPayDates();
    
    // Make a copy of the reference date to ensure it's included
    const refDateCopy = new Date(referenceDate);
    
    // Filter to only current month pay dates
    let currentMonthPayDates = allPayDates.filter(date => 
      date.getMonth() === currentMonth && 
      date.getFullYear() === currentYear
    );
    
    // For Bi-Weekly pay, ensure we have both first-half and second-half pay dates
    if (payFrequency === "Bi-Weekly") {
      // If reference date (e.g., April 3) is in the current month, add it to the list
      if (refDateCopy.getMonth() === currentMonth && 
          refDateCopy.getFullYear() === currentYear) {
        // Check if it's not already in the list
        const refDateExists = currentMonthPayDates.some(date => 
          date.getDate() === refDateCopy.getDate()
        );
        
        if (!refDateExists) {
          currentMonthPayDates.push(refDateCopy);
        }
      }
      
      // Also ensure we have at least one pay date in each half of the month
      const middleOfMonth = 15;
      const hasFirstHalfDate = currentMonthPayDates.some(date => date.getDate() <= middleOfMonth);
      const hasSecondHalfDate = currentMonthPayDates.some(date => date.getDate() > middleOfMonth);
      
      // If no first half date, add one based on reference date
      if (!hasFirstHalfDate) {
        // Use the reference date day if it's in the first half, otherwise use day 3
        const firstHalfDay = refDay <= middleOfMonth ? refDay : 3;
        currentMonthPayDates.push(new Date(currentYear, currentMonth, firstHalfDay));
      }
      
      // If no second half date, add one based on reference date
      if (!hasSecondHalfDate) {
        let secondHalfDay;
        
        // If the reference day is in the first half (1-15), add 14 days to get the second pay date
        if (refDay <= middleOfMonth) {
          // Calculate the second pay date by adding 14 days
          const secondPayDate = new Date(referenceDate);
          secondPayDate.setDate(refDay + 14);
          
          // If still in same month, use the calculated day
          if (secondPayDate.getMonth() === currentMonth) {
            secondHalfDay = secondPayDate.getDate();
          } else {
            // Default to 17th if the calculated date would be in the next month
            secondHalfDay = 17;
          }
        } else {
          // If reference date is already in second half, use that day
          secondHalfDay = refDay;
        }
        
        // Make sure the date is valid for the month
        const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const validSecondHalfDay = Math.min(secondHalfDay, lastDayOfMonth);
        
        currentMonthPayDates.push(new Date(currentYear, currentMonth, validSecondHalfDay));
        
        console.log(`Added second half pay date: ${validSecondHalfDay}/${currentMonth + 1}/${currentYear} based on reference day ${refDay}`);
      }
      
      // Sort dates chronologically
      currentMonthPayDates.sort((a, b) => a.getTime() - b.getTime());
    }
    
    if (currentMonthPayDates.length === 0) {
      console.log("No pay dates found in current month");
      return [];
    }
    
    // Get all active bills (not hidden)
    const activeBills = bills.filter(bill => !bill.hidden);
    
    // Log all active bills for debugging
    console.log("Active bills:", activeBills.map(bill => ({
      name: bill.name,
      dueDay: parseInt(bill.dueDay),
      status: bill.status,
      isAnnual: bill.isAnnual
    })));
    
    // Log all pay dates in the month
    console.log("Pay dates in current month:", currentMonthPayDates.map(d => d.toDateString()));
    
    if (payFrequency === "Bi-Weekly") {
      // For bi-weekly pay frequency, we need special bill assignment logic
      
      // Get middle of the month
      const middleOfMonth = 15;
      
      // Split the month in half (1-15, 16-end)
      const firstHalfPayDates = currentMonthPayDates.filter(date => date.getDate() <= middleOfMonth);
      const secondHalfPayDates = currentMonthPayDates.filter(date => date.getDate() > middleOfMonth);
      
      // For each bill, check which half of the month it's due in
      const firstHalfBills = activeBills.filter(bill => {
        // Skip paid, skipped, or hidden bills
        if (bill.status === "paid" || bill.status === "skip" || bill.hidden) {
          return false;
        }
        
        // Parse due day as number
        const dueDayNum = parseInt(bill.dueDay);
        if (isNaN(dueDayNum)) return false;
        
        // For annual bills, check if due in current month/year
        if (bill.isAnnual) {
          if (!bill.annualMonth || !bill.annualYear) return false;
          const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
          const annualYear = parseInt(bill.annualYear);
          
          // Include if due in current month/year and in first half of month
          return (annualMonth === currentMonth && 
                  annualYear === currentYear && 
                  dueDayNum <= middleOfMonth);
        }
        
        // Regular monthly bills - include if due in first half of month
        return dueDayNum <= middleOfMonth;
      });
      
      const secondHalfBills = activeBills.filter(bill => {
        // Skip paid, skipped, or hidden bills
        if (bill.status === "paid" || bill.status === "skip" || bill.hidden) {
          return false;
        }
        
        // Parse due day as number
        const dueDayNum = parseInt(bill.dueDay);
        if (isNaN(dueDayNum)) return false;
        
        // For annual bills, check if due in current month/year
        if (bill.isAnnual) {
          if (!bill.annualMonth || !bill.annualYear) return false;
          const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
          const annualYear = parseInt(bill.annualYear);
          
          // Include if due in current month/year and in second half of month
          return (annualMonth === currentMonth && 
                  annualYear === currentYear && 
                  dueDayNum > middleOfMonth);
        }
        
        // Regular monthly bills - include if due in second half of month
        return dueDayNum > middleOfMonth;
      });
      
      // Debug: Log the bills for each half of the month
      console.log("First half bills (due days 1-15):", firstHalfBills.map(b => 
        `${b.name} (due on day ${b.dueDay})`
      ));
      
      console.log("Second half bills (due days 16-end):", secondHalfBills.map(b => 
        `${b.name} (due on day ${b.dueDay})`
      ));
      
      // For each pay date in the month, determine if it's in the first half or second half
      return currentMonthPayDates.map(payDate => {
        // Determine if this pay date is in the first or second half of the month
        const isFirstHalf = payDate.getDate() <= middleOfMonth;
        
        // Get the list of bills for this half
        const periodBills = isFirstHalf ? firstHalfBills : secondHalfBills;
        
        // Calculate total amount for this pay period including additional payments
        const totalAmount = periodBills.reduce((sum, bill) => {
          const baseAmount = parseFloat(bill.amount || "0");
          const additionalAmount = parseFloat(bill.additionalPayment || "0");
          return sum + baseAmount + additionalAmount;
        }, 0);
        
        // Add cushion
        const cushionAmount = totalAmount * cushionPercentage;
        
        console.log(`Pay date ${payDate.toDateString()} (${isFirstHalf ? 'first half' : 'second half'}): $${totalAmount.toFixed(2)}, cushion: $${cushionAmount.toFixed(2)}, bills: ${periodBills.length}`);
        
        return {
          date: payDate,
          amount: totalAmount + cushionAmount,
          cushionAmount: cushionAmount,
          count: periodBills.length
        };
      });
    } else {
      // For other pay frequencies, use a different approach (weekly, semi-monthly, monthly)
      
      // Calculate bills for each pay date
      return currentMonthPayDates.map((payDate, index) => {
        // Get the next pay date (or end of month if this is the last)
        const nextIndex = index + 1;
        const isLastPayDate = nextIndex >= currentMonthPayDates.length;
        
        // Determine the end date for this period
        let periodEndDate: Date;
        
        if (isLastPayDate) {
          // Last pay date - use end of month
          const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
          periodEndDate = new Date(currentYear, currentMonth, lastDayOfMonth);
        } else {
          // Use day before next pay date
          periodEndDate = new Date(currentMonthPayDates[nextIndex]);
          periodEndDate.setDate(periodEndDate.getDate() - 1);
        }
        
        // Get the day range for this period
        const periodStartDay = payDate.getDate();
        const periodEndDay = periodEndDate.getDate();
        
        console.log(`Pay period ${index + 1}: ${payDate.toDateString()} covering days ${periodStartDay}-${periodEndDay}`);
        
        // Filter bills that belong to this pay period
        const periodBills = activeBills.filter(bill => {
          // Skip paid or skipped bills
          if (bill.status === "paid" || bill.status === "skip") {
            return false;
          }
          
          // Parse due day as number
          const dueDayNum = parseInt(bill.dueDay);
          if (isNaN(dueDayNum)) return false;
          
          // For annual bills, check if due in current month/year
          if (bill.isAnnual) {
            if (!bill.annualMonth || !bill.annualYear) return false;
            const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
            const annualYear = parseInt(bill.annualYear);
            
            // Include if due in current month/year and due day is in this period
            return (annualMonth === currentMonth && 
                   annualYear === currentYear && 
                   dueDayNum >= periodStartDay && 
                   dueDayNum <= periodEndDay);
          }
          
          // Regular monthly bills - include if due in this period
          return dueDayNum >= periodStartDay && dueDayNum <= periodEndDay;
        });
        
        console.log(`Bills for pay date ${payDate.toDateString()}:`, 
          periodBills.map(b => `${b.name} (due on day ${b.dueDay})`)
        );
        
        // Calculate total amount for this pay period including additional payments
        const totalAmount = periodBills.reduce((sum, bill) => {
          const baseAmount = parseFloat(bill.amount || "0");
          const additionalAmount = parseFloat(bill.additionalPayment || "0");
          return sum + baseAmount + additionalAmount;
        }, 0);
        
        // Add cushion
        const cushionAmount = totalAmount * cushionPercentage;
        
        console.log(`Period total: $${totalAmount.toFixed(2)}, cushion: $${cushionAmount.toFixed(2)}, bills: ${periodBills.length}`);
        
        return {
          date: payDate,
          amount: totalAmount + cushionAmount,
          cushionAmount: cushionAmount,
          count: periodBills.length
        };
      });
    }
  } catch (error) {
    console.error("Error calculating draft summary:", error);
    return [];
  }
}

export function getCurrentPeriodBills(): Bill[] {
  const { paymentStrategy, payFrequency, lastPayDate } = settings;
  const today = getCurrentDate();
  console.log(`Getting current period bills for date: ${today.toDateString()}`);
  
  // Always include visible regular monthly bills (not hidden)
  const visibleMonthlyBills = bills.filter(bill => 
    !bill.hidden && 
    (!bill.isAnnual || 
      (bill.isAnnual && 
       bill.annualMonth && 
       parseInt(bill.annualMonth) - 1 === today.getMonth() && 
       bill.annualYear && 
       parseInt(bill.annualYear) === today.getFullYear())
    )
  );
  
  console.log(`Total visible bills: ${visibleMonthlyBills.length}`);
  
  let currentBills: Bill[] = [];
  
  // Special case: If it's the 1st day of the month, always show all bills
  if (today.getDate() === 1) {
    console.log('Showing all bills because it is the 1st of the month');
    currentBills = visibleMonthlyBills;
    // Add statuses to bills and return immediately
    return currentBills.map(bill => {
      // Use the existing status from the database if available
      if (bill.status === "paid" || bill.status === "skip") {
        return bill;
      }
      
      // Otherwise, determine status based on due date
      const dueDay = parseInt(bill.dueDay);
      let billDate = new Date(today.getFullYear(), today.getMonth(), dueDay);
      
      let status: BillStatus;
      
      // If the bill is due in the future, mark as upcoming
      if (billDate > today) {
        status = "upcoming";
      } else {
        // If the bill is past due, mark as due
        status = "due";
      }
      
      return { ...bill, status };
    });
  }
  
  if (paymentStrategy === "Proactive") {
    // For Proactive: Include all bills due in the next 30 days
    const thirtyDaysLater = new Date(today);
    thirtyDaysLater.setDate(today.getDate() + 30);
    
    currentBills = visibleMonthlyBills.filter(bill => {
      // Special handling for annual bills
      if (bill.isAnnual) {
        if (!bill.annualMonth || !bill.annualYear) return false;
        
        const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
        const annualYear = parseInt(bill.annualYear);
        const annualDueDay = parseInt(bill.dueDay);
        
        // Create the exact annual due date
        const annualDueDate = new Date(annualYear, annualMonth, annualDueDay);
        
        // Only include if due date is within the next 30 days
        return (annualDueDate >= today && annualDueDate <= thirtyDaysLater);
      }
      
      // Regular monthly bills
      const dueDay = parseInt(bill.dueDay);
      if (isNaN(dueDay)) return false;
      
      const currentMonthDate = new Date(today.getFullYear(), today.getMonth(), dueDay);
      const nextMonthDate = new Date(today.getFullYear(), today.getMonth() + 1, dueDay);
      
      return (currentMonthDate >= today && currentMonthDate <= thirtyDaysLater) || 
             (nextMonthDate >= today && nextMonthDate <= thirtyDaysLater);
    });
  } else {
    // For Reactive: Only include bills due in the current pay period
    const allPayDates = getUpcomingPayDates();
    
    if (allPayDates.length > 0) {
      const nextPayDate = allPayDates[0];
      
      // Create a new date for yesterday - we'll use this to get the most recent pay period
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      
      // Parse the reference pay date - handle both ISO and simple date formats
      let refDate: Date;
      let refYear: number, refMonth: number, refDay: number;
      
      if (lastPayDate.includes('T')) {
        // ISO format like "2025-04-03T10:00:00.000Z"
        refDate = new Date(lastPayDate);
        refYear = refDate.getFullYear();
        refMonth = refDate.getMonth();
        refDay = refDate.getDate();
      } else {
        // Simple format like "2025-4-3"
        [refYear, refMonth, refDay] = lastPayDate.split('-').map(Number);
        refDate = new Date(refYear, refMonth - 1, refDay); // month is 0-indexed in JS
      }
      
      let recentPayDates: Date[] = [];
      
      // Generate recent pay dates using the same logic as in getUpcomingPayDates
      switch (payFrequency) {
        case "Weekly": {
          // Generate weekly dates going back 4 weeks
          let weeklyDate = new Date(refDate);
          while (weeklyDate > yesterday) {
            weeklyDate = new Date(weeklyDate.getTime() - 7 * 24 * 60 * 60 * 1000);
          }
          // Go forward until we pass today
          for (let i = 0; i < 6; i++) {
            weeklyDate = new Date(weeklyDate.getTime() + 7 * 24 * 60 * 60 * 1000);
            recentPayDates.push(new Date(weeklyDate));
            if (weeklyDate > today) break;
          }
          break;
        }
        
        case "Bi-Weekly": {
          // Generate bi-weekly dates going back 4 weeks
          let biWeeklyDate = new Date(refDate);
          while (biWeeklyDate > yesterday) {
            biWeeklyDate = new Date(biWeeklyDate.getTime() - 14 * 24 * 60 * 60 * 1000);
          }
          // Go forward until we pass today
          for (let i = 0; i < 3; i++) {
            biWeeklyDate = new Date(biWeeklyDate.getTime() + 14 * 24 * 60 * 60 * 1000);
            recentPayDates.push(new Date(biWeeklyDate));
            if (biWeeklyDate > today) break;
          }
          break;
        }
        
        case "1st & 15th": {
          // Get pay dates for current month
          const currMonth = today.getMonth();
          const currYear = today.getFullYear();
          const prevMonth = currMonth === 0 ? 11 : currMonth - 1;
          const prevYear = currMonth === 0 ? currYear - 1 : currYear;
          
          // Add pay dates for previous and current month
          recentPayDates.push(new Date(prevYear, prevMonth, 15));
          recentPayDates.push(new Date(currYear, currMonth, 1));
          recentPayDates.push(new Date(currYear, currMonth, 15));
          break;
        }
        
        case "Monthly": {
          // Add previous month's pay date and this month's pay date
          const currMonth = today.getMonth();
          const currYear = today.getFullYear();
          const prevMonth = currMonth === 0 ? 11 : currMonth - 1;
          const prevYear = currMonth === 0 ? currYear - 1 : currYear;
          
          recentPayDates.push(new Date(prevYear, prevMonth, refDay));
          recentPayDates.push(new Date(currYear, currMonth, refDay));
          break;
        }
      }
      
      // Sort chronologically
      recentPayDates.sort((a, b) => a.getTime() - b.getTime());
      
      // Find the most recent pay date (closest to today but not after today)
      const mostRecentPayDate = recentPayDates.filter(date => date <= today).pop();
      
      // Determine the period start and end
      const periodStart = mostRecentPayDate || new Date(today.getFullYear(), today.getMonth(), 0);
      
      // Special handling for periods that end on the 1st of next month
      let periodEnd = nextPayDate;
      
      // If the most recent pay date is on the 17th and the next pay date is on the 1st of the next month
      if (mostRecentPayDate && mostRecentPayDate.getDate() === 17 && 
          nextPayDate.getDate() === 1 && nextPayDate.getMonth() > mostRecentPayDate.getMonth()) {
        // Set the end to the last day of the current month (so we don't include the 1st)
        periodEnd = new Date(mostRecentPayDate.getFullYear(), mostRecentPayDate.getMonth() + 1, 0);
      }
      
      currentBills = getBillsInRange(bills, periodStart, periodEnd);
    } else {
      // Fallback: use the last 30 days if we can't determine pay dates
      const startOfPeriod = new Date(today);
      startOfPeriod.setDate(today.getDate() - 30);
      const endOfPeriod = new Date(today);
      endOfPeriod.setDate(today.getDate() + 1); // Include today
      
      currentBills = getBillsInRange(bills, startOfPeriod, endOfPeriod);
    }
  }
  
  // Add status to each bill
  return currentBills.map(bill => {
    // For "auto" status, check if the due date has passed, then mark as "paid"
    if (bill.status === "auto") {
      const dueDay = parseInt(bill.dueDay);
      let billDate = new Date(today.getFullYear(), today.getMonth(), dueDay);
      
      // If today is past the due date, auto-pay has kicked in
      if (billDate <= today) {
        return { ...bill, status: "paid" };
      }
      // Otherwise keep it as auto
      return bill;
    }
    
    // Use the existing status from the database if already set
    if (bill.status === "paid" || bill.status === "skip") {
      return bill;
    }
    
    // Otherwise, determine status based on due date
    const dueDay = parseInt(bill.dueDay);
    let billDate = new Date(today.getFullYear(), today.getMonth(), dueDay);
    
    let status: BillStatus;
    
    // If the bill is due in the future, mark as upcoming
    if (billDate > today) {
      status = "upcoming";
    } else {
      // If the bill is past due, mark as due
      status = "due";
    }
    
    return { ...bill, status };
  });
}

export function getEstimatedDraft(): { total: number; baseAmount: number; cushionAmount: number } {
  // Get payment strategy and billing cushion from settings
  const { paymentStrategy, payFrequency, lastPayDate, billingCushion = "2" } = settings;
  const cushionPercentage = parseFloat(billingCushion) / 100;
  
  let baseAmount = 0;
  
  if (paymentStrategy === "Proactive") {
    // For Proactive: Split monthly bills evenly across pay periods
    // First, calculate the total of all bills due in the next 30 days
    const today = getCurrentDate();
    const thirtyDaysLater = new Date(today);
    thirtyDaysLater.setDate(today.getDate() + 30);
    
    // Get all bills that are due in the next 30 days
    const billsInNextThirtyDays = bills.filter(bill => {
      if (bill.hidden) return false;
      
      // Special handling for annual bills
      if (bill.isAnnual) {
        // Only include annual bills if they're due in the current or next month
        if (!bill.annualMonth || !bill.annualYear) return false;
        
        const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
        const annualYear = parseInt(bill.annualYear);
        const annualDueDay = parseInt(bill.dueDay);
        
        // Create the exact annual due date
        const annualDueDate = new Date(annualYear, annualMonth, annualDueDay);
        
        // Only include if due date is within the next 30 days
        return (annualDueDate >= today && annualDueDate <= thirtyDaysLater);
      }
      
      // Regular monthly bills
      const dueDay = parseInt(bill.dueDay);
      const currentMonthDate = new Date(today.getFullYear(), today.getMonth(), dueDay);
      const nextMonthDate = new Date(today.getFullYear(), today.getMonth() + 1, dueDay);
      
      return (currentMonthDate >= today && currentMonthDate <= thirtyDaysLater) || 
             (nextMonthDate >= today && nextMonthDate <= thirtyDaysLater);
    });
    
    // Calculate total amount for these bills
    const totalAmount = billsInNextThirtyDays.reduce((sum, bill) => {
      const baseAmount = Number(bill.amount || 0);
      const additionalAmount = Number(bill.additionalPayment || 0);
      return sum + baseAmount + additionalAmount;
    }, 0);
    
    // Determine how many pay periods in a month
    let periodsPerMonth = 1;
    switch (payFrequency) {
      case "Weekly": periodsPerMonth = 4; break;
      case "Bi-Weekly": periodsPerMonth = 2; break;
      case "1st & 15th": periodsPerMonth = 2; break;
      case "Monthly": periodsPerMonth = 1; break;
    }
    
    // Calculate the base amount - divide total by number of pay periods
    baseAmount = totalAmount / periodsPerMonth;
  } else {
    // For Reactive: Only include bills due in the current pay period
    const currentBills = getCurrentPeriodBills();
    baseAmount = currentBills
      .reduce((sum, bill) => {
        const baseAmount = Number(bill.amount || 0);
        const additionalAmount = Number(bill.additionalPayment || 0);
        return sum + baseAmount + additionalAmount;
      }, 0);
  }
  
  // Calculate cushion amount
  const cushionAmount = baseAmount * cushionPercentage;
  
  // Calculate total with cushion
  const total = baseAmount + cushionAmount;
  
  return { total, baseAmount, cushionAmount };
}

export function getMonthlyTotal(): number {
  const today = getCurrentDate();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();
  const { billingCushion = "2" } = settings;
  const cushionPercentage = parseFloat(billingCushion) / 100;

  // Get all eligible bills for this month (regardless of paid/skip status)
  const monthlyBills = bills.filter(bill => {
    // Skip hidden bills
    if (bill.hidden) return false;
    
    // Handle annual bills
    if (bill.isAnnual) {
      if (!bill.annualMonth || !bill.annualYear) return false;
      
      const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
      const annualYear = parseInt(bill.annualYear);
      
      // Only include annual bills that are due in the current month/year
      return (annualMonth === currentMonth && annualYear === currentYear);
    }
    
    // Include all regular monthly bills
    return true;
  });
  
  // Calculate base total of all bills (regardless of status)
  const baseTotal = monthlyBills
    .reduce((sum, bill) => {
      const baseAmount = Number(bill.amount || 0);
      const additionalAmount = Number(bill.additionalPayment || 0);
      return sum + baseAmount + additionalAmount;
    }, 0);
  
  // Add the billing cushion to the total
  const cushionAmount = baseTotal * cushionPercentage;
  
  // Return total with cushion
  return baseTotal + cushionAmount;
}

export function getActiveBillsCount(): number {
  return bills.filter(bill => !bill.hidden).length;
}

export function getDueSoonCount(): number {
  const today = getCurrentDate();
  const nextWeek = new Date(today);
  nextWeek.setDate(today.getDate() + 7);
  
  return bills.filter(bill => {
    if (bill.hidden) return false;
    
    // Handle annual bills
    if (bill.isAnnual) {
      if (!bill.annualMonth || !bill.annualYear) return false;
      
      const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
      const annualYear = parseInt(bill.annualYear);
      const annualDueDay = parseInt(bill.dueDay);
      
      if (isNaN(annualDueDay)) return false;
      
      // Create the exact annual due date
      const annualDueDate = new Date(annualYear, annualMonth, annualDueDay);
      
      // Only include if due date is within the next week
      return (annualDueDate >= today && annualDueDate <= nextWeek);
    }
    
    // Handle regular monthly bills
    const dueDay = parseInt(bill.dueDay);
    if (isNaN(dueDay)) return false;
    
    let billDate = new Date(today.getFullYear(), today.getMonth(), dueDay);
    
    // If the due day has passed this month, check next month
    if (billDate < today) {
      billDate.setMonth(billDate.getMonth() + 1);
    }
    
    return billDate <= nextWeek;
  }).length;
}