// Sound utilities for the app

// This function creates and plays a welcoming sound
export function playWelcomeSound() {
  try {
    // Create audio context
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    
    const audioCtx = new AudioContext();
    const masterGain = audioCtx.createGain();
    masterGain.gain.value = 0.3; // Lower overall volume
    masterGain.connect(audioCtx.destination);
    
    // Create a pleasing chord progression
    const playNote = (frequency: number, startTime: number, duration: number, type: OscillatorType = 'sine') => {
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.type = type;
      oscillator.frequency.value = frequency;
      
      // Set up fade in/out for a smooth sound
      gainNode.gain.setValueAtTime(0, startTime);
      gainNode.gain.linearRampToValueAtTime(0.2, startTime + 0.05);
      gainNode.gain.setValueAtTime(0.2, startTime + duration - 0.05);
      gainNode.gain.linearRampToValueAtTime(0, startTime + duration);
      
      // Connect and schedule
      oscillator.connect(gainNode);
      gainNode.connect(masterGain);
      
      oscillator.start(startTime);
      oscillator.stop(startTime + duration);
    };
    
    // Play a pleasant chord progression
    const now = audioCtx.currentTime;
    
    // First chord - Major (harmony)
    playNote(261.63, now, 0.8);       // C4
    playNote(329.63, now + 0.1, 0.7); // E4
    playNote(392.00, now + 0.2, 0.6); // G4
    
    // Second note - higher
    playNote(523.25, now + 0.5, 0.5); // C5
    
    // Add a subtle background harmony
    playNote(196.00, now, 1.0, 'sine'); // G3 (lower harmony)
    
    // Add a very subtle white noise in the background for texture
    const bufferSize = 2 * audioCtx.sampleRate;
    const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 0.03 - 0.015; // Very quiet white noise
    }
    
    const whiteNoise = audioCtx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    
    const noiseGain = audioCtx.createGain();
    noiseGain.gain.value = 0.006; // Very quiet
    
    whiteNoise.connect(noiseGain);
    noiseGain.connect(masterGain);
    
    whiteNoise.start();
    whiteNoise.stop(now + 1.0);
    
  } catch (e) {
    console.log("Could not play welcome sound", e);
  }
}

// This function creates and plays a goodbye chime
export function playLogoutSound() {
  try {
    // Create audio context
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    
    const audioCtx = new AudioContext();
    const masterGain = audioCtx.createGain();
    masterGain.gain.value = 0.35; // Slightly louder than welcome sound
    masterGain.connect(audioCtx.destination);
    
    // Create a pleasing chord progression
    const playNote = (frequency: number, startTime: number, duration: number, type: OscillatorType = 'sine') => {
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.type = type;
      oscillator.frequency.value = frequency;
      
      // Set up fade in/out for a smooth sound
      gainNode.gain.setValueAtTime(0, startTime);
      gainNode.gain.linearRampToValueAtTime(0.25, startTime + 0.05);
      gainNode.gain.setValueAtTime(0.25, startTime + duration - 0.05);
      gainNode.gain.linearRampToValueAtTime(0, startTime + duration);
      
      // Connect and schedule
      oscillator.connect(gainNode);
      gainNode.connect(masterGain);
      
      oscillator.start(startTime);
      oscillator.stop(startTime + duration);
    };
    
    // Play a pleasant chord progression for goodbye (different from welcome)
    const now = audioCtx.currentTime;
    
    // Goodbye chord - descending notes with a harmonious finish
    playNote(523.25, now, 0.6);         // C5 (start higher)
    playNote(392.00, now + 0.2, 0.6);   // G4 (middle)
    playNote(329.63, now + 0.4, 0.6);   // E4 (lower)
    playNote(261.63, now + 0.6, 0.9);   // C4 (final note, longer duration)
    
    // Add harmonies
    playNote(784.00, now + 0.1, 0.4);   // G5 (high harmony)
    playNote(659.26, now + 0.3, 0.4);   // E5 (mid-high harmony)
    playNote(523.25, now + 0.5, 0.4);   // C5 (mid harmony)
    
    // Add a subtle background pad
    playNote(196.00, now, 1.5, 'sine'); // G3 (low pad note)
    playNote(130.81, now + 0.5, 1.0);   // C3 (final bass note)
    
  } catch (e) {
    console.log("Could not play logout sound", e);
  }
}

// This function will speak a message using the selected voice
export function speakMessage(message: string) {
  if (typeof window === 'undefined' || !window.speechSynthesis) return;
  
  try {
    const synth = window.speechSynthesis;
    const voices = synth.getVoices();
    
    // Get platform info from localStorage
    const platformType = localStorage.getItem('platformType') || 'desktop';
    
    // IMPORTANT: We want to ensure the welcome and logout voices are ALWAYS the same
    // So we prioritize the platform-specific voice first, then the general voice
    const platformVoiceName = localStorage.getItem(`selectedVoice_${platformType}`);
    const savedVoiceName = platformVoiceName || localStorage.getItem('selectedVoice');
    
    let voice = null;
    
    // Find the specific voice saved by the user
    if (savedVoiceName) {
      voice = voices.find(v => v.name === savedVoiceName);
      console.log(`Using previously selected voice: "${savedVoiceName}"`);
    }
    
    // If no saved voice, prioritize Nigerian or British voices
    if (!voice) {
      // Check if desktop or mobile
      const isMobile = platformType !== 'desktop';
      
      if (isMobile) {
        console.log("Using mobile-specific voice priorities");
        // Mobile voice priorities - Karen is recommended for mobile
        const mobilePriorityVoices = [
          'Karen', 'Samantha', 'Moira', 'Tessa', 
          'Google US English Female', 'Google UK English Female'
        ];
        
        for (const voiceName of mobilePriorityVoices) {
          voice = voices.find(v => v.name.includes(voiceName));
          if (voice) {
            console.log("Using mobile priority voice:", voice.name);
            // Save this voice preference for consistency
            if (typeof localStorage !== 'undefined') {
              localStorage.setItem('selectedVoice', voice.name);
              localStorage.setItem(`selectedVoice_${platformType}`, voice.name);
            }
            break;
          }
        }
      } else {
        console.log("Using desktop-specific voice priorities");
        // Desktop voice priorities - Ezinne (Nigerian) is preferred
        // Make this extremely specific to ensure ONLY Ezinne (female Nigerian voice) is used
        let ezinneVoice = voices.find(v => 
          v.name === 'Ezinne' || 
          v.name === 'Microsoft Ezinne Online' || 
          v.name === 'Microsoft Ezinne'
        );
        
        // If Ezinne is found, use it immediately
        if (ezinneVoice) {
          voice = ezinneVoice;
          console.log("Using Ezinne voice (primary choice):", voice.name);
          // Save this voice preference for consistency
          if (typeof localStorage !== 'undefined') {
            localStorage.setItem('selectedVoice', voice.name);
            localStorage.setItem(`selectedVoice_${platformType}`, voice.name);
          }
        } 
        // If Ezinne not found, try the fallback female voices
        else {
          const desktopPriorityVoices = [
            'Sonia', 'Microsoft Sonia Online',
            'Clara', 'Microsoft Clara Online',
            'Susan', 'Microsoft Susan Online'
          ];
          
          for (const voiceName of desktopPriorityVoices) {
            voice = voices.find(v => v.name.includes(voiceName));
            if (voice) {
              console.log("Using desktop priority voice:", voice.name);
              // Save this voice preference for consistency
              if (typeof localStorage !== 'undefined') {
                localStorage.setItem('selectedVoice', voice.name);
                localStorage.setItem(`selectedVoice_${platformType}`, voice.name);
              }
              break;
            }
          }
        }
      }
    }
    
    // Last resort: just pick any English voice
    if (!voice) {
      voice = voices.find(v => v.lang && v.lang.startsWith('en'));
      if (voice && typeof localStorage !== 'undefined') {
        console.log("Using fallback English voice:", voice.name);
        // Save the fallback voice for consistency
        localStorage.setItem('selectedVoice', voice.name);
        localStorage.setItem(`selectedVoice_${platformType}`, voice.name);
      }
    }
    
    // Create and speak the utterance
    const utterance = new SpeechSynthesisUtterance(message);
    if (voice) {
      utterance.voice = voice;
    }
    utterance.rate = 0.88;
    utterance.pitch = 1.1;
    utterance.volume = 1.0;
    
    synth.speak(utterance);
    
    return true;
  } catch (e) {
    console.log("Failed to speak message:", e);
    return false;
  }
}

// This function plays the logout sound and speaks the logout message
export function playLogoutSoundAndMessage() {
  // To ensure we're using the EXACT same voice and voice detection code as in LogoutSuccessPage
  // Let's use the same approach for getting the voice
  
  // First play the sound
  playLogoutSound();
  
  // Get the stored voice - using the EXACT same method as in all other parts of the app
  const platformType = localStorage.getItem('platformType') || 'desktop';
  const savedVoiceName = localStorage.getItem(`selectedVoice_${platformType}`) || localStorage.getItem('selectedVoice');
  
  // Debug info
  console.log("Playing logout voice message using voice:", savedVoiceName);
  
  // Small delay before speaking to let the chime play first
  setTimeout(() => {
    // Make sure we have a synth
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
  
    // Create utterance with consistent logout message text
    const utterance = new SpeechSynthesisUtterance(
      "Thank you for investing in you, until next time. Good day."
    );
    
    // Set the same voice used during login if we have it
    if (savedVoiceName) {
      const voices = window.speechSynthesis.getVoices();
      
      // IMPORTANT: Using exact match only for Microsoft Ezinne to prevent using male Nigerian voice
      // This is the critical fix to prevent switching to male voice on logout
      if (savedVoiceName.includes("Ezinne")) {
        const ezinneVoice = voices.find(v => 
          v.name === 'Microsoft Ezinne Online (Natural) - English (Nigeria)' ||
          v.name === 'Microsoft Ezinne Online - English (Nigeria)' ||
          v.name === 'Microsoft Ezinne - English (Nigeria)' ||
          v.name === 'Ezinne'
        );
        
        if (ezinneVoice) {
          console.log("Using exact Ezinne voice match for logout:", ezinneVoice.name);
          utterance.voice = ezinneVoice;
        }
      } else {
        // For other voices, use standard name matching
        const voice = voices.find(v => v.name === savedVoiceName);
        if (voice) {
          console.log("Using saved voice for logout:", voice.name);
          utterance.voice = voice;
        }
      }
    }
    
    // Set other properties and speak
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    
    window.speechSynthesis.speak(utterance);
  }, 800);
}