// This function uses the reference pay date to calculate upcoming pay dates
export function getPayDates(lastPayDate: string, frequency: string, count = 10): Date[] {
  const dates: Date[] = [];
  
  // First, standardize the reference pay date format to avoid date offset issues
  const refPayDate = new Date(lastPayDate);
  refPayDate.setHours(0, 0, 0, 0);
  
  // Start with the reference pay date itself
  let current = new Date(refPayDate);
  
  // Include the reference pay date as the first date if it's today or in the future
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  if (current >= today) {
    dates.push(new Date(current));
  }
  
  // Generate future pay dates based on the frequency
  for (let i = 0; i < count; i++) {
    // Apply the frequency adjustment to get the next pay date
    switch (frequency) {
      case "Weekly": 
        current.setDate(current.getDate() + 7); 
        break;
      case "Bi-Weekly": 
        current.setDate(current.getDate() + 14); 
        break;
      case "Monthly": 
        current.setMonth(current.getMonth() + 1); 
        break;
      case "Semi-Monthly": // Handle 1st & 15th (renamed to Semi-Monthly)
        if (current.getDate() < 15) {
          current.setDate(15);
        } else {
          current.setMonth(current.getMonth() + 1);
          current.setDate(1);
        }
        break;
    }
    
    // Add the calculated date to our array
    dates.push(new Date(current));
  }
  
  // Filter out any past dates before returning
  const filteredDates = dates.filter(date => date >= today);
  
  // Return at least up to the requested count or all future dates we have
  return filteredDates.slice(0, count);
}

export function normalizeDate(date: Date): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + 1);
  d.setHours(0, 0, 0, 0);
  return d;
}

export function getBillsInRange(bills: any[], fromDate: Date, toDate: Date): any[] {
  fromDate = normalizeDate(fromDate);
  toDate = normalizeDate(toDate);

  return bills.filter(bill => {
    if (!bill || typeof bill !== 'object') return false;
    if (bill.hidden) return false;

    const hasValidDueDay = bill.dueDay !== undefined && !isNaN(parseInt(bill.dueDay));
    if (!hasValidDueDay) return false;

    // Handle annual bills specially
    if (bill.isAnnual) {
      // Only include annual bills if their specific month and year matches the current period
      if (!bill.annualMonth || !bill.annualYear) return false;
      
      const annualMonth = parseInt(bill.annualMonth) - 1; // Convert 1-12 to 0-11
      const annualYear = parseInt(bill.annualYear);
      const dueDay = parseInt(bill.dueDay);
      
      // Create the exact annual due date
      const annualDueDate = new Date(annualYear, annualMonth, dueDay);
      
      // Only include this bill if its annual due date falls within the specified range
      return annualDueDate >= fromDate && annualDueDate < toDate;
    }

    // Handle regular monthly bills
    const dueDay = parseInt(bill.dueDay);
    
    // Create dates for both the start month and the next month(s)
    // This ensures we catch bills due in this period even if they cross month boundaries
    const startMonthYear = fromDate.getFullYear();
    const startMonth = fromDate.getMonth();
    
    const endMonthYear = toDate.getFullYear();
    const endMonth = toDate.getMonth();
    
    // Create a date object for this bill in the starting month
    const billDateStart = new Date(startMonthYear, startMonth, dueDay);
    
    // Check if the bill date is within the range
    if (billDateStart >= fromDate && billDateStart < toDate) {
      return true;
    }
    
    // If the period spans multiple months, check if the bill falls due in later months
    if (endMonthYear > startMonthYear || (endMonthYear === startMonthYear && endMonth > startMonth)) {
      // Check each month in the range
      const monthDiff = (endMonthYear - startMonthYear) * 12 + (endMonth - startMonth);
      
      for (let i = 1; i <= monthDiff; i++) {
        const nextMonth = (startMonth + i) % 12;
        const nextYear = startMonthYear + Math.floor((startMonth + i) / 12);
        
        const billDateNext = new Date(nextYear, nextMonth, dueDay);
        
        if (billDateNext >= fromDate && billDateNext < toDate) {
          return true;
        }
      }
    }
    
    return false;
  });
}

export function getDaysUntil(date: Date): number {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const targetDate = new Date(date);
  targetDate.setHours(0, 0, 0, 0);
  
  const diffTime = targetDate.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function formatDateString(date: Date): string {
  return date.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });
}
