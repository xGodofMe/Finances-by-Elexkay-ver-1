import { Switch, Route } from "wouter";
import { queryClient, apiRequest } from "./lib/queryClient";
import { QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import Dashboard from "@/pages/Dashboard";
import BillManagement from "@/pages/BillManagement";
import SettingsPage from "@/pages/SettingsPage";
import HelpPage from "@/pages/HelpPage";
import AuthPage from "@/pages/auth-page";
import LogoutSuccessPage from "@/pages/LogoutSuccessPage";
import AdminPage from "@/pages/AdminPage";
import ProfilePage from "@/pages/ProfilePage";
import SuggestionsPage from "@/pages/SuggestionsPage";
import NotFound from "@/pages/not-found";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import TickerTape from "@/components/TickerTape";
import NewsTickerTape from "@/components/NewsTickerTape";
import ScrollToTop from "@/components/ScrollToTop";
import YouTubePlayer from "@/components/YouTubePlayer";
import MusicPlayer from "@/components/MusicPlayer";
import { useEffect, useState, useRef } from "react";
import { initializeStore } from "@/lib/store";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { Loader2, Clock, RefreshCw } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/manage" component={BillManagement} />
      <ProtectedRoute path="/settings" component={SettingsPage} />
      <ProtectedRoute path="/help" component={HelpPage} />
      <ProtectedRoute path="/admin" component={AdminPage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/suggestions" component={SuggestionsPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/logout-success" component={LogoutSuccessPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Create ticker components that are only shown when authenticated
function AuthenticatedTickerTape() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const refreshIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Market status indicator removed as requested
  
  // Define empty function to preserve API calls structure
  const checkMarketStatus = async () => {
    // This function is now empty as market status indicator is removed
  };
  
  // Function to refresh both stocks and news
  const refreshMarketData = async () => {
    if (isRefreshing) return;
    
    try {
      setIsRefreshing(true);
      
      // Update stocks
      await apiRequest("POST", "/api/stocks/update");
      queryClient.invalidateQueries({ queryKey: ["/api/stocks"] });
      
      // Update news
      await apiRequest("POST", "/api/news/refresh");
      queryClient.invalidateQueries({ queryKey: ["/api/news"] });
      
      // Update the timestamp
      setLastUpdated(new Date());
      
    } catch (error) {
      toast({
        title: "Update failed",
        description: error instanceof Error ? error.message : "Failed to update market data",
        variant: "destructive",
      });
    } finally {
      setIsRefreshing(false);
    }
  };
  
  // Set up auto-refresh every 5 minutes
  useEffect(() => {
    if (user) {
      // Initial fetch
      refreshMarketData();
      
      // Set up interval
      refreshIntervalRef.current = setInterval(() => {
        refreshMarketData();
      }, 5 * 60 * 1000); // Every 5 minutes
      
      return () => {
        if (refreshIntervalRef.current) {
          clearInterval(refreshIntervalRef.current);
        }
      };
    }
  }, [user]);
  
  if (!user) return null;
  
  // Shared market data controls
  const marketControls = (
    <div className="bg-black/40 backdrop-blur-sm pl-1 sm:pl-2 flex gap-1 sm:gap-2 items-center rounded-md">
      {lastUpdated && (
        <div className="hidden sm:flex items-center text-xs text-white">
          <Clock className="h-3 w-3 mr-1" />
          <span>Updated: {format(lastUpdated, 'h:mm a')}</span>
        </div>
      )}
      <button 
        className="h-6 w-6 flex items-center justify-center bg-blue-500/30 border border-blue-500/50 hover:bg-blue-500/50 rounded-full text-white disabled:opacity-50"
        onClick={refreshMarketData}
        disabled={isRefreshing}
        aria-label="Refresh market data"
      >
        <RefreshCw className={`h-3 w-3 ${isRefreshing ? 'animate-spin' : ''}`} />
      </button>
    </div>
  );
  
  return (
    <div className="fixed bottom-0 left-0 right-0 z-10">
      <div className="relative">
        <NewsTickerTape showControls={false} />
        <div className="absolute right-2 sm:right-3 top-1/2 transform -translate-y-1/2 z-10">
          {marketControls}
        </div>
      </div>
      <TickerTape showControls={false} />
    </div>
  );
}

// Component for background music on authenticated pages
function AuthenticatedMusicPlayer() {
  const { user } = useAuth();
  const [useMp3Player, setUseMp3Player] = useState(false);
  const [mp3FilePath, setMp3FilePath] = useState<string | null>(null);
  
  // Using cozy jazz with fireplace sounds as requested
  const videoId = "D31mPjC2YSE"; // Ethereal Jazz & Cozy Fireplace: London Apartment Ambience
  
  // We're using YouTube directly since this is the specific style requested
  useEffect(() => {
    // Force using YouTube player - skip MP3 player check
    console.log("Using specific cozy jazz & apartment ambience video for background music");
    setUseMp3Player(false);
  }, []);
  
  if (!user) return null;
  
  // Render MP3 player if file exists, otherwise use YouTube player
  if (useMp3Player && mp3FilePath) {
    return <MusicPlayer audioSrc={mp3FilePath} autoplay={true} />;
  } else {
    // Pass the specific video ID for cozy jazz apartment ambience
    return <YouTubePlayer videoId={videoId} autoplay={true} />;
  }
}

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [showFirstTimeArrow, setShowFirstTimeArrow] = useState(false);

  useEffect(() => {
    // Initialize the store when the app loads
    const init = async () => {
      try {
        await initializeStore();
      } catch (error) {
        console.error("Failed to initialize app:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    init();
  }, []);

  // Function to pass to Dashboard to update the first-time arrow state
  const updateFirstTimeArrow = (show: boolean) => {
    setShowFirstTimeArrow(show);
  };

  // Create custom Dashboard component that gets the updateFirstTimeArrow function
  const DashboardWithArrow = () => {
    return <Dashboard updateFirstTimeArrow={updateFirstTimeArrow} />;
  };

  // Override the default Dashboard in Router
  const CustomRouter = () => {
    return (
      <Switch>
        <ProtectedRoute path="/" component={DashboardWithArrow} />
        <ProtectedRoute path="/manage" component={BillManagement} />
        <ProtectedRoute path="/settings" component={SettingsPage} />
        <ProtectedRoute path="/help" component={HelpPage} />
        <ProtectedRoute path="/admin" component={AdminPage} />
        <ProtectedRoute path="/profile" component={ProfilePage} />
        <ProtectedRoute path="/suggestions" component={SuggestionsPage} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/logout-success" component={LogoutSuccessPage} />
        <Route component={NotFound} />
      </Switch>
    );
  };

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="min-h-screen flex flex-col text-white">
          <Header showFirstTimeArrow={showFirstTimeArrow} />
          <main className="flex-grow">
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="h-8 w-8 animate-spin text-primary mr-2" />
                <div className="text-xl">Loading...</div>
              </div>
            ) : (
              <CustomRouter />
            )}
          </main>
          <AuthenticatedTickerTape />
          <AuthenticatedMusicPlayer />
          <Footer />
          <ScrollToTop />
        </div>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
