export default function Footer() {
  return (
    <footer className="backdrop-blur-md bg-black/30 text-gray-400 text-sm p-4 md:p-6 border-t border-white/10">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="mb-2 md:mb-0">
          <span>© {new Date().getFullYear()} Finances by Elexkay™. All rights reserved.</span>
        </div>
        <div>
          <button className="text-white hover:text-blue-300 transition duration-200">Help</button>
          <span className="mx-2">|</span>
          <button className="text-white hover:text-blue-300 transition duration-200">Privacy</button>
          <span className="mx-2">|</span>
          <button className="text-white hover:text-blue-300 transition duration-200">Terms</button>
        </div>
      </div>
    </footer>
  );
}
