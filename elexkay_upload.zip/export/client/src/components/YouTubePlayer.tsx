import { useEffect, useRef, useState } from 'react';

interface YouTubePlayerProps {
  playlistId?: string;
  videoId?: string;
  autoplay?: boolean;
}

declare global {
  interface Window {
    onYouTubeIframeAPIReady: () => void;
    YT: any;
  }
}

// Array of fallback video IDs that are likely to work in most regions
// These are cozy apartment ambience videos with jazz saxophone and fireplace sounds
const FALLBACK_VIDEO_IDS = [
  'D31mPjC2YSE', // Ethereal Jazz & Cozy Fireplace: London Apartment Ambience
  'bFoGPm3_zww', // Cozy Jazz & Bossa Nova With Fireplace
  'JyO5UHk7m-g', // Cozy Autumn Jazz with Fireplace Crackling
  'ekFMBVD9Z30', // Jazz Saxophone & Rain Sounds
  '54XgfjTt0C0', // Cozy Coffee Shop with Jazz Music
  'mv4r8Y7qc-o', // Apartment in Paris: Jazz Music with Relaxing Rain Sounds
];

export default function YouTubePlayer({ 
  playlistId = 'PLOHoVaTp8R7dfrJW5TOb6dfuWijCqYeBH', // Default to a financial education playlist
  videoId,
  autoplay = true,
}: YouTubePlayerProps) {
  const playerRef = useRef<any>(null);
  const playerContainerRef = useRef<HTMLDivElement>(null);
  const [isMuted, setIsMuted] = useState(true); // Start muted by default so we can unmute after login
  const [isPlayerReady, setIsPlayerReady] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [playerEnabled, setPlayerEnabled] = useState(false); // Track if player should be enabled
  const [currentVideoId, setCurrentVideoId] = useState<string>(videoId || FALLBACK_VIDEO_IDS[0]);
  const [fallbackIndex, setFallbackIndex] = useState(0);
  
  // Track if we've attempted to unmute player after user interaction
  const hasAttemptedUnmute = useRef(false);
  
  // Special function to try and force autoplay by simulating user interaction with the YouTube iframe
  useEffect(() => {
    if (isPlayerReady) {
      // Try to find the YouTube iframe that's hidden
      setTimeout(() => {
        const iframe = document.querySelector('iframe[src*="youtube"]');
        if (iframe) {
          console.log("Found YouTube player iframe on login success, triggering user interaction");
          
          try {
            // Focus and click the iframe to trigger user interaction
            if (iframe instanceof HTMLElement) {
              iframe.focus();
            }
            
            // Try to click any button within the iframe
            console.log("Triggering YouTube player button click to start music");
            
            // We can't directly click inside the iframe due to cross-origin restrictions,
            // so we'll click our own control button to activate the player
            const muteButton = document.querySelector('[title="Unmute background music"]');
            if (muteButton instanceof HTMLElement) {
              muteButton.click();
            }
          } catch (e) {
            console.error("Failed to force YouTube player interaction:", e);
          }
        }
      }, 1500);
    }
  }, [isPlayerReady]);
  
  // Add a listener for user interaction to enable autoplay
  useEffect(() => {
    // Function to enable player after user interaction (required by browsers)
    const enablePlayerAfterInteraction = () => {
      if (hasAttemptedUnmute.current) return; // Only try once

      setPlayerEnabled(true);
      console.log("User interaction detected, enabling YouTube player");
      
      // Unmute player if it exists
      if (playerRef.current) {
        try {
          console.log("Attempting to play and unmute after user interaction");
          
          if (typeof playerRef.current.playVideo === 'function') {
            playerRef.current.playVideo();
          }
          
          setTimeout(() => {
            try {
              if (typeof playerRef.current.unMute === 'function' && 
                  typeof playerRef.current.setVolume === 'function') {
                
                playerRef.current.unMute();
                playerRef.current.setVolume(25);
                setIsMuted(false);
                console.log("Player unmuted after user interaction");
              } else {
                // If methods aren't available, just update UI state
                console.warn("YouTube player methods not available");
                setIsMuted(false);
              }
            } catch (innerError) {
              console.error("Failed to set volume or unmute:", innerError);
              setIsMuted(false); // Still update UI
            }
          }, 500);
          
          hasAttemptedUnmute.current = true;
        } catch (error) {
          console.error("Failed to unmute after user interaction:", error);
        }
      }
      
      // Remove the listeners after successful interaction
      document.removeEventListener('click', enablePlayerAfterInteraction);
      document.removeEventListener('keydown', enablePlayerAfterInteraction);
    };
    
    // Add interaction listeners for the entire document
    document.addEventListener('click', enablePlayerAfterInteraction);
    document.addEventListener('keydown', enablePlayerAfterInteraction);
    
    return () => {
      // Clean up listeners on unmount
      document.removeEventListener('click', enablePlayerAfterInteraction);
      document.removeEventListener('keydown', enablePlayerAfterInteraction);
    };
  }, []);

  useEffect(() => {
    console.log("YouTubePlayer initialized:", videoId ? `videoId: ${videoId}` : `playlistId: ${playlistId}`);
    
    // Function to load the YouTube API script
    const loadYouTubeAPI = () => {
      // Check if the script is already loaded
      if (window.YT && window.YT.Player) {
        console.log("YouTube API already loaded");
        initializePlayer();
        return;
      }
      
      console.log("Loading YouTube API...");
      
      // Create the script element
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      
      // Add error handling
      tag.onerror = () => {
        console.error("Failed to load YouTube API script");
        setLoadError(true);
      };
      
      // Set up callback for when API is ready
      window.onYouTubeIframeAPIReady = () => {
        console.log("YouTube API loaded successfully");
        initializePlayer();
      };
      
      // Add the script to the document
      const firstScriptTag = document.getElementsByTagName('script')[0];
      if (firstScriptTag && firstScriptTag.parentNode) {
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
      } else {
        document.head.appendChild(tag);
      }
      
      // Set a timeout to detect if the API fails to load
      setTimeout(() => {
        if (!window.YT || !window.YT.Player) {
          console.error("YouTube API failed to load after timeout");
          setLoadError(true);
        }
      }, 5000); // 5 second timeout
    };
    
    // Function to initialize the YouTube player
    const initializePlayer = () => {
      if (!playerContainerRef.current) {
        console.error("Player container ref is not available");
        return;
      }
      
      // Make sure div is clear before creating player
      playerContainerRef.current.innerHTML = '';
      
      console.log("Initializing YouTube player...");
      
      try {
        // Create a background player using a direct video ID instead of a playlist
        // Using a popular lofi music video that should be accessible globally
        playerRef.current = new window.YT.Player(playerContainerRef.current, {
          height: '1',
          width: '1',
          videoId: currentVideoId, // Using the first fallback video ID
          playerVars: {
            autoplay: autoplay ? 1 : 0,
            controls: 0,
            mute: 1, // Start muted to comply with autoplay policies
            loop: 1,
            playsinline: 1,
            origin: window.location.origin
          },
          events: {
            'onReady': (event: any) => {
              console.log("YouTube player ready");
              setIsPlayerReady(true);
              // Check if player methods exist
              if (typeof event.target.setVolume === 'function') {
                event.target.setVolume(15); // Low volume (15%)
              }
              
              // Try to play and unmute (may be blocked by browser policies)
              if (autoplay) {
                try {
                  // Check if player methods exist before calling them
                  if (typeof event.target.playVideo === 'function') {
                    // Play video with a more aggressive approach
                    event.target.playVideo();
                  }
                  
                  // After a short delay, unmute the player and increase volume for better audibility
                  setTimeout(() => {
                    try {
                      if (typeof event.target.unMute === 'function' && 
                          typeof event.target.setVolume === 'function' &&
                          typeof event.target.getPlayerState === 'function' && 
                          typeof event.target.playVideo === 'function') {
                          
                        event.target.unMute();
                        event.target.setVolume(25); // Slightly higher volume (25%)
                        setIsMuted(false);
                        console.log("YouTube player unmuted - music should be playing now");
                        
                        // Force playback if it didn't start
                        if (event.target.getPlayerState() !== 1) { // 1 = playing
                          console.log("Forcing playback restart");
                          event.target.playVideo();
                        }
                      } else {
                        console.warn("Some YouTube player methods are not available");
                        setIsMuted(false); // Still update the UI
                      }
                    } catch (unmute_error) {
                      console.error("Failed to unmute:", unmute_error);
                      setIsMuted(false); // Still update the UI
                    }
                  }, 1500);
                  
                  console.log("Autoplay initialized");
                } catch (error) {
                  console.error("Autoplay initialization failed:", error);
                }
              }
            },
            'onError': (event: any) => {
              console.error("YouTube player error:", event.data);
              
              // If we get an error, try the next fallback video ID
              if (fallbackIndex < FALLBACK_VIDEO_IDS.length - 1) {
                const nextIndex = fallbackIndex + 1;
                const nextVideoId = FALLBACK_VIDEO_IDS[nextIndex];
                console.log(`Trying fallback video ID ${nextIndex}: ${nextVideoId}`);
                
                setFallbackIndex(nextIndex);
                setCurrentVideoId(nextVideoId);
                
                // If the player is initialized, load the next video
                if (playerRef.current) {
                  try {
                    if (typeof playerRef.current.loadVideoById === 'function') {
                      playerRef.current.loadVideoById(nextVideoId);
                    } else {
                      console.warn("loadVideoById method not available");
                      // Try to recreate the player with the new video ID
                      setTimeout(() => {
                        if (playerContainerRef.current) {
                          // Clear the container to force a new player creation
                          playerContainerRef.current.innerHTML = '';
                          // The effect will pick up the new currentVideoId
                        }
                      }, 500);
                    }
                  } catch (e) {
                    console.error("Failed to load fallback video:", e);
                  }
                }
              } else {
                // We've tried all fallback videos, show the error message
                setLoadError(true);
              }
            },
            'onStateChange': (event: any) => {
              try {
                // If video ends, replay it
                if (event.data === window.YT.PlayerState.ENDED && 
                    typeof event.target.playVideo === 'function') {
                  event.target.playVideo();
                }
              } catch (error) {
                console.error("Error in onStateChange handler:", error);
              }
            }
          }
        });
      } catch (error) {
        console.error("Error initializing YouTube player:", error);
        setLoadError(true);
      }
    };
    
    loadYouTubeAPI();
    
    // Cleanup
    return () => {
      if (playerRef.current) {
        try {
          playerRef.current.destroy();
          console.log("YouTube player destroyed");
        } catch (error) {
          console.error("Error destroying YouTube player:", error);
        }
      }
    };
  }, [videoId, playlistId, autoplay, currentVideoId, fallbackIndex]);
  
  const toggleMute = () => {
    if (!playerRef.current) return;
    
    try {
      // Check if these methods exist on the player object
      if (typeof playerRef.current.unMute === 'function' && 
          typeof playerRef.current.mute === 'function' &&
          typeof playerRef.current.setVolume === 'function') {
        
        if (isMuted) {
          playerRef.current.unMute();
          playerRef.current.setVolume(20); // Low volume for background music
        } else {
          playerRef.current.mute();
        }
        
        setIsMuted(!isMuted);
      } else {
        console.error("YouTube player methods not available (player may be in an error state)");
        // Still toggle the mute state for the UI
        setIsMuted(!isMuted);
      }
    } catch (error) {
      console.error("Error toggling mute state:", error);
      // Still toggle the mute state for the UI
      setIsMuted(!isMuted);
    }
  };
  
  // To provide a better user experience, show a link to open the music in a new tab
  const openYouTubePlayer = () => {
    window.open(`https://www.youtube.com/watch?v=${currentVideoId}`, '_blank');
  };
  
  return (
    <div className="fixed bottom-3 right-3 z-50">
      {loadError ? (
        <div className="text-xs bg-black/70 backdrop-blur-sm p-2 rounded-lg border border-slate-700 shadow-lg text-white max-w-[200px]">
          <p>Music player unavailable</p>
          <p className="text-xs text-gray-400 mb-2">Click below to play music in a new tab</p>
          <button 
            onClick={openYouTubePlayer}
            className="w-full py-1 px-2 bg-blue-600/80 hover:bg-blue-600 rounded text-white text-xs"
          >
            Open YouTube Music
          </button>
        </div>
      ) : (
        <div className="flex flex-col items-end gap-2">
          <button
            onClick={openYouTubePlayer}
            className="text-xs bg-black/60 backdrop-blur-sm px-2 py-1 rounded-md border border-slate-700 hover:bg-black/80"
            title="Open music in new tab"
          >
            Open Music
          </button>
          
          <button
            onClick={toggleMute}
            className="w-8 h-8 bg-black/60 backdrop-blur-sm rounded-full flex items-center justify-center border border-slate-700 shadow-lg hover:bg-black/80 transition-colors"
            title={isMuted ? "Unmute background music" : "Mute background music"}
            aria-label={isMuted ? "Unmute background music" : "Mute background music"}
          >
            {isMuted ? 
              <span className="text-lg">🔇</span> : 
              <span className="text-lg">🔊</span>
            }
          </button>
        </div>
      )}
      <div ref={playerContainerRef} className="hidden" />
    </div>
  );
}