import { useEffect, useRef } from "react";
import { ChevronUp, ChevronDown } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

interface Stock {
  id: number;
  symbol: string;
  companyName: string;
  price: string;
  change: string;
  changePercent: string;
  lastUpdated: string;
  hidden: boolean;
  isWatching: boolean;
}

interface TickerTapeProps {
  showControls?: boolean;
}

export default function TickerTape({ showControls = true }: TickerTapeProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Fetch stocks
  const { data: stocks = [], isLoading } = useQuery<Stock[]>({
    queryKey: ["/api/stocks"],
    staleTime: 60000, // 1 minute
  });

  const watchingStocks = stocks.filter((stock: Stock) => stock.isWatching);

  // Animation for ticker tape
  useEffect(() => {
    if (!containerRef.current || watchingStocks.length === 0) return;
    
    // Simple animation using CSS animation
    const tickerContent = containerRef.current.querySelector('.ticker-content') as HTMLElement;
    if (!tickerContent) return;
    
    // Make sure the content is wide enough to create a ticker effect
    tickerContent.style.animationDuration = `${Math.max(20, watchingStocks.length * 4)}s`;
  }, [watchingStocks]);

  if (isLoading) {
    return (
      <div className="bg-black/30 border-t border-white/[0.3] py-1 overflow-hidden">
        <div className="flex items-center gap-4">
          <Skeleton className="h-6 w-24" />
          <Skeleton className="h-6 w-24" />
          <Skeleton className="h-6 w-24" />
        </div>
      </div>
    );
  }

  if (watchingStocks.length === 0) {
    return null; // Don't show ticker if no stocks are being watched
  }

  return (
    <div 
      className="bg-black/30 border-t border-white/[0.3] py-1 overflow-hidden relative backdrop-blur-[10px]"
      ref={containerRef}
    >
      {/* Ticker controls are now managed in App.tsx */}
      
      {/* Ticker content */}
      <div 
        className="ticker-content flex items-center gap-2 sm:gap-6 whitespace-nowrap animate-ticker text-xs sm:text-sm"
        style={{
          // Create a continuous animation effect
          animationName: 'ticker',
          animationTimingFunction: 'linear',
          animationIterationCount: 'infinite',
          animationDuration: '20s',
          paddingRight: '48px' // Padding for the controls
        }}
      >
        {/* Duplicate items for seamless scrolling */}
        {[...watchingStocks, ...watchingStocks].map((stock, index) => (
          <div key={`${stock.id}-${index}`} className="flex items-center gap-1 font-medium">
            <span className="text-blue-200">{stock.symbol}</span>
            <span className="text-white">${stock.price}</span>
            <div className="flex items-center">
              {parseFloat(stock.change) >= 0 ? (
                <ChevronUp className="h-2.5 w-2.5 sm:h-3 sm:w-3 text-green-500" />
              ) : (
                <ChevronDown className="h-2.5 w-2.5 sm:h-3 sm:w-3 text-red-500" />
              )}
              <span 
                className={`px-2 py-0.5 rounded-full text-[10px] sm:text-xs ${
                  parseFloat(stock.change) >= 0 
                    ? "bg-emerald-600 text-white" 
                    : "bg-red-600 text-white"
                }`}
              >
                {stock.changePercent}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}