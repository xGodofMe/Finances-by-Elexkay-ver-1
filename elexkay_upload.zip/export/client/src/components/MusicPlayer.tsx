import { useEffect, useRef, useState } from 'react';

interface MusicPlayerProps {
  audioSrc: string;
  autoplay?: boolean;
}

export default function MusicPlayer({ 
  audioSrc,
  autoplay = true,
}: MusicPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.3); // 30% volume by default
  const [loadError, setLoadError] = useState(false);
  
  // Set up audio element
  useEffect(() => {
    // Create audio element if it doesn't exist
    if (!audioRef.current) {
      const audio = new Audio(audioSrc);
      audio.loop = true;
      audio.volume = volume;
      
      // Handle load errors
      audio.onerror = () => {
        console.error("Failed to load audio file:", audioSrc);
        setLoadError(true);
      };
      
      // Handle successful load
      audio.oncanplaythrough = () => {
        console.log("Audio file loaded successfully");
        
        // Try to play if autoplay is enabled
        if (autoplay) {
          playAudio(audio);
        }
      };
      
      audioRef.current = audio;
    }
    
    // Cleanup
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
        audioRef.current = null;
      }
    };
  }, [audioSrc, autoplay, volume]);
  
  // Function to handle autoplay with user interaction
  useEffect(() => {
    const handleUserInteraction = () => {
      if (audioRef.current && !isPlaying && autoplay) {
        playAudio(audioRef.current);
      }
    };
    
    // Add interaction listeners
    document.addEventListener('click', handleUserInteraction);
    document.addEventListener('keydown', handleUserInteraction);
    
    return () => {
      document.removeEventListener('click', handleUserInteraction);
      document.removeEventListener('keydown', handleUserInteraction);
    };
  }, [autoplay, isPlaying]);
  
  // Function to play audio with error handling
  const playAudio = (audio: HTMLAudioElement) => {
    const playPromise = audio.play();
    
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          console.log("Music playback started successfully");
          setIsPlaying(true);
        })
        .catch(error => {
          console.error("Playback failed:", error);
          // Most likely due to autoplay restrictions
          console.log("Autoplay prevented by browser policy - waiting for user interaction");
        });
    }
  };
  
  // Toggle play/pause
  const togglePlayback = () => {
    if (!audioRef.current) return;
    
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      playAudio(audioRef.current);
    }
  };
  
  // Toggle mute
  const toggleMute = () => {
    if (!audioRef.current) return;
    
    audioRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };
  
  return (
    <div className="fixed bottom-3 right-3 z-50">
      {loadError ? (
        <div className="text-xs bg-black/70 backdrop-blur-sm p-2 rounded-lg border border-slate-700 shadow-lg text-white">
          <p>Music player unavailable</p>
          <p className="text-xs text-gray-400">Audio file could not be loaded</p>
        </div>
      ) : (
        <div className="flex flex-col items-end gap-2">
          <button
            onClick={togglePlayback}
            className="text-xs bg-black/60 backdrop-blur-sm px-2 py-1 rounded-md border border-slate-700 hover:bg-black/80"
            title={isPlaying ? "Pause background music" : "Play background music"}
          >
            {isPlaying ? "Pause Music" : "Play Music"}
          </button>
          
          <button
            onClick={toggleMute}
            className="w-8 h-8 bg-black/60 backdrop-blur-sm rounded-full flex items-center justify-center border border-slate-700 shadow-lg hover:bg-black/80 transition-colors"
            title={isMuted ? "Unmute background music" : "Mute background music"}
            aria-label={isMuted ? "Unmute background music" : "Mute background music"}
          >
            {isMuted ? 
              <span className="text-lg">🔇</span> : 
              <span className="text-lg">🔊</span>
            }
          </button>
        </div>
      )}
    </div>
  );
}