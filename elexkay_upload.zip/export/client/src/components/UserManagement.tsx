import { useState, useEffect } from "react";
import { User } from "@shared/schema";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, UserCog, Trash2, ShieldAlert, ShieldCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";

export default function UserManagement() {
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [userToModify, setUserToModify] = useState<User | null>(null);
  const [isAdminChecked, setIsAdminChecked] = useState(false);
  
  // Define the type for query data to avoid TypeScript errors 
  interface QueryData {
    data: User[];
  }
  
  const { data: users = [], isLoading, error } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });
  
  // Handle error separately since onError isn't part of the options type
  useEffect(() => {
    if (error) {
      toast({
        title: "Error fetching users",
        description: error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      await apiRequest("DELETE", `/api/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      setUserToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error deleting user",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const updateAdminStatusMutation = useMutation({
    mutationFn: async ({ userId, isAdmin }: { userId: number; isAdmin: boolean }) => {
      await apiRequest("PUT", `/api/users/${userId}/admin`, { isAdmin });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Success",
        description: "User admin status updated successfully",
      });
      setUserToModify(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating admin status",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const confirmDelete = (user: User) => {
    setUserToDelete(user);
  };
  
  const openAdminDialog = (user: User) => {
    setUserToModify(user);
    setIsAdminChecked(user.isAdmin || false);
  };
  
  const handleAdminStatusChange = () => {
    if (userToModify) {
      updateAdminStatusMutation.mutate({
        userId: userToModify.id,
        isAdmin: isAdminChecked,
      });
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center w-full p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!users || users.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCog size={20} />
            User Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">No users found.</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <UserCog size={20} />
            User Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map((user) => (
              <div 
                key={user.id} 
                className="flex items-center justify-between p-3 border rounded-lg"
              >
                <div className="flex items-center gap-2">
                  {user.isAdmin ? (
                    <ShieldAlert className="h-5 w-5 text-amber-500" />
                  ) : (
                    <ShieldCheck className="h-5 w-5 text-green-500" />
                  )}
                  <span className="font-medium">{user.username}</span>
                  {user.isAdmin && <Badge variant="outline">Admin</Badge>}
                  {user.id === currentUser?.id && <Badge variant="secondary">You</Badge>}
                </div>
                
                <div className="flex items-center gap-2">
                  {/* Don't allow changing your own admin status */}
                  {currentUser?.isAdmin && user.id !== currentUser.id && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openAdminDialog(user)}
                    >
                      Admin Rights
                    </Button>
                  )}
                  
                  {/* Allow admins to delete any user, regular users can only delete themselves */}
                  {(currentUser?.isAdmin || user.id === currentUser?.id) && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => confirmDelete(user)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={!!userToDelete} onOpenChange={(open) => !open && setUserToDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Account Deletion</DialogTitle>
            <DialogDescription>
              {userToDelete?.id === currentUser?.id 
                ? "Are you sure you want to delete your account? This action cannot be undone."
                : `Are you sure you want to delete the account "${userToDelete?.username}"? This action cannot be undone.`
              }
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setUserToDelete(null)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => userToDelete && deleteUserMutation.mutate(userToDelete.id)}
              disabled={deleteUserMutation.isPending}
            >
              {deleteUserMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Account"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Admin Rights Dialog */}
      <Dialog open={!!userToModify} onOpenChange={(open) => !open && setUserToModify(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Manage Admin Rights</DialogTitle>
            <DialogDescription>
              Update admin privileges for user "{userToModify?.username}"
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center space-x-2 py-4">
            <Checkbox 
              id="admin-rights" 
              checked={isAdminChecked}
              onCheckedChange={(checked) => setIsAdminChecked(!!checked)}
            />
            <Label htmlFor="admin-rights">Admin access</Label>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setUserToModify(null)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleAdminStatusChange}
              disabled={updateAdminStatusMutation.isPending}
            >
              {updateAdminStatusMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}