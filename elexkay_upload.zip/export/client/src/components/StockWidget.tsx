import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, RefreshCw, Plus, Minus, ChevronUp, ChevronDown } from "lucide-react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Stock {
  id: number;
  symbol: string;
  companyName: string;
  price: string;
  change: string;
  changePercent: string;
  lastUpdated: string;
  hidden: boolean;
  isWatching: boolean;
}

interface StockSearchResult {
  symbol: string;
  companyName: string;
  price: string;
  change: string;
  changePercent: string;
}

export default function StockWidget() {
  const [isSearchDialogOpen, setIsSearchDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<StockSearchResult[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch stocks
  const { data: stocks = [], isLoading } = useQuery<Stock[]>({
    queryKey: ["/api/stocks"],
    staleTime: 60000, // 1 minute
  });

  const updateStocksMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/stocks/update");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stocks"] });
      toast({
        title: "Stocks updated",
        description: "Stock prices have been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update stocks",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addStockMutation = useMutation({
    mutationFn: async (symbol: string) => {
      return await apiRequest("POST", "/api/stocks/add", { symbol });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stocks"] });
      toast({
        title: "Stock added",
        description: "The stock has been added to your watchlist.",
      });
      setIsSearchDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add stock",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const removeStockMutation = useMutation({
    mutationFn: async (stockId: number) => {
      return await apiRequest("POST", `/api/stocks/remove/${stockId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stocks"] });
      toast({
        title: "Stock removed",
        description: "The stock has been removed from your watchlist.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to remove stock",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      const result = await apiRequest("GET", `/api/stocks/search?query=${encodeURIComponent(searchQuery)}`);
      setSearchResults(result);
    } catch (error) {
      toast({
        title: "Search failed",
        description: "Failed to search for stocks. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddStock = (symbol: string) => {
    addStockMutation.mutate(symbol);
  };

  const handleRemoveStock = (stockId: number) => {
    removeStockMutation.mutate(stockId);
  };

  const watchingStocks = stocks.filter((stock: Stock) => stock.isWatching);

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Stock Watchlist</CardTitle>
          <CardDescription>Track your favorite stocks</CardDescription>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => updateStocksMutation.mutate()}
            disabled={updateStocksMutation.isPending}
          >
            <RefreshCw className={`h-4 w-4 ${updateStocksMutation.isPending ? 'animate-spin' : ''}`} />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => setIsSearchDialogOpen(true)}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : watchingStocks.length > 0 ? (
          <div className="space-y-4">
            {watchingStocks.map((stock: Stock) => (
              <div key={stock.id} className="flex items-center justify-between">
                <div>
                  <div className="font-bold">{stock.symbol}</div>
                  <div className="text-sm text-muted-foreground">{stock.companyName}</div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="font-bold">${stock.price}</div>
                    <div className="flex items-center gap-1 text-xs">
                      {parseFloat(stock.change) >= 0 ? (
                        <ChevronUp className="h-3 w-3 text-green-500" />
                      ) : (
                        <ChevronDown className="h-3 w-3 text-red-500" />
                      )}
                      <Badge variant={parseFloat(stock.change) >= 0 ? "success" : "destructive"} className="px-1 py-0 h-auto">
                        {stock.change} ({stock.changePercent})
                      </Badge>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveStock(stock.id)}
                    disabled={removeStockMutation.isPending}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6">
            <div className="text-muted-foreground mb-2">No stocks in your watchlist</div>
            <Button variant="outline" onClick={() => setIsSearchDialogOpen(true)}>
              Add Stocks
            </Button>
          </div>
        )}
      </CardContent>

      <StockSearchDialog
        isOpen={isSearchDialogOpen}
        setIsOpen={setIsSearchDialogOpen}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        searchResults={searchResults}
        isSearching={isSearching}
        handleSearch={handleSearch}
        handleAddStock={handleAddStock}
      />
    </Card>
  );
}

interface StockSearchDialogProps {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  searchResults: StockSearchResult[];
  isSearching: boolean;
  handleSearch: () => void;
  handleAddStock: (symbol: string) => void;
}

function StockSearchDialog({
  isOpen,
  setIsOpen,
  searchQuery,
  setSearchQuery,
  searchResults,
  isSearching,
  handleSearch,
  handleAddStock,
}: StockSearchDialogProps) {
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Search Stocks</DialogTitle>
          <DialogDescription>
            Search for stocks by symbol or company name
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-center space-x-2">
          <div className="grid flex-1 gap-2">
            <Input
              placeholder="AAPL, Apple, MSFT..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch();
                }
              }}
            />
          </div>
          <Button 
            onClick={handleSearch} 
            disabled={isSearching || !searchQuery.trim()}
            variant="outline"
          >
            <Search className="h-4 w-4 mr-2" />
            Search
          </Button>
        </div>
        
        {searchResults.length > 0 && (
          <div className="max-h-[300px] overflow-y-auto">
            {searchResults.map((result) => (
              <div key={result.symbol} className="py-2">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold">{result.symbol}</div>
                    <div className="text-sm text-muted-foreground">{result.companyName}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right mr-2">
                      <div className="font-semibold">${result.price}</div>
                      <div className="flex items-center gap-1 text-xs">
                        {parseFloat(result.change) >= 0 ? (
                          <ChevronUp className="h-3 w-3 text-green-500" />
                        ) : (
                          <ChevronDown className="h-3 w-3 text-red-500" />
                        )}
                        <Badge variant={parseFloat(result.change) >= 0 ? "success" : "destructive"} className="px-1 py-0 h-auto">
                          {result.change} ({result.changePercent})
                        </Badge>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleAddStock(result.symbol)}
                      className="h-8 px-2"
                    >
                      <Plus className="h-3 w-3 mr-1" />
                      Add
                    </Button>
                  </div>
                </div>
                <Separator className="mt-2" />
              </div>
            ))}
          </div>
        )}
        
        {isSearching && (
          <div className="space-y-2">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        )}
        
        {!isSearching && searchResults.length === 0 && searchQuery && (
          <div className="text-center py-4 text-muted-foreground">
            No results found. Try a different search.
          </div>
        )}
        
        <DialogFooter className="sm:justify-end">
          <Button
            variant="secondary"
            onClick={() => setIsOpen(false)}
          >
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}