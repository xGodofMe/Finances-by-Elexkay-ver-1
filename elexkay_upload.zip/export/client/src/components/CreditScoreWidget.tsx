import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Shield, Eye, EyeOff, RefreshCw, ArrowUp, ArrowDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { CreditScore } from '@shared/schema';

// Define the shape of our credit score data
interface CreditScoreData {
  id?: number;
  userId?: number;
  experianScore?: number | null;
  equifaxScore?: number | null;
  transunionScore?: number | null;
  date?: string | null;
  hidden?: boolean;
  experianChange?: number | null;
  equifaxChange?: number | null;
  transunionChange?: number | null;
  experianToken?: string | null;
  equifaxToken?: string | null;
  transunionToken?: string | null;
}

export default function CreditScoreWidget() {
  const [hidden, setHidden] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  // Fetch credit scores
  const { data: creditScore, isLoading } = useQuery<CreditScoreData>({ 
    queryKey: ['/api/credit-scores'],
    staleTime: 1000 * 60 * 5 // 5 minutes
  });

  // Update hidden state when credit score data changes
  useEffect(() => {
    if (creditScore) {
      setHidden(creditScore.hidden || false);
    }
  }, [creditScore]);

  // Mutation to toggle visibility
  const toggleVisibilityMutation = useMutation({
    mutationFn: async (hidden: boolean) => {
      await apiRequest('/api/credit-scores/visibility', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hidden })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/credit-scores'] });
    }
  });

  // Mutation to update credit scores
  const updateScoresMutation = useMutation({
    mutationFn: async () => {
      setIsUpdating(true);
      return apiRequest('/api/credit-scores/update', {
        method: 'POST'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/credit-scores'] });
      setIsUpdating(false);
    },
    onError: () => {
      setIsUpdating(false);
    }
  });

  // Helper to get score color class
  const getScoreColorClass = (score?: number | null) => {
    if (!score) return 'text-gray-400';
    if (score >= 750) return 'text-green-400';
    if (score >= 700) return 'text-green-500';
    if (score >= 650) return 'text-yellow-500';
    if (score >= 600) return 'text-yellow-600';
    return 'text-red-500';
  };

  // Helper to render change indicator
  const renderChangeIndicator = (change?: number | null) => {
    if (!change) return null;
    
    if (change > 0) {
      return <Badge variant="default" className="bg-green-600 text-white text-[8px] ml-1 px-1 py-0">
        <ArrowUp className="h-2 w-2 mr-0.5" />{change}
      </Badge>;
    }
    
    if (change < 0) {
      return <Badge variant="default" className="bg-red-600 text-white text-[8px] ml-1 px-1 py-0">
        <ArrowDown className="h-2 w-2 mr-0.5" />{Math.abs(change)}
      </Badge>;
    }
    
    return null;
  };

  // Toggle visibility handler
  const handleToggleVisibility = () => {
    const newHidden = !hidden;
    setHidden(newHidden);
    toggleVisibilityMutation.mutate(newHidden);
  };

  // Update scores handler
  const handleUpdateScores = () => {
    updateScoresMutation.mutate();
  };

  // Function to render a score with its label
  const renderScoreCard = (
    bureau: string, 
    score?: number | null, 
    change?: number | null,
    icon?: React.ReactNode
  ) => {
    return (
      <div className="bg-[#1E2A5E] rounded-lg p-2 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            {icon}
            <h3 className="text-xs font-medium ml-1">{bureau}</h3>
          </div>
          {renderChangeIndicator(change)}
        </div>
        {hidden ? (
          <div className="text-sm font-bold flex items-center justify-center">
            ••••
          </div>
        ) : isLoading ? (
          <Skeleton className="h-5 w-full" />
        ) : (
          <p className={`text-sm font-bold ${getScoreColorClass(score)}`}>
            {score || '—'}
          </p>
        )}
      </div>
    );
  };

  return (
    <Card className="bg-[#131C3E] border-gray-700">
      <CardHeader className="pb-1 pt-2 px-3">
        <CardTitle className="text-sm flex items-center">
          <Shield className="mr-1.5 h-4 w-4" />
          Credit Scores
          <div className="ml-auto flex items-center gap-1">
            <Button 
              onClick={handleUpdateScores} 
              variant="ghost" 
              size="sm"
              disabled={isUpdating}
              className="h-6 w-6 p-0"
            >
              <RefreshCw className={`h-3 w-3 ${isUpdating ? 'animate-spin' : ''}`} />
            </Button>
            <div className="flex items-center gap-1">
              <span className="text-xs text-gray-400">
                {hidden ? 'Show' : 'Hide'}
              </span>
              <Switch 
                checked={!hidden} 
                onCheckedChange={() => handleToggleVisibility()}
                className="scale-70"
              />
            </div>
          </div>
        </CardTitle>
        <CardDescription className="text-xs">
          Credit scores from all three major bureaus
        </CardDescription>
      </CardHeader>
      <CardContent className="py-1 px-3">
        <div className="grid grid-cols-3 gap-2">
          {renderScoreCard(
            'Experian', 
            creditScore?.experianScore,
            creditScore?.experianChange,
            <div className="w-3 h-3 rounded-full bg-blue-600 flex items-center justify-center">
              <span className="text-[8px] font-bold">E</span>
            </div>
          )}
          {renderScoreCard(
            'Equifax',
            creditScore?.equifaxScore,
            creditScore?.equifaxChange,
            <div className="w-3 h-3 rounded-full bg-red-600 flex items-center justify-center">
              <span className="text-[8px] font-bold">E</span>
            </div>
          )}
          {renderScoreCard(
            'TransUnion',
            creditScore?.transunionScore,
            creditScore?.transunionChange,
            <div className="w-3 h-3 rounded-full bg-green-600 flex items-center justify-center">
              <span className="text-[8px] font-bold">T</span>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="pt-0 pb-2 px-3 text-[10px] text-gray-400">
        {!isLoading && creditScore?.date ? (
          <span>Last updated: {new Date(creditScore.date).toLocaleDateString()}</span>
        ) : (
          <span>Connect accounts to track scores</span>
        )}
      </CardFooter>
    </Card>
  );
}