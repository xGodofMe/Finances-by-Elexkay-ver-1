import React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Smartphone, ExternalLink } from "lucide-react";

interface VoiceGuideModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  platformType: 'ios' | 'android' | 'desktop';
}

export function VoiceGuideModal({ 
  open, 
  onOpenChange,
  platformType
}: VoiceGuideModalProps) {
  const [dismissed, setDismissed] = React.useState<boolean>(false);

  const handleDismiss = () => {
    setDismissed(true);
    onOpenChange(false);
    
    // Store dismissal in localStorage so we don't show it again
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('hideVoiceGuide', 'true');
    }
  };
  
  // Platform-specific content
  const renderContent = () => {
    if (platformType === 'ios') {
      return (
        <>
          <DialogHeader>
            <DialogTitle className="text-xl text-center flex items-center justify-center mb-2">
              <Smartphone className="w-5 h-5 mr-2" />
              Download Nigerian Voice for iOS
            </DialogTitle>
            <DialogDescription className="text-center pb-2">
              Follow these steps to download the Ezinne voice on your iPhone or iPad
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">1. Open Settings on your device</h3>
              <p className="text-sm text-slate-300">Go to your iOS Settings app</p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">2. Navigate to Accessibility</h3>
              <p className="text-sm text-slate-300">Tap on Accessibility in the Settings menu</p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">3. Find Spoken Content</h3>
              <p className="text-sm text-slate-300">Within Accessibility, tap on "Spoken Content"</p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">4. Select Voices</h3>
              <p className="text-sm text-slate-300">Tap on "Voices"</p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">5. Download English (Nigeria) voice</h3>
              <p className="text-sm text-slate-300">
                Tap on "English" → Scroll to find "English (Nigeria)" or "Nigerian English" → Download the Ezinne voice
              </p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">6. Return to Elexkay™</h3>
              <p className="text-sm text-slate-300">
                Once downloaded, come back to Elexkay™ and refresh the page. The Nigerian voice will now be available in the voice selector.
              </p>
            </div>
          </div>
        </>
      );
    } else if (platformType === 'android') {
      return (
        <>
          <DialogHeader>
            <DialogTitle className="text-xl text-center flex items-center justify-center mb-2">
              <Smartphone className="w-5 h-5 mr-2" />
              Download Nigerian Voice for Android
            </DialogTitle>
            <DialogDescription className="text-center pb-2">
              Follow these steps to download African voices on your Android device
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">1. Open Device Settings</h3>
              <p className="text-sm text-slate-300">Open the Settings app on your Android device</p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">2. Find System Settings</h3>
              <p className="text-sm text-slate-300">
                Scroll down and tap on "System" (on some devices, look for "General Management")
              </p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">3. Access Language & Input</h3>
              <p className="text-sm text-slate-300">
                Find and tap on "Language & Input" or "Languages & Input"
              </p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">4. Find Text-to-Speech Options</h3>
              <p className="text-sm text-slate-300">
                Look for "Text-to-speech output" or similar option
              </p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">5. Select Your TTS Engine</h3>
              <p className="text-sm text-slate-300">
                Tap on "Preferred engine" and select Google Text-to-speech Engine
              </p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">6. Install Voice Data</h3>
              <p className="text-sm text-slate-300">
                Tap on the settings (gear icon) for Google TTS → Then tap "Install voice data" → Look for "English (South Africa)" or other African English variants
              </p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">7. Return to Elexkay™</h3>
              <p className="text-sm text-slate-300">
                Once downloaded, come back to Elexkay™ and refresh the page. The African voice options should now be available in the voice selector.
              </p>
            </div>
          </div>
        </>
      );
    } else {
      // Desktop instructions
      return (
        <>
          <DialogHeader>
            <DialogTitle className="text-xl text-center flex items-center justify-center mb-2">
              <ExternalLink className="w-5 h-5 mr-2" />
              Download Ezinne Voice for Desktop
            </DialogTitle>
            <DialogDescription className="text-center pb-2">
              To get the best experience with the Nigerian Ezinne voice
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">1. Use Microsoft Edge</h3>
              <p className="text-sm text-slate-300">
                For the most authentic Nigerian voice experience, we recommend using Microsoft Edge browser
              </p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">2. Download Voices in Windows</h3>
              <p className="text-sm text-slate-300">
                On Windows: Open Settings → Time & Language → Speech → Manage voices → Add voices → Look for "English (Nigeria)" and install
              </p>
            </div>
            
            <div className="rounded-md p-3 bg-blue-950/30 border border-blue-900/50">
              <h3 className="font-medium text-blue-100 mb-1">3. Return to Elexkay™</h3>
              <p className="text-sm text-slate-300">
                After installation, refresh this page in Microsoft Edge browser and select the Ezinne voice from the voice selector
              </p>
            </div>
          </div>
        </>
      );
    }
  };

  return (
    <Dialog open={open && !dismissed} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
        {renderContent()}
        <DialogFooter className="flex gap-2 justify-between">
          <Button variant="outline" onClick={handleDismiss}>
            Don&apos;t show again
          </Button>
          <Button onClick={() => onOpenChange(false)}>
            Got it
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}