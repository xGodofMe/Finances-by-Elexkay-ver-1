import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { News } from "@shared/schema";
import { Clock } from "lucide-react";

interface NewsTickerTapeProps {
  showControls?: boolean;
}

export default function NewsTickerTape({ showControls = true }: NewsTickerTapeProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  // Market status indicator has been removed as requested

  // Fetch news data
  const { data: news = [], isLoading } = useQuery({
    queryKey: ["/api/news"],
    queryFn: async () => {
      const response = await fetch("/api/news");
      if (!response.ok) {
        throw new Error("Failed to fetch news");
      }
      return response.json();
    },
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  // Filter out hidden news
  const visibleNews = news.filter((item: News) => !item.hidden);

  // Animation for news ticker
  useEffect(() => {
    if (!containerRef.current || visibleNews.length === 0) return;
    
    // Simple animation using CSS animation
    const tickerContent = containerRef.current.querySelector('.news-ticker-content') as HTMLElement;
    if (!tickerContent) return;
    
    // Make sure the content is wide enough to create a ticker effect
    tickerContent.style.animationDuration = `${Math.max(30, visibleNews.length * 6)}s`;
  }, [visibleNews]);

  if (isLoading || visibleNews.length === 0) {
    return null;
  }

  return (
    <div 
      className="w-full bg-black/30 backdrop-blur-[20px] border-t border-white/[0.3] py-1 overflow-hidden"
      ref={containerRef}
    >
      <div className="container mx-auto px-4 relative">
        {/* News ticker header */}
        <div className="absolute left-4 top-0 bottom-0 flex items-center z-10 bg-black/30 backdrop-blur-sm pr-2">
          <div className="flex items-center gap-2">
            <div className="font-bold text-xs sm:text-sm py-1 text-white">
              FINANCIAL NEWS:
            </div>
          </div>
        </div>
        
        {/* News ticker content */}
        <div className="pl-[140px] sm:pl-[200px] md:pl-[220px] overflow-hidden">
          <div 
            className="news-ticker-content flex items-center whitespace-nowrap"
            style={{
              // Create a continuous animation effect
              animationName: 'ticker',
              animationTimingFunction: 'linear',
              animationIterationCount: 'infinite',
              animationDuration: '30s',
              paddingRight: '48px' // Extra padding for controls
            }}
          >
            {/* Duplicate news items for seamless looping */}
            {[...visibleNews, ...visibleNews].map((item: News, index) => (
              <span
                key={`${item.id}-${index}`}
                onClick={(e) => {
                  e.preventDefault();
                  // Use window.open with explicit https protocol if not present
                  let url = item.url;
                  if (!/^https?:\/\//i.test(url)) {
                    url = 'https://' + url;
                  }
                  window.open(url, '_blank', 'noopener,noreferrer');
                }}
                className="inline-block mx-3 sm:mx-6 text-xs sm:text-sm text-white hover:text-blue-300 transition-colors cursor-pointer"
              >
                {item.title} <span className="text-blue-300 font-medium">({item.source})</span>
              </span>
            ))}
          </div>
        </div>
        
        {/* Individual refresh button only shown when showControls is true */}
        {showControls && (
          <div className="absolute right-4 top-0 bottom-0 flex items-center">
            <button
              onClick={() => {/* refresh logic was moved to App.tsx */}}
              className="text-xs sm:text-sm px-2 py-1 bg-blue-500/30 border border-blue-500/50 hover:bg-blue-500/50 rounded-sm transition-colors text-white"
            >
              Refresh
            </button>
          </div>
        )}
      </div>
    </div>
  );
}