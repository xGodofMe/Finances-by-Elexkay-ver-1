import { Link, useLocation } from "wouter";
import { Menu, ArrowLeft, ArrowRight, LogOut, Settings, LineChart, LayoutDashboard, HelpCircle, Mail, ShieldAlert, User, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/use-auth";

interface HeaderProps {
  showFirstTimeArrow?: boolean;
}

export default function Header({ showFirstTimeArrow = false }: HeaderProps) {
  const [location, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();

  const goBack = () => {
    navigate("/");
  };

  // Determine the current page
  const isManagePage = location === "/manage";
  const isSettingsPage = location === "/settings";
  const isHelpPage = location === "/help";
  const isProfilePage = location === "/profile";
  const isSuggestionsPage = location === "/suggestions";
  const isAuthPage = location === "/auth";
  const isDetailPage = isManagePage || isSettingsPage || isHelpPage || isProfilePage || isSuggestionsPage;

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="p-3 md:p-6 border-b border-white/[0.18] backdrop-blur-[10px] bg-black/30">
      <div className="flex justify-between items-center">
        {/* Left side - back button on detail pages */}
        <div className="z-10">
          {!isAuthPage && user && isDetailPage && (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={goBack}
              className="bg-white/10 hover:bg-white/20 border-white/20 transition duration-200 rounded-full"
              aria-label="Back to Dashboard"
            >
              <ArrowLeft className="h-4 w-4 sm:mr-1" />
              <span className="hidden sm:inline">Back</span>
            </Button>
          )}
        </div>
        
        {/* Center - logo and tagline */}
        <div className="text-center mx-auto">
          <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-white">
            Finances by Elexkay<sup className="text-xs sm:text-sm md:text-base">™</sup>
            {/* Show "Demo" badge only for demo user account */}
            {user?.isDemoAccount && (
              <span className="ml-2 text-xs sm:text-sm bg-amber-500 text-black px-2 py-0.5 rounded-md font-medium align-middle">
                Demo
              </span>
            )}
          </h1>
          <p className="text-[9px] sm:text-xs md:text-sm mt-1 text-blue-200 italic">
            <span className="text-white font-bold">L</span>earn.{" "}
            <span className="font-bold">e</span>
            <span className="text-white font-bold">X</span>ecute.{" "}
            <span className="text-white font-bold">K</span>eep.
          </p>
        </div>
        
        {/* Right side - navigation menu */}
        <div className="z-10 relative">
          {showFirstTimeArrow && !isAuthPage && user && !isDetailPage && (
            <div className="absolute -left-16 top-0 flex items-center">
              <div className="text-yellow-300 animate-pulse text-sm font-medium mr-1">
                Add first bill
              </div>
              <ArrowRight className="h-5 w-5 text-yellow-300 animate-bounce" />
            </div>
          )}
          {!isAuthPage && user && !isDetailPage && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="bg-white/10 hover:bg-white/20 border-white/20 transition duration-200 rounded-full"
                  aria-label="Menu"
                >
                  <Menu className="h-4 w-4 sm:mr-1" />
                  <span className="hidden sm:inline">Menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Menu</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer" onClick={() => navigate("/")}>
                  <LayoutDashboard className="mr-2 h-4 w-4" />
                  <span>Dashboard</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer" onClick={() => navigate("/manage")}>
                  <LineChart className="mr-2 h-4 w-4" />
                  <span>Manage Bills</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer" onClick={() => navigate("/settings")}>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer" onClick={() => navigate("/help")}>
                  <HelpCircle className="mr-2 h-4 w-4" />
                  <span>Help & Support</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer" onClick={() => navigate("/profile")}>
                  <User className="mr-2 h-4 w-4" />
                  <span>My Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer" onClick={() => navigate("/suggestions")}>
                  <MessageSquare className="mr-2 h-4 w-4" />
                  <span>Suggestions</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer" onClick={() => window.location.href = "mailto:help@elexkay.com"}>
                  <Mail className="mr-2 h-4 w-4" />
                  <span>Contact Support</span>
                </DropdownMenuItem>
                {user?.isAdmin && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="cursor-pointer" onClick={() => navigate("/admin")}>
                      <ShieldAlert className="mr-2 h-4 w-4 text-amber-500" />
                      <span className="text-amber-500 font-semibold">Admin Panel</span>
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer" onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </header>
  );
}
