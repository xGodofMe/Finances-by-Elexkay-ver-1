import { Badge } from "@/components/ui/badge";
import { BillStatus } from "@shared/schema";

interface StatusBadgeProps {
  status: BillStatus;
  children?: React.ReactNode;
  onClick?: () => void;
}

export function StatusBadge({ status, children, onClick }: StatusBadgeProps) {
  let content;
  let badgeVariant: any = status;
  
  // Map our custom status to valid badge variants if needed
  if (status === "skip" || status === "due") {
    badgeVariant = status === "skip" ? "secondary" : "destructive";
  }
  
  switch (status) {
    case "paid":
      content = children || "Paid";
      break;
    case "upcoming":
      content = children || "Upcoming";
      break;
    case "active":
      content = children || "Active";
      break;
    case "hidden":
      content = children || "Hidden";
      break;
    case "skip":
      content = children || "Skip";
      break;
    case "due":
      content = children || "Due";
      break;
    case "auto":
      content = children || "Auto Pay";
      break;
  }
  
  return (
    <span 
      onClick={onClick}
      className={`squarespace-badge ${onClick ? "cursor-pointer" : ""} ${
        status === "paid" ? "squarespace-badge-paid" : 
        status === "skip" ? "bg-gray-500 text-white" : 
        status === "due" ? "bg-red-600 text-white" : 
        status === "upcoming" ? "bg-sky-700 text-white" :
        status === "active" ? "bg-amber-600 text-white" :
        status === "auto" ? "bg-purple-600 text-white" :
        "bg-gray-500 text-white"
      }`}
    >
      {content}
    </span>
  );
}
