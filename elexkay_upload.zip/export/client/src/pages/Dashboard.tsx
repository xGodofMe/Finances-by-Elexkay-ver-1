import { useEffect, useState } from "react";
import { 
  getSettings, 
  getCurrentPeriodBills, 
  getUpcomingPayDates, 
  getDraftSummary,
  getEstimatedDraft,
  getMonthlyTotal,
  subscribe,
  updateBill
} from "@/lib/store";
import { formatCurrency, getOrdinal } from "@/lib/utils";
import { StatusBadge } from "@/components/ui/status-badge";
import { formatDateString, getDaysUntil } from "@/lib/date-utils";
import { Wallet, RefreshCw } from "lucide-react";
import { format } from "date-fns";
import { BillStatus } from "@shared/schema";
import { Progress } from "@/components/ui/progress";

interface DashboardProps {
  updateFirstTimeArrow?: (show: boolean) => void;
}

export default function Dashboard({ updateFirstTimeArrow }: DashboardProps) {
  const [currentPeriodBills, setCurrentPeriodBills] = useState<any[]>([]);
  const [upcomingPayDates, setUpcomingPayDates] = useState<Date[]>([]);
  const [draftSummary, setDraftSummary] = useState<any[]>([]);
  const [settings, setSettings] = useState(getSettings());
  const [estimatedDraft, setEstimatedDraft] = useState<{ total: number; baseAmount: number; cushionAmount: number }>({ total: 0, baseAmount: 0, cushionAmount: 0 });
  const [sortColumn, setSortColumn] = useState<string>("dueDay");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [isResetting, setIsResetting] = useState(false);
  const [loading, setLoading] = useState<boolean>(true);
  
  // Function to add a new calculator item
  const addCalculatorItem = () => {
    const container = document.getElementById('calculator-items');
    if (!container) return;
    
    // Create new calculator item
    const newItem = document.createElement('div');
    newItem.className = 'calculator-item mb-2';
    
    // Create flex container for side-by-side layout
    const flexContainer = document.createElement('div');
    flexContainer.className = 'flex gap-2';
    
    // Create name input
    const nameInputContainer = document.createElement('div');
    nameInputContainer.className = 'relative rounded-md shadow-sm flex-1';
    
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.className = 'calc-name block w-full rounded-md border-0 py-1.5 pl-3 pr-2 bg-blue-900/50 text-white placeholder:text-gray-400 focus:ring-1 focus:ring-blue-500 text-sm';
    nameInput.placeholder = 'Bill Name';
    
    nameInputContainer.appendChild(nameInput);
    
    // Create amount input
    const amountInputContainer = document.createElement('div');
    amountInputContainer.className = 'relative rounded-md shadow-sm w-1/3 min-w-[100px]';
    
    const dollarSign = document.createElement('div');
    dollarSign.className = 'pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3';
    const dollarSpan = document.createElement('span');
    dollarSpan.className = 'text-gray-400 sm:text-xs';
    dollarSpan.textContent = '$';
    dollarSign.appendChild(dollarSpan);
    
    const amountInput = document.createElement('input');
    amountInput.type = 'number';
    amountInput.className = 'calc-amount block w-full rounded-md border-0 py-1.5 pl-7 pr-2 bg-blue-900/50 text-white placeholder:text-gray-400 focus:ring-1 focus:ring-blue-500 text-sm';
    amountInput.placeholder = '0.00';
    amountInput.step = '0.01';
    amountInput.min = '0';
    amountInput.addEventListener('input', updateCalculatorTotal);
    
    amountInputContainer.appendChild(dollarSign);
    amountInputContainer.appendChild(amountInput);
    
    // Add elements to flex container
    flexContainer.appendChild(nameInputContainer);
    flexContainer.appendChild(amountInputContainer);
    
    // Add flex container to the new item
    newItem.appendChild(flexContainer);
    
    // Insert the new item before the button
    const addButton = container.querySelector('button');
    if (addButton && addButton.parentNode) {
      container.insertBefore(newItem, addButton);
      updateCalculatorTotal();
    }
  };
  
  // Function to calculate the total of all calculator items
  const updateCalculatorTotal = () => {
    const amountInputs = document.querySelectorAll('.calc-amount');
    const totalElement = document.getElementById('calc-total');
    
    if (totalElement) {
      let total = 0;
      
      amountInputs.forEach((input) => {
        const amountInput = input as HTMLInputElement;
        const amount = parseFloat(amountInput.value) || 0;
        total += amount;
      });
      
      totalElement.textContent = formatCurrency(total);
    }
  };

  // Update state when store changes
  useEffect(() => {
    const updateState = () => {
      const bills = getCurrentPeriodBills();
      setCurrentPeriodBills(bills);
      setUpcomingPayDates(getUpcomingPayDates());
      setDraftSummary(getDraftSummary());
      setSettings(getSettings());
      setEstimatedDraft(getEstimatedDraft());
      setLoading(false); // Set loading to false after data is loaded
      
      // Show first-time user arrow if there are no bills
      if (updateFirstTimeArrow) {
        updateFirstTimeArrow(bills.length === 0);
      }
    };

    // Initial update
    updateState();

    // Subscribe to store updates
    const unsubscribe = subscribe(updateState);
    return unsubscribe;
  }, [updateFirstTimeArrow]);

  // Get the next pay date
  const nextPayDate = upcomingPayDates.length > 0 ? upcomingPayDates[0] : new Date();
  const daysUntilNextPay = getDaysUntil(nextPayDate);

  // Get the current pay period end date (next pay date)
  const currentPeriodEnd = upcomingPayDates.length > 0 ? upcomingPayDates[0] : new Date();
  
  // Sort bills based on current sort settings
  const sortedBills = [...currentPeriodBills].sort((a, b) => {
    let aValue, bValue;
    
    // Get the values to compare based on the sort column
    switch (sortColumn) {
      case "name":
        aValue = a.name.toLowerCase();
        bValue = b.name.toLowerCase();
        break;
      case "amount":
        aValue = parseFloat(a.amount);
        bValue = parseFloat(b.amount);
        break;
      case "dueDay":
        aValue = parseInt(a.dueDay);
        bValue = parseInt(b.dueDay);
        break;
      case "status":
        aValue = a.status;
        bValue = b.status;
        break;
      default:
        aValue = a.name.toLowerCase();
        bValue = b.name.toLowerCase();
    }
    
    // Compare the values based on sort direction
    if (sortDirection === "asc") {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Function to handle column header click for sorting
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      // If already sorting by this column, toggle direction
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      // Otherwise, sort by this column in ascending order
      setSortColumn(column);
      setSortDirection("asc");
    }
  };
  
  // Function to toggle bill status
  const toggleBillStatus = async (bill: any) => {
    let newStatus: BillStatus;
    
    // Cycle through statuses: upcoming/due -> paid -> auto -> skip -> upcoming
    if (bill.status === "upcoming" || bill.status === "due") {
      newStatus = "paid";
    } else if (bill.status === "paid") {
      newStatus = "auto";
    } else if (bill.status === "auto") {
      newStatus = "skip";
    } else {
      newStatus = "upcoming";
    }
    
    // Update the bill in the database
    await updateBill(bill.id, { status: newStatus });
  };

  return (
    <div className="container mx-auto p-4 md:p-6">
      {/* Summary Card */}
      <div className="mb-6">
        <div className="flex justify-between gap-4">
          <div className="bg-black/[0.45] backdrop-blur-[20px] rounded-[12px] p-4 text-center border border-white/[0.3] flex-1 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
            <div className="text-xs text-blue-200">Draft This Pay Period</div>
            <div className="text-2xl font-bold mt-1">{formatCurrency(estimatedDraft.total)}</div>
          </div>
          
          <div className="bg-black/[0.45] backdrop-blur-[20px] rounded-[12px] p-4 text-center border border-white/[0.3] flex-1 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
            <div className="text-xs text-blue-200">Monthly Due</div>
            <div className="text-2xl font-bold mt-1">{formatCurrency(getMonthlyTotal())}</div>
          </div>
        </div>

      </div>
      
      {/* Mobile-first Layout with responsive column adjustments */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4 md:gap-6">
        {/* Draft Summary - Left Column on larger screens, full width on mobile */}
        <div className="md:col-span-1 lg:col-span-3 card-container">
          <h2 className="text-sm font-semibold mb-2 flex items-center justify-between">
            <span>
              Draft Summary <span className="text-blue-200">{new Date().toLocaleDateString('en-US', { month: 'short' })} {new Date().getFullYear()}</span>
            </span>
            <span className="text-xs text-blue-200">
              ({settings.payFrequency})
            </span>
          </h2>
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="text-blue-200 text-xs border-b border-white/[0.18]">
                  <th className="text-left pb-1 px-1">Date</th>
                  <th className="text-right pb-1 px-1">Amount</th>
                  <th className="text-right pb-1 px-1">Bills</th>
                </tr>
              </thead>
              <tbody>
                {draftSummary.length > 0 ? (
                  draftSummary.map((item, index) => (
                    <tr key={index} className="border-b border-white/[0.18] hover:bg-white/[0.08] transition-colors">
                      <td className="py-1.5 text-xs px-1">
                        {item.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </td>
                      <td className="py-1.5 text-right text-xs font-medium px-1">{formatCurrency(item.amount)}</td>
                      <td className="py-1.5 text-right text-xs text-blue-200 px-1">{item.count}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3} className="py-2 text-center text-xs text-gray-400">No pay dates in {new Date().toLocaleDateString('en-US', { month: 'short' })}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {/* Quick Reference Calculator - Sticky */}
          <div className="mt-4 pt-4 border-t border-white/[0.18] sticky top-4">
            <h3 className="text-sm font-semibold mb-2">Quick Calculator</h3>
            <div className="space-y-2" id="calculator-items">
              {/* Calculator items will be added here */}
              <div className="calculator-item">
                <div className="flex gap-2">
                  <div className="relative rounded-md shadow-sm flex-1">
                    <input
                      type="text"
                      className="calc-name block w-full rounded-md border-0 py-1.5 pl-3 pr-2 bg-blue-900/50 text-white placeholder:text-gray-400 focus:ring-1 focus:ring-blue-500 text-sm"
                      placeholder="Bill Name"
                    />
                  </div>
                  <div className="relative rounded-md shadow-sm w-1/3 min-w-[100px]">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                      <span className="text-gray-400 sm:text-xs">$</span>
                    </div>
                    <input
                      type="number"
                      className="calc-amount block w-full rounded-md border-0 py-1.5 pl-7 pr-2 bg-blue-900/50 text-white placeholder:text-gray-400 focus:ring-1 focus:ring-blue-500 text-sm"
                      placeholder="0.00"
                      step="0.01"
                      min="0"
                      onChange={updateCalculatorTotal}
                    />
                  </div>
                </div>
              </div>
              
              {/* Add button with enhanced styling */}
              <button 
                className="flex items-center justify-center w-full py-1.5 mt-2 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium transition-colors shadow-md hover:shadow-lg"
                onClick={addCalculatorItem}
                aria-label="Add another bill to calculate"
              >
                <span className="mr-1 text-lg font-bold">+</span> Add Another Bill
              </button>
              
              {/* Clear all button */}
              <button 
                className="flex items-center justify-center w-full py-1 mt-1 rounded-md bg-transparent hover:bg-red-900/30 text-red-300 hover:text-red-200 text-xs font-medium transition-colors border border-red-900/30"
                onClick={() => {
                  // Keep only the first calculator item
                  const container = document.getElementById('calculator-items');
                  if (!container) return;
                  
                  // Get all calculator items
                  const items = container.querySelectorAll('.calculator-item');
                  
                  // Remove all except the first one
                  if (items.length > 1) {
                    for (let i = 1; i < items.length; i++) {
                      items[i].remove();
                    }
                    
                    // Clear the first item's inputs
                    const firstItem = items[0];
                    const nameInput = firstItem.querySelector('.calc-name') as HTMLInputElement;
                    const amountInput = firstItem.querySelector('.calc-amount') as HTMLInputElement;
                    
                    if (nameInput) nameInput.value = '';
                    if (amountInput) {
                      amountInput.value = '';
                      // Update the calculator total
                      updateCalculatorTotal();
                    }
                  }
                }}
              >
                Clear All
              </button>
              
              <div className="flex justify-between items-center text-sm mt-1 pt-2 border-t border-white/[0.18]">
                <span className="font-medium">Total:</span>
                <span id="calc-total" className="font-bold">{formatCurrency(0)}</span>
              </div>
            </div>
          </div>
          
          {/* Payment Settings - Visible on mobile within the draft summary card */}
          <div className="mt-4 pt-4 border-t border-white/[0.18] md:hidden">
            <h3 className="text-sm font-medium mb-2">Payment Settings</h3>
            <div className="flex items-center justify-between text-sm">
              <span>Payment Strategy</span>
              <span className="font-medium">{settings.paymentStrategy}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-1">
              <span>Pay Frequency</span>
              <span className="font-medium">{settings.payFrequency}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-1">
              <span>Billing Cushion</span>
              <span className="font-medium">
                {settings.billingCushion || "2"}% 
                <span className="ml-1 text-gray-400">
                  ({formatCurrency(estimatedDraft.cushionAmount)})
                </span>
              </span>
            </div>
          </div>
        </div>

        {/* Bills - Middle Column on larger screens, full width on mobile */}
        <div className="md:col-span-1 lg:col-span-6 card-container">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0 mb-4">
            <div className="flex items-center">
              <h2 className="text-lg font-semibold">
                Bills
                {loading && (
                  <span className="ml-2 inline-block">
                    <span className="animate-pulse">Loading...</span>
                  </span>
                )}
              </h2>
              <button 
                className="ml-2 px-3 py-1 text-xs bg-black/[0.45] hover:bg-black/[0.55] border border-white/[0.3] rounded-full text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed backdrop-blur-[10px]"
                disabled={isResetting}
                onClick={async () => {
                  try {
                    setIsResetting(true);
                    // Get all current bills
                    const currentBills = getCurrentPeriodBills();
                    
                    // Update each bill to "upcoming" status
                    for (const bill of currentBills) {
                      if (bill.status !== "upcoming") {
                        await updateBill(bill.id!, { status: "upcoming" });
                      }
                    }
                  } finally {
                    setIsResetting(false);
                  }
                }}
              >
                {isResetting ? (
                  <span className="flex items-center gap-1">
                    <RefreshCw className="h-3 w-3 animate-spin" />
                    Resetting...
                  </span>
                ) : (
                  <span className="flex items-center gap-1">
                    <RefreshCw className="h-3 w-3" />
                    Reset All
                  </span>
                )}
              </button>
            </div>
            <div className="text-sm text-blue-200 w-full sm:w-auto text-right">
              <span className="font-medium">Total:</span> {formatCurrency(estimatedDraft.total)} 
              <span className="hidden sm:inline ml-1">
                (includes {formatCurrency(estimatedDraft.cushionAmount)} cushion)
              </span>
            </div>
          </div>
          
          {/* Mobile view: List of bills instead of table */}
          <div className="sm:hidden">
            {loading ? (
              <div className="my-8 flex flex-col items-center">
                <div className="text-center mb-4">Loading bills...</div>
                <Progress value={50} className="w-72 h-2 animate-pulse" />
              </div>
            ) : sortedBills.length > 0 ? (
              <div className="space-y-3">
                {sortedBills.map((bill) => (
                  <div key={bill.id} className="p-3 rounded-[12px] border border-white/[0.3] bg-black/[0.45] backdrop-blur-[20px] shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium">{bill.name}</h3>
                      <StatusBadge 
                        status={bill.status || "upcoming"} 
                        onClick={() => toggleBillStatus(bill)}
                      />
                    </div>
                    <div className="mt-2 flex justify-between text-sm">
                      <div>
                        <div>
                          Amount: <span className="font-medium">{formatCurrency(Number(bill.amount) + Number(bill.additionalPayment || 0))}</span>
                          {bill.additionalPayment && Number(bill.additionalPayment) > 0 && (
                            <span className="ml-1 text-xs text-blue-200">(+ {formatCurrency(Number(bill.additionalPayment))})</span>
                          )}
                        </div>
                        <div>Due: <span className="font-medium">{getOrdinal(parseInt(bill.dueDay))}</span></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-gray-400 my-4">
                No bills for this period
              </div>
            )}
          </div>
          
          {/* Desktop view: Table of bills */}
          <div className="hidden sm:block">
            {loading ? (
              <div className="my-8 flex flex-col items-center">
                <div className="text-center mb-4">Loading bills...</div>
                <Progress value={50} className="w-72 h-2 animate-pulse" />
              </div>
            ) : (
              <table className="min-w-full divide-y divide-white/10">
                <thead className="bg-black/[0.35] backdrop-blur-[10px]">
                  <tr>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("name")}
                  >
                    Name {sortColumn === "name" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("amount")}
                  >
                    Amount {sortColumn === "amount" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("dueDay")}
                  >
                    Due Date {sortColumn === "dueDay" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-blue-200 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("status")}
                  >
                    Status {sortColumn === "status" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {sortedBills.length > 0 ? (
                  sortedBills.map((bill) => (
                    <tr key={bill.id} className="hover:bg-white/[0.08] transition-colors">
                      <td className="px-4 py-3 whitespace-nowrap">{bill.name}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {formatCurrency(Number(bill.amount) + Number(bill.additionalPayment || 0))}
                        {bill.additionalPayment && Number(bill.additionalPayment) > 0 && (
                          <div className="text-xs text-blue-200">
                            (+ {formatCurrency(Number(bill.additionalPayment))})
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">{getOrdinal(parseInt(bill.dueDay))}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <StatusBadge 
                          status={bill.status || "upcoming"} 
                          onClick={() => toggleBillStatus(bill)}
                        />
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="px-4 py-3 text-center text-gray-400">
                      No bills for this period
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            )}
          </div>
        </div>

        {/* Payment Schedule - Right Column on desktop, hidden on small tablets and shown on mobile */}
        <div className="lg:col-span-3 hidden md:block card-container">
          <h2 className="text-lg font-semibold mb-4">Upcoming Pay Dates</h2>
          <ul className="space-y-2">
            {upcomingPayDates.slice(0, 8).map((date, index) => {
              const currentMonth = new Date().getMonth();
              const isCurrentMonth = date.getMonth() === currentMonth;
              
              // Find if this pay date is in the draft summary (current month)
              const draftItem = draftSummary.find(item => 
                item.date.getTime() === date.getTime()
              );
              
              return (
                <li 
                  key={index} 
                  className="flex justify-between items-center p-2 hover:bg-white/[0.08] rounded-[8px] transition-colors"
                >
                  <span className="text-sm md:text-base">
                    {format(date, "EEEE, MMMM d, yyyy")}
                  </span>
                  {draftItem && (
                    <span className="text-sm font-semibold text-blue-200 whitespace-nowrap ml-2">{formatCurrency(draftItem.amount)}</span>
                  )}
                </li>
              );
            })}
          </ul>
          <div className="mt-4 pt-4 border-t border-white/[0.18]">
            <h3 className="text-sm font-medium mb-2">Payment Settings</h3>
            <div className="flex items-center justify-between text-sm">
              <span>Payment Strategy</span>
              <span className="font-medium">{settings.paymentStrategy}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-1">
              <span>Pay Frequency</span>
              <span className="font-medium">{settings.payFrequency}</span>
            </div>
            <div className="flex items-center justify-between text-sm mt-1">
              <span>Billing Cushion</span>
              <span className="font-medium">
                {settings.billingCushion || "2"}% 
                <span className="ml-1 text-gray-400">
                  ({formatCurrency(estimatedDraft.cushionAmount)})
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
