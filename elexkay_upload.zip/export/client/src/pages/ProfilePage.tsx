import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ProfileData {
  id: number;
  username: string;
  firstName?: string | null;
  lastName?: string | null;
  phoneticLastName?: string | null; // Phonetic breakdown for pronunciation
  email?: string | null;
  title?: string | null;
  isAdmin: boolean;
  autoLogout: boolean;
  inactivityTimeout: number;
}

export default function ProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [profileForm, setProfileForm] = useState({
    firstName: "",
    lastName: "",
    phoneticLastName: "", // Add phonetic breakdown field
    email: "",
    title: "",
  });
  
  const [securityForm, setSecurityForm] = useState({
    autoLogout: true,
    inactivityTimeout: 15,
  });
  
  // Try to get existing data from localStorage before the API call
  useEffect(() => {
    try {
      // Check if we have complete profile data saved in localStorage first
      const savedUserProfile = localStorage.getItem('userProfile');
      if (savedUserProfile) {
        const parsedProfile = JSON.parse(savedUserProfile);
        console.log("Found saved user profile in localStorage:", parsedProfile);
        
        // Pre-fill the form with localStorage data before API call completes
        setProfileForm({
          firstName: parsedProfile.firstName || "",
          lastName: parsedProfile.lastName || "",
          phoneticLastName: parsedProfile.phoneticLastName || "",
          email: parsedProfile.email || "",
          title: parsedProfile.title || "",
        });
        
        setSecurityForm({
          autoLogout: parsedProfile.autoLogout ?? true,
          inactivityTimeout: parsedProfile.inactivityTimeout || 15,
        });
      }
    } catch (error) {
      console.error("Error loading profile from localStorage:", error);
    }
  }, []);
  
  // Fetch profile data from API
  const { data: profile, isLoading } = useQuery<ProfileData>({
    queryKey: ["/api/profile"],
    queryFn: async () => {
      try {
        const response = await apiRequest<ProfileData>("GET", "/api/profile");
        if (!response) {
          // If API fails, try to return from localStorage
          const savedProfile = localStorage.getItem('userProfile');
          if (savedProfile) {
            return JSON.parse(savedProfile);
          }
          throw new Error("Failed to fetch profile data");
        }
        return response;
      } catch (error) {
        console.error("Profile fetch error:", error);
        // Return from localStorage as fallback
        const savedProfile = localStorage.getItem('userProfile');
        if (savedProfile) {
          return JSON.parse(savedProfile);
        }
        throw error;
      }
    },
    retry: 3,
    staleTime: 60 * 1000 // 1 minute
  });
  
  // Update form state when profile data loads from API
  useEffect(() => {
    if (profile) {
      console.log("Profile data loaded from API:", profile);
      
      // Store the profile in localStorage as a backup
      localStorage.setItem('userProfile', JSON.stringify(profile));
      
      setProfileForm({
        firstName: profile.firstName || "",
        lastName: profile.lastName || "",
        phoneticLastName: profile.phoneticLastName || "",
        email: profile.email || "",
        title: profile.title || "",
      });
      
      setSecurityForm({
        autoLogout: profile.autoLogout ?? true,
        inactivityTimeout: profile.inactivityTimeout || 15,
      });
    }
  }, [profile]);
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: Partial<ProfileData>) => {
      // The apiRequest already handles the JSON parsing for us
      const response = await apiRequest<ProfileData>("PUT", "/api/profile", data);
      if (!response) throw new Error("Failed to update profile: No response from server");
      return response;
    },
    onSuccess: (data) => {
      // Update both the React Query cache and session/user data
      queryClient.setQueryData(["/api/profile"], data);
      
      // Also update the user data in auth context to ensure it persists
      // This is crucial because the main user data is used throughout the app
      const currentUser = queryClient.getQueryData<ProfileData>(["/api/user"]);
      if (currentUser) {
        // Merge the profile data into user data
        const updatedUser = {
          ...currentUser,
          firstName: data.firstName,
          lastName: data.lastName,
          phoneticLastName: data.phoneticLastName,
          email: data.email,
          title: data.title,
          autoLogout: data.autoLogout,
          inactivityTimeout: data.inactivityTimeout
        };
        queryClient.setQueryData(["/api/user"], updatedUser);
      }
      
      // Also store in localStorage as a backup
      localStorage.setItem('userProfile', JSON.stringify(data));
      
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      console.error("Profile update error:", error);
      toast({
        title: "Error",
        description: `Failed to update profile: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSecurityChange = (name: string, value: boolean | number) => {
    setSecurityForm(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Save in localStorage too for backup in case API fails
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('profileForm', JSON.stringify(profileForm));
    }
    
    updateProfileMutation.mutate(profileForm);
  };
  
  const handleSecuritySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Save in localStorage too for backup in case API fails
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('securityForm', JSON.stringify(securityForm));
    }
    
    updateProfileMutation.mutate(securityForm);
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">My Profile</h1>
      
      <Tabs defaultValue="personal" className="w-full">
        <TabsList className="mb-6 grid grid-cols-2 w-[400px]">
          <TabsTrigger value="personal">Personal Information</TabsTrigger>
          <TabsTrigger value="security">Security Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="personal">
          <Card className="mb-6 backdrop-blur-lg bg-card/80 border-none shadow-lg">
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
              <CardDescription>
                Update your personal details
              </CardDescription>
            </CardHeader>
            <form onSubmit={handleProfileSubmit}>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={profileForm.firstName}
                      onChange={handleProfileChange}
                      placeholder="Enter your first name"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={profileForm.lastName}
                      onChange={handleProfileChange}
                      placeholder="Enter your last name"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phoneticLastName">Phonetic Last Name</Label>
                  <Input
                    id="phoneticLastName"
                    name="phoneticLastName"
                    value={profileForm.phoneticLastName}
                    onChange={handleProfileChange}
                    placeholder="How to pronounce your last name (e.g., kwa-lee)"
                  />
                  <p className="text-xs text-muted-foreground">
                    This helps the voice assistant pronounce your name correctly
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={profileForm.email}
                    onChange={handleProfileChange}
                    placeholder="Enter your email address"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    name="title"
                    value={profileForm.title}
                    onChange={handleProfileChange}
                    placeholder="Mr, Mrs, Dr, etc."
                  />
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  type="submit" 
                  disabled={updateProfileMutation.isPending}
                  className="w-full md:w-auto"
                >
                  {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
        
        <TabsContent value="security">
          <Card className="mb-6 backdrop-blur-lg bg-card/80 border-none shadow-lg">
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Configure auto-logout and session security
              </CardDescription>
            </CardHeader>
            <form onSubmit={handleSecuritySubmit}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="autoLogout" className="flex-1">
                      Auto-logout when inactive
                    </Label>
                    <Switch
                      id="autoLogout"
                      checked={securityForm.autoLogout}
                      onCheckedChange={(checked) => handleSecurityChange("autoLogout", checked)}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Automatically log out after a period of inactivity for better security.
                  </p>
                </div>
                
                {securityForm.autoLogout && (
                  <div className="space-y-2">
                    <Label htmlFor="inactivityTimeout">Inactivity Timeout (minutes)</Label>
                    <Select 
                      value={securityForm.inactivityTimeout.toString()} 
                      onValueChange={(value) => handleSecurityChange("inactivityTimeout", parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select timeout duration" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="5">5 minutes</SelectItem>
                        <SelectItem value="10">10 minutes</SelectItem>
                        <SelectItem value="15">15 minutes</SelectItem>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="60">1 hour</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button 
                  type="submit" 
                  disabled={updateProfileMutation.isPending}
                  className="w-full md:w-auto"
                >
                  {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}