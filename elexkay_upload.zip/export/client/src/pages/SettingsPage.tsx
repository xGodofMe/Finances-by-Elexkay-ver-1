import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { getSettings, updateSettings, subscribe, setMockDate, getCurrentDate } from "@/lib/store";
import { DatePicker } from "@/components/ui/date-picker";
import { Switch } from "@/components/ui/switch";
import StockSettings from "@/components/StockSettings";

export default function SettingsPage() {
  const [settings, setSettings] = useState(getSettings());
  const [isSaving, setIsSaving] = useState(false);
  const [lastPayDate, setLastPayDate] = useState<Date | undefined>(
    settings.lastPayDate ? new Date(settings.lastPayDate) : undefined
  );
  const [mockDate, setMockDateState] = useState<Date | null>(null);

  // Update local state when the store changes
  useEffect(() => {
    const handleUpdate = () => {
      const newSettings = getSettings();
      setSettings(newSettings);
      setLastPayDate(newSettings.lastPayDate ? new Date(newSettings.lastPayDate) : undefined);
    };

    // Subscribe to store updates
    const unsubscribe = subscribe(handleUpdate);
    return unsubscribe;
  }, []);

  const handleSaveSettings = async () => {
    try {
      setIsSaving(true);
      
      // Prepare the updates, including the date string
      const updates = {
        ...settings,
        lastPayDate: lastPayDate?.toISOString() || new Date().toISOString(),
      };
      
      await updateSettings(updates);
      
      toast({
        title: "Settings saved",
        description: "Your settings have been updated successfully.",
      });
    } catch (error) {
      toast({
        title: "Error saving settings",
        description: "There was a problem saving your settings. Please try again.",
        variant: "destructive",
      });
      console.error("Error saving settings:", error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="container mx-auto p-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Settings</h1>
      
      <Tabs defaultValue="general">
        <TabsList className="mb-6 bg-[#1E2A5E]">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="stocks">Stocks</TabsTrigger>
          <TabsTrigger value="testing">Testing</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general">
          <Card className="card-container">
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Configure your payment and billing preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="paymentStrategy">Payment Strategy</Label>
                  <Select 
                    value={settings.paymentStrategy} 
                    onValueChange={(value) => setSettings({...settings, paymentStrategy: value})}
                  >
                    <SelectTrigger id="paymentStrategy">
                      <SelectValue placeholder="Select a payment strategy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Proactive">Proactive (Distribute evenly)</SelectItem>
                      <SelectItem value="Reactive">Reactive (Pay as they come)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground">
                    {settings.paymentStrategy === "Proactive" 
                      ? "Bills are evenly distributed across pay periods" 
                      : "Bills are paid in the period they're due"}
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="payFrequency">Pay Frequency</Label>
                  <Select 
                    value={settings.payFrequency} 
                    onValueChange={(value) => setSettings({...settings, payFrequency: value})}
                  >
                    <SelectTrigger id="payFrequency">
                      <SelectValue placeholder="Select pay frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Weekly">Weekly</SelectItem>
                      <SelectItem value="Bi-Weekly">Bi-Weekly</SelectItem>
                      <SelectItem value="Semi-Monthly">Semi-Monthly</SelectItem>
                      <SelectItem value="Monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground">
                    How often you receive your paycheck
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lastPayDate">Reference Pay Date</Label>
                  <DatePicker
                    date={lastPayDate}
                    setDate={setLastPayDate}
                  />
                  <p className="text-sm text-muted-foreground">
                    Used to calculate future pay dates based on your pay frequency. 
                    This date will only change when you manually update it.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="billingCushion">Billing Cushion (%)</Label>
                  <Input
                    id="billingCushion"
                    type="number"
                    min="0"
                    max="20"
                    value={settings.billingCushion || "2"}
                    onChange={(e) => setSettings({...settings, billingCushion: e.target.value})}
                    className="max-w-xs"
                  />
                  <p className="text-sm text-muted-foreground">
                    Extra amount added to estimates for unexpected expenses
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="resetDate">Bill Status Reset Date</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="resetDate"
                      type="number"
                      min="1"
                      max="28"
                      value={settings.resetDate || "1"}
                      onChange={(e) => {
                        const value = parseInt(e.target.value);
                        if (value >= 1 && value <= 28) {
                          setSettings({...settings, resetDate: value});
                        }
                      }}
                      className="max-w-[100px]"
                    />
                    <p className="text-sm">of each month</p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Day of month when paid/skipped bills will automatically reset to upcoming status
                  </p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="autoResetEnabled" className="text-base cursor-pointer">
                      Automatic Bill Reset
                    </Label>
                    <Switch 
                      id="autoResetEnabled"
                      checked={settings.autoResetEnabled ?? true}
                      onCheckedChange={(checked) => 
                        setSettings({...settings, autoResetEnabled: checked})
                      }
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    When enabled, all paid/skipped bills will automatically reset to "upcoming" status
                    on the reset date each month
                  </p>
                </div>
              </div>
              
              <Button 
                onClick={handleSaveSettings} 
                disabled={isSaving}
                className="mt-4"
              >
                {isSaving ? "Saving..." : "Save Settings"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="stocks">
          <Card className="card-container">
            <CardHeader>
              <CardTitle>Stock Watchlist</CardTitle>
              <CardDescription>
                Manage stocks you want to track in the ticker
              </CardDescription>
            </CardHeader>
            <CardContent>
              <StockSettings />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="testing">
          <Card className="card-container">
            <CardHeader>
              <CardTitle>Date Testing</CardTitle>
              <CardDescription>
                Test how the application works with different dates
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="mockDate">Mock Current Date</Label>
                    <DatePicker
                      date={mockDate || undefined}
                      setDate={(date) => setMockDateState(date || null)}
                    />
                    <p className="text-sm text-muted-foreground">
                      Select a date to simulate how the application would behave on that day
                    </p>
                  </div>

                  <div className="flex space-x-2 pt-2">
                    <Button 
                      onClick={() => {
                        if (mockDate) {
                          setMockDate(mockDate);
                          toast({
                            title: "Mock Date Set",
                            description: `Application is now running as if it's ${mockDate.toLocaleDateString()}`,
                          });
                        }
                      }}
                      variant="default"
                      disabled={!mockDate}
                    >
                      Apply Mock Date
                    </Button>
                    
                    <Button 
                      onClick={() => {
                        setMockDate(null);
                        setMockDateState(null);
                        toast({
                          title: "Mock Date Cleared",
                          description: "Application is now using the real current date",
                        });
                      }}
                      variant="outline"
                    >
                      Reset to Real Date
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-lg font-medium">Current Date:</h3>
                  <div className="p-4 bg-blue-900/40 rounded-md border border-blue-800">
                    <p className="text-xl">{getCurrentDate().toLocaleDateString('en-US', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      {mockDate 
                        ? "Using mock date (all calculations use this date instead of the real date)" 
                        : "Using real system date"}
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    This feature is useful for testing how bills, due dates, and draft calculations 
                    will appear on different dates without having to change your system clock.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}