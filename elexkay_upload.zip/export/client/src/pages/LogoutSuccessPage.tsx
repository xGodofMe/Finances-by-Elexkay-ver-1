import { useEffect, useState, useRef } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";

export default function LogoutSuccessPage() {
  const [, navigate] = useLocation();
  const [countdown, setCountdown] = useState(30);
  const navigateRef = useRef(navigate);
  const hasPlayedAudioRef = useRef(false);

  // Set up navigate ref
  useEffect(() => {
    navigateRef.current = navigate;
  }, [navigate]);

  // Check if audio already played in the logout process
  useEffect(() => {
    // Don't play audio twice - we already play it in use-auth.tsx during logout
    const audioAlreadyPlayed = localStorage.getItem('logoutAudioPlayed') === 'true';
    
    // If already played, just clean up the flag
    if (audioAlreadyPlayed) {
      localStorage.removeItem('logoutAudioPlayed');
      hasPlayedAudioRef.current = true;
      return;
    }
    
    // Skip playing if already done in this component
    if (hasPlayedAudioRef.current) return;
    hasPlayedAudioRef.current = true;
    
    // Get the stored voice from login using the exact same method as in audio-utils.ts
    const platformType = localStorage.getItem('platformType') || detectPlatform();
    const storedVoice = localStorage.getItem(`selectedVoice_${platformType}`) || localStorage.getItem('selectedVoice');
    
    console.log("Audio not previously played, playing now in LogoutSuccessPage with voice:", storedVoice);
    
    // Play chime sound
    playLogoutChime();
    
    // Play voice message using the same voice as login
    speakLogoutMessage(storedVoice);
  }, []);

  // Auto redirect countdown after 30 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Use setTimeout to avoid state updates during render
          setTimeout(() => {
            navigateRef.current("/auth");
          }, 0);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);
  
  // Helper function to detect platform type
  function detectPlatform(): 'ios' | 'android' | 'desktop' {
    const userAgent = navigator.userAgent.toLowerCase();
    
    if (/iphone|ipad|ipod/.test(userAgent)) {
      return 'ios';
    } else if (/android/.test(userAgent)) {
      return 'android';
    } else {
      return 'desktop';
    }
  }
  
  // Play a gentle chime sound on logout
  function playLogoutChime() {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      const playNote = (freq: number, start: number, duration: number) => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.value = freq;
        
        gainNode.gain.setValueAtTime(0.1, start);
        gainNode.gain.exponentialRampToValueAtTime(0.001, start + duration);
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.start(start);
        oscillator.stop(start + duration);
      };
      
      // Play a pleasant descending melody
      playNote(988.0, audioContext.currentTime, 0.2);      // B5
      playNote(784.0, audioContext.currentTime + 0.2, 0.2); // G5
      playNote(659.3, audioContext.currentTime + 0.4, 0.2); // E5
      playNote(523.3, audioContext.currentTime + 0.6, 0.4); // C5
    } catch (error) {
      console.error("Could not play logout chime:", error);
    }
  }
  
  // Speak the logout message using same voice as login
  function speakLogoutMessage(voiceName: string | null) {
    if (!window.speechSynthesis) {
      console.error("Speech synthesis not supported");
      return;
    }
    
    // Create utterance with logout message
    const utterance = new SpeechSynthesisUtterance(
      "Thank you for investing in you, until next time. Good day."
    );
    
    // Set the same voice used during login
    if (voiceName) {
      const voices = window.speechSynthesis.getVoices();
      
      // IMPORTANT: Special case for Ezinne voice to prevent switching to male voice
      if (voiceName.includes("Ezinne")) {
        // Using exact match only for Microsoft Ezinne to prevent using male Nigerian voice
        const ezinneVoice = voices.find(v => 
          v.name === 'Microsoft Ezinne Online (Natural) - English (Nigeria)' ||
          v.name === 'Microsoft Ezinne Online - English (Nigeria)' ||
          v.name === 'Microsoft Ezinne - English (Nigeria)' ||
          v.name === 'Ezinne'
        );
        
        if (ezinneVoice) {
          console.log("Using exact Ezinne voice match for logout page:", ezinneVoice.name);
          utterance.voice = ezinneVoice;
        }
      } else {
        // For other voices, use standard name matching
        const savedVoice = voices.find(v => v.name === voiceName);
        
        if (savedVoice) {
          console.log("Using saved voice for logout page:", savedVoice.name);
          utterance.voice = savedVoice;
        } else {
          // Wait for voices to load if they haven't yet
          window.speechSynthesis.onvoiceschanged = () => {
            const updatedVoices = window.speechSynthesis.getVoices();
            
            // Check for Ezinne again
            if (voiceName.includes("Ezinne")) {
              const ezinneVoice = updatedVoices.find(v => 
                v.name === 'Microsoft Ezinne Online (Natural) - English (Nigeria)' ||
                v.name === 'Microsoft Ezinne Online - English (Nigeria)' ||
                v.name === 'Microsoft Ezinne - English (Nigeria)' ||
                v.name === 'Ezinne'
              );
              
              if (ezinneVoice) {
                utterance.voice = ezinneVoice;
                window.speechSynthesis.speak(utterance);
                return;
              }
            }
            
            // For other voices
            const voice = updatedVoices.find(v => v.name === voiceName);
            if (voice) {
              utterance.voice = voice;
              window.speechSynthesis.speak(utterance);
            }
          };
        }
      }
    }
    
    // Set other properties and speak
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    
    window.speechSynthesis.speak(utterance);
  }

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-full max-w-md p-8 space-y-6 bg-[#1E293B]/80 backdrop-blur-lg rounded-xl border border-blue-900/30 shadow-2xl">
        <div className="text-center space-y-2">
          <div className="bg-green-500/20 text-green-400 rounded-full p-4 w-16 h-16 mx-auto flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-white">Successfully Logged Out</h1>
          <p className="text-blue-200">Thank you for investing in yourself!</p>
        </div>

        <div className="mt-8 space-y-4">
          <p className="text-center text-slate-400">
            You'll be redirected to the login page in <span className="text-white font-bold">{countdown}</span> seconds.
          </p>
          
          <div className="flex justify-center">
            <Button
              onClick={() => navigate("/auth")}
              className="flex items-center space-x-2"
              size="lg"
            >
              <LogIn className="h-5 w-5" />
              <span>Return to Login</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}