import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Plus, Check, X, MessageSquare, Bug, Lightbulb } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";

interface Suggestion {
  id: number;
  userId: number;
  title: string;
  description: string;
  type: string;
  status: string;
  createdAt: string;
  updatedAt: string | null;
  resolved: boolean;
  adminResponse: string | null;
}

export default function SuggestionsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [newSuggestion, setNewSuggestion] = useState({
    title: "",
    description: "",
    type: "feature"
  });
  const [selectedSuggestion, setSelectedSuggestion] = useState<Suggestion | null>(null);

  // Fetch suggestions
  const { data: suggestions, isLoading, error: suggestionsError } = useQuery<Suggestion[]>({
    queryKey: ["/api/suggestions"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/suggestions");
      return res.json();
    }
  });
  
  // Handle errors
  useEffect(() => {
    if (suggestionsError) {
      toast({
        title: "Error",
        description: `Failed to load suggestions: ${(suggestionsError as Error).message}`,
        variant: "destructive",
      });
    }
  }, [suggestionsError, toast]);

  // Submit new suggestion
  const submitSuggestionMutation = useMutation({
    mutationFn: async (data: typeof newSuggestion) => {
      const res = await apiRequest("POST", "/api/suggestions", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions"] });
      setIsFormOpen(false);
      setNewSuggestion({ title: "", description: "", type: "feature" });
      toast({
        title: "Suggestion Submitted",
        description: "Thank you for your feedback!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to submit suggestion: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update suggestion (admin only)
  const updateSuggestionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Suggestion> }) => {
      const res = await apiRequest("PUT", `/api/suggestions/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions"] });
      toast({
        title: "Suggestion Updated",
        description: "The suggestion has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update suggestion: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete suggestion
  const deleteSuggestionMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/suggestions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/suggestions"] });
      toast({
        title: "Suggestion Deleted",
        description: "The suggestion has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete suggestion: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewSuggestion(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleTypeChange = (value: string) => {
    setNewSuggestion(prev => ({
      ...prev,
      type: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSuggestion.title.trim() || !newSuggestion.description.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    submitSuggestionMutation.mutate(newSuggestion);
  };

  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this suggestion?")) {
      deleteSuggestionMutation.mutate(id);
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "new":
        return "bg-blue-500/20 text-blue-500 hover:bg-blue-500/30";
      case "reviewing":
        return "bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30";
      case "implemented":
        return "bg-green-500/20 text-green-500 hover:bg-green-500/30";
      case "rejected":
        return "bg-red-500/20 text-red-500 hover:bg-red-500/30";
      default:
        return "bg-slate-500/20 text-slate-500 hover:bg-slate-500/30";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "feature":
        return <Lightbulb className="h-4 w-4 mr-1" />;
      case "bug":
        return <Bug className="h-4 w-4 mr-1" />;
      case "improvement":
        return <MessageSquare className="h-4 w-4 mr-1" />;
      default:
        return <MessageSquare className="h-4 w-4 mr-1" />;
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Suggestions & Feedback</h1>
        <Button onClick={() => setIsFormOpen(true)}>
          <Plus className="h-4 w-4 mr-2" /> New Suggestion
        </Button>
      </div>

      {/* Suggestions List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {suggestions && suggestions.length > 0 ? (
          suggestions.map((suggestion: Suggestion) => (
            <Card 
              key={suggestion.id}
              className="backdrop-blur-lg bg-card/80 border-none shadow-lg hover:shadow-xl transition-all cursor-pointer"
              onClick={() => setSelectedSuggestion(suggestion)}
            >
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <Badge 
                    variant="outline" 
                    className={`flex items-center ${getStatusBadgeColor(suggestion.status)}`}
                  >
                    {suggestion.status.charAt(0).toUpperCase() + suggestion.status.slice(1)}
                  </Badge>
                  <Badge variant="outline" className="flex items-center">
                    {getTypeIcon(suggestion.type)}
                    {suggestion.type.charAt(0).toUpperCase() + suggestion.type.slice(1)}
                  </Badge>
                </div>
                <CardTitle className="text-xl mt-2">{suggestion.title}</CardTitle>
                <CardDescription>
                  {format(new Date(suggestion.createdAt), "MMM d, yyyy")}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="line-clamp-3 text-sm text-muted-foreground">
                  {suggestion.description}
                </p>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="col-span-3 text-center p-10 border border-dashed rounded-lg">
            <p className="text-muted-foreground">No suggestions yet. Be the first to suggest something!</p>
          </div>
        )}
      </div>

      {/* New Suggestion Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Submit New Suggestion</DialogTitle>
            <DialogDescription>
              Have an idea for improving our application? Share your feedback!
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  name="title"
                  value={newSuggestion.title}
                  onChange={handleInputChange}
                  placeholder="Brief title for your suggestion"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="type">Suggestion Type</Label>
                <RadioGroup
                  value={newSuggestion.type}
                  onValueChange={handleTypeChange}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="feature" id="feature" />
                    <Label htmlFor="feature" className="flex items-center">
                      <Lightbulb className="h-4 w-4 mr-1" /> Feature
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="bug" id="bug" />
                    <Label htmlFor="bug" className="flex items-center">
                      <Bug className="h-4 w-4 mr-1" /> Bug
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="improvement" id="improvement" />
                    <Label htmlFor="improvement" className="flex items-center">
                      <MessageSquare className="h-4 w-4 mr-1" /> Improvement
                    </Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={newSuggestion.description}
                  onChange={handleInputChange}
                  placeholder="Describe your suggestion in detail"
                  rows={5}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setIsFormOpen(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={submitSuggestionMutation.isPending}
              >
                {submitSuggestionMutation.isPending ? "Submitting..." : "Submit Suggestion"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Suggestion Details Dialog */}
      <Dialog 
        open={selectedSuggestion !== null} 
        onOpenChange={(open) => !open && setSelectedSuggestion(null)}
      >
        {selectedSuggestion && (
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <div className="flex justify-between">
                <Badge 
                  variant="outline" 
                  className={`flex items-center ${getStatusBadgeColor(selectedSuggestion.status)}`}
                >
                  {selectedSuggestion.status.charAt(0).toUpperCase() + selectedSuggestion.status.slice(1)}
                </Badge>
                <Badge variant="outline" className="flex items-center">
                  {getTypeIcon(selectedSuggestion.type)}
                  {selectedSuggestion.type.charAt(0).toUpperCase() + selectedSuggestion.type.slice(1)}
                </Badge>
              </div>
              <DialogTitle className="mt-2">{selectedSuggestion.title}</DialogTitle>
              <DialogDescription>
                Submitted on {format(new Date(selectedSuggestion.createdAt), "MMM d, yyyy")}
              </DialogDescription>
            </DialogHeader>
            
            <ScrollArea className="max-h-[300px] mt-2">
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium">Description</h4>
                  <p className="mt-1">{selectedSuggestion.description}</p>
                </div>
                
                {selectedSuggestion.adminResponse && (
                  <div className="mt-4 p-3 bg-primary/10 rounded-md">
                    <h4 className="text-sm font-medium flex items-center">
                      <MessageSquare className="h-4 w-4 mr-1" /> Response
                    </h4>
                    <p className="mt-1 text-sm">{selectedSuggestion.adminResponse}</p>
                  </div>
                )}
                
                {/* Admin response form - only visible to admins */}
                {user?.isAdmin && !selectedSuggestion.resolved && (
                  <div className="mt-4 border-t pt-4">
                    <h4 className="text-sm font-medium mb-2">Admin Actions</h4>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="status">Update Status</Label>
                        <select 
                          id="status"
                          className="w-full p-2 border rounded-md"
                          value={selectedSuggestion.status}
                          onChange={(e) => {
                            updateSuggestionMutation.mutate({
                              id: selectedSuggestion.id,
                              data: { status: e.target.value }
                            });
                          }}
                        >
                          <option value="new">New</option>
                          <option value="reviewing">Reviewing</option>
                          <option value="implemented">Implemented</option>
                          <option value="rejected">Rejected</option>
                        </select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="adminResponse">Response</Label>
                        <Textarea
                          id="adminResponse"
                          placeholder="Provide a response to this suggestion"
                          defaultValue={selectedSuggestion.adminResponse || ""}
                          rows={3}
                        />
                        <Button 
                          className="w-full mt-2"
                          onClick={() => {
                            const textarea = document.getElementById("adminResponse") as HTMLTextAreaElement;
                            updateSuggestionMutation.mutate({
                              id: selectedSuggestion.id, 
                              data: { 
                                adminResponse: textarea.value,
                                resolved: selectedSuggestion.status === "implemented" || selectedSuggestion.status === "rejected"
                              }
                            });
                          }}
                        >
                          Save Response
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
            
            <DialogFooter>
              <div className="w-full flex justify-between items-center">
                {/* Delete option - only for admins or the author */}
                {(user?.isAdmin || user?.id === selectedSuggestion.userId) && (
                  <Button 
                    variant="destructive" 
                    size="sm"
                    onClick={() => {
                      handleDelete(selectedSuggestion.id);
                      setSelectedSuggestion(null);
                    }}
                  >
                    <X className="h-4 w-4 mr-1" /> Delete
                  </Button>
                )}
                
                <div className="flex space-x-2 ml-auto">
                  <Button 
                    variant="outline" 
                    onClick={() => setSelectedSuggestion(null)}
                  >
                    Close
                  </Button>
                </div>
              </div>
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}