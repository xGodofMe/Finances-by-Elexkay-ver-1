import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useVoiceGuide } from "@/hooks/use-voice-guide";
import { Redirect } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { insertUserSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Volume2, Download } from "lucide-react";
import { VoiceGuideModal } from "@/components/VoiceGuideModal";

// Extend the insert schema with form-specific validations
const loginSchema = insertUserSchema;

const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(1, { message: "Confirm password is required" }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation, demoAccessMutation, isLoading } = useAuth();
  const { 
    showVoiceGuide, 
    setShowVoiceGuide, 
    platformType, 
    isMobileDevice, 
    hasEzinneVoice 
  } = useVoiceGuide();
  
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const [typedQuote, setTypedQuote] = useState<string>("");
  const [isTyping, setIsTyping] = useState<boolean>(true);
  const [greetingText, setGreetingText] = useState<string>("Welcome");
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [showVoiceSelector, setShowVoiceSelector] = useState<boolean>(false);
  const [selectedVoiceName, setSelectedVoiceName] = useState<string>(
    typeof localStorage !== 'undefined' ? localStorage.getItem('selectedVoice') || "" : ""
  );
  const quoteRef = useRef<string>("");
  const greetingRef = useRef<string>("");
  const synth = useRef<SpeechSynthesis | null>(null);
  const hasPlayedRef = useRef<boolean>(false);
  
  // This function creates and plays a welcoming sound
  function playWelcomeSound() {
    try {
      // Create audio context
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      
      const audioCtx = new AudioContext();
      const masterGain = audioCtx.createGain();
      masterGain.gain.value = 0.3; // Lower overall volume
      masterGain.connect(audioCtx.destination);
      
      // Create a pleasing chord progression
      const playNote = (frequency: number, startTime: number, duration: number, type: OscillatorType = 'sine') => {
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        
        oscillator.type = type;
        oscillator.frequency.value = frequency;
        
        // Set up fade in/out for a smooth sound
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.2, startTime + 0.05);
        gainNode.gain.setValueAtTime(0.2, startTime + duration - 0.05);
        gainNode.gain.linearRampToValueAtTime(0, startTime + duration);
        
        // Connect and schedule
        oscillator.connect(gainNode);
        gainNode.connect(masterGain);
        
        oscillator.start(startTime);
        oscillator.stop(startTime + duration);
      };
      
      // Play a pleasant chord progression
      const now = audioCtx.currentTime;
      
      // First chord - Major (harmony)
      playNote(261.63, now, 0.8);       // C4
      playNote(329.63, now + 0.1, 0.7); // E4
      playNote(392.00, now + 0.2, 0.6); // G4
      
      // Second note - higher
      playNote(523.25, now + 0.5, 0.5); // C5
      
      // Add a subtle background harmony
      playNote(196.00, now, 1.0, 'sine'); // G3 (lower harmony)
      
      // Add a very subtle white noise in the background for texture
      const bufferSize = 2 * audioCtx.sampleRate;
      const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 0.03 - 0.015; // Very quiet white noise
      }
      
      const whiteNoise = audioCtx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      
      const noiseGain = audioCtx.createGain();
      noiseGain.gain.value = 0.006; // Very quiet
      
      whiteNoise.connect(noiseGain);
      noiseGain.connect(masterGain);
      
      whiteNoise.start();
      whiteNoise.stop(now + 1.0);
      
    } catch (e) {
      console.log("Could not play welcome sound", e);
    }
  }
  
  // This function will force browsers to preload speech synthesis voices
  function forceSpeechSynthesis() {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      // Create and close an utterance to trigger voice loading
      const u = new SpeechSynthesisUtterance(" ");
      u.volume = 0; // Silent
      window.speechSynthesis.speak(u);
      window.speechSynthesis.cancel();
      
      // Force the browser to load voices
      window.speechSynthesis.getVoices();
    }
  }
  
  // Speech synthesis setup with auto-start functionality
  useEffect(() => {
    // Detect device platform
    const detectPlatform = () => {
      const userAgent = 
        typeof window !== 'undefined' && navigator.userAgent || '';
      
      // Detect if this is a mobile device
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
      
      // Detect specific platform
      const isIOS = /iPad|iPhone|iPod/.test(userAgent);
      const isAndroid = /Android/i.test(userAgent);
      
      let platform: 'ios' | 'android' | 'desktop' = 'desktop';
      
      if (isIOS) {
        platform = 'ios';
        console.log("iOS device detected, applying special audio handling");
      } else if (isAndroid) {
        platform = 'android';
        console.log("Android device detected, applying special audio handling");
      }
      
      // Store platform in localStorage for persistent experience
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('platformType', platform);
        
        // Also retrieve platform-specific voice preference if available
        const platformVoice = localStorage.getItem(`selectedVoice_${platform}`);
        if (platformVoice) {
          setSelectedVoiceName(platformVoice);
          console.log(`Loaded saved voice preference "${platformVoice}" for platform ${platform}`);
        } else {
          console.log(`No saved voice preference found for platform ${platform}`);
        }
      }
      
      console.log("Device detection - Mobile:", isMobile, "Platform:", platform, "User Agent:", userAgent);
      return { isMobile, platform };
    };
    
    const { isMobile, platform } = detectPlatform();
    
    // Initialize speech synthesis
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      synth.current = window.speechSynthesis;
      
      // Force-load voices
      forceSpeechSynthesis();
      
      // Create a silent audio context to unlock audio on iOS/Safari
      const unlockAudio = () => {
        const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContext) {
          const audioCtx = new AudioContext();
          // Create a short silent buffer and play it
          const buffer = audioCtx.createBuffer(1, 1, 22050);
          const source = audioCtx.createBufferSource();
          source.buffer = buffer;
          source.connect(audioCtx.destination);
          source.start(0);
          
          // Also try to unlock Web Speech API
          const silent = new SpeechSynthesisUtterance('');
          silent.volume = 0;
          window.speechSynthesis.speak(silent);
        }
      };
      
      // Try to unlock audio immediately
      unlockAudio();
      
      // Create a visible "Click to Enable Audio" button for browsers with strict policies
      const createVisibleAudioButton = () => {
        // First remove any existing buttons
        const existingButton = document.getElementById('enable-audio-button');
        if (existingButton) {
          existingButton.remove();
        }
        
        const audioUnlockButton = document.createElement('button');
        audioUnlockButton.id = 'enable-audio-button';
        audioUnlockButton.textContent = 'Click to Enable Sound';
        audioUnlockButton.style.position = 'fixed';
        audioUnlockButton.style.top = '50%';
        audioUnlockButton.style.left = '50%';
        audioUnlockButton.style.transform = 'translate(-50%, -50%)';
        audioUnlockButton.style.padding = '12px 24px';
        audioUnlockButton.style.backgroundColor = '#2563eb';
        audioUnlockButton.style.color = 'white';
        audioUnlockButton.style.border = 'none';
        audioUnlockButton.style.borderRadius = '6px';
        audioUnlockButton.style.fontFamily = 'sans-serif';
        audioUnlockButton.style.fontSize = '16px';
        audioUnlockButton.style.cursor = 'pointer';
        audioUnlockButton.style.zIndex = '10000';
        audioUnlockButton.style.boxShadow = '0 4px 10px rgba(0, 0, 0, 0.3)';
        
        // Add a semi-transparent overlay
        const overlay = document.createElement('div');
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.width = '100%';
        overlay.style.height = '100%';
        overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
        overlay.style.zIndex = '9999';
        
        document.body.appendChild(overlay);
        document.body.appendChild(audioUnlockButton);
        
        audioUnlockButton.addEventListener('click', () => {
          unlockAudio();
          if (overlay.parentNode) {
            document.body.removeChild(overlay);
          }
          if (audioUnlockButton.parentNode) {
            document.body.removeChild(audioUnlockButton);
          }
          
          // Set a flag to indicate we've played audio
          hasPlayedRef.current = true;
          
          // Try to play the greeting again after user interaction
          if (synth.current && greetingRef.current && quoteRef.current) {
            synth.current.cancel(); // Clear any previous utterances
            const voices = synth.current.getVoices();
            
            // Get selected voice from localStorage
            const savedVoiceName = localStorage.getItem('selectedVoice');
            let voice = null;
            
            if (savedVoiceName) {
              voice = voices.find(v => v.name === savedVoiceName);
            }
            
            // Special handling for mobile devices
            if (!voice && isMobileDevice) {
              console.log("Mobile device detected, using mobile voice priorities");
              
              // Mobile voice priorities - prioritize common mobile voices first
              const mobilePriorityVoices = [
                'Samantha', 'Karen', 'Moira', 'Tessa', 
                'Google US English Female', 'Google UK English Female',
                'iOS Samantha', 'iOS Karen', 'iOS Moira',
                'Android Female', 'Female', 'en-US', 'en-GB'
              ];
              
              for (const voiceName of mobilePriorityVoices) {
                voice = voices.find(v => 
                  v.name.includes(voiceName) || 
                  v.name === voiceName ||
                  (v.lang && v.lang.startsWith('en') && v.name.toLowerCase().includes('female'))
                );
                if (voice) {
                  console.log("Using mobile priority voice:", voice.name);
                  break;
                }
              }
            }
            
            // If no saved voice or mobile voice found, try to use Ezinne or other desktop priority voices
            if (!voice) {
              const priorityVoices = [
                'Ezinne', 'Microsoft Ezinne Online', 'Microsoft Ezinne',
                'Samantha', 'Google US English Female', 'Zira'
              ];
              
              for (const voiceName of priorityVoices) {
                voice = voices.find(v => v.name.includes(voiceName));
                if (voice) {
                  console.log("Using desktop priority voice:", voice.name);
                  break;
                }
              }
            }
            
            // Last resort: just pick any English voice
            if (!voice) {
              voice = voices.find(v => v.lang && v.lang.startsWith('en'));
              if (voice) {
                console.log("Using fallback English voice:", voice.name);
              }
            }
            
            // Create and speak the utterance
            const utterance = new SpeechSynthesisUtterance(greetingRef.current + quoteRef.current);
            if (voice) {
              utterance.voice = voice;
            }
            utterance.rate = 0.85;
            utterance.pitch = 1.15;
            utterance.volume = 0.95;
            synth.current.speak(utterance);
          }
        });
      };
      
      // First try the invisible button approach
      const invisibleUnlockButton = document.createElement('button');
      invisibleUnlockButton.textContent = 'Enable Audio';
      invisibleUnlockButton.style.position = 'fixed';
      invisibleUnlockButton.style.top = '0';
      invisibleUnlockButton.style.left = '0';
      invisibleUnlockButton.style.width = '100%';
      invisibleUnlockButton.style.height = '100%';
      invisibleUnlockButton.style.backgroundColor = 'transparent';
      invisibleUnlockButton.style.border = 'none';
      invisibleUnlockButton.style.cursor = 'default';
      invisibleUnlockButton.style.zIndex = '9999';
      invisibleUnlockButton.style.opacity = '0';
      
      document.body.appendChild(invisibleUnlockButton);
      
      invisibleUnlockButton.addEventListener('click', () => {
        unlockAudio();
        if (invisibleUnlockButton.parentNode) {
          document.body.removeChild(invisibleUnlockButton);
        }
        hasPlayedRef.current = true;
      });
      
      // Auto-click the invisible button after a small delay
      setTimeout(() => {
        invisibleUnlockButton.click();
      }, 100);
      
      // Show the visible button if auto-play doesn't work within 2 seconds
      setTimeout(() => {
        if (!hasPlayedRef.current) {
          createVisibleAudioButton();
        }
      }, 2000);
      
      // Add a visible play button that shows up when deployed to handle browsers 
      // that strictly require user interaction
      const handleVisibilityChange = () => {
        if (document.visibilityState === 'visible' && !hasPlayedRef.current) {
          setTimeout(() => {
            if (!hasPlayedRef.current) {
              createVisibleAudioButton();
            }
          }, 1000);
        }
      };
      
      document.addEventListener('visibilitychange', handleVisibilityChange);
      
      return () => {
        // Clean up
        document.removeEventListener('visibilitychange', handleVisibilityChange);
        
        // Cancel any ongoing speech when component unmounts
        if (synth.current) {
          synth.current.cancel();
        }
      };
    }
    
    return () => {
      // Cancel any ongoing speech when component unmounts
      if (synth.current) {
        synth.current.cancel();
      }
    };
  }, []);
  
  // Get a random quote and set up typing animation
  useEffect(() => {
    const quotes = [
      // Original quotes
      "Wealth is the ability to fully experience life. – Henry David Thoreau",
      "A budget is telling your money where to go instead of wondering where it went. – Dave Ramsey",
      "Discipline is the bridge between goals and accomplishment. – Jim Rohn",
      "Time is a currency. Spend it wisely.",
      "What you track, you control. What you control, you master.",
      "Prosperity begins with clarity.",
      "Your financial peace isn't in what you earn, but in what you manage.",
      "Luxury is not a price — it's a choice to move with intention.",
      "Abundance flows through structure.",
      "Even kings keep ledgers.",
      "Clarity today creates freedom tomorrow.",
      "Pay attention to the pennies, and the dollars will follow.",
      "Elegance is found in the details — even in your budget.",
      "Money talks. Yours should speak your name.",
      "You don't need more — just mastery of what you have.",
      
      // Additional financial quotes
      "The flex is financial freedom, not fashion.",
      "Financial freedom is knowing your future is secure.",
      "Small savings create big futures.",
      "Track every expense, celebrate every win.",
      "Wealth isn't having money; it's having options.",
      "Financial discipline is freedom's foundation.",
      "Master money or it will master you.",
      "Spend on what matters, save for what's coming.",
      "Your wealth journey begins with a single plan.",
      "The best time to budget was yesterday. The second best is today.",
      "Build your tomorrow by managing your today.",
      "Rich isn't a number. Rich is a lifestyle within your means.",
      "A penny saved is more than a penny earned.",
      "Invest in your future self.",
      "Financial clarity brings mental calm.",
      "Budget like a lighthouse—guiding through calm and storm.",
      "Your income is your greatest wealth-building tool.",
      "Money management isn't about restriction—it's about direction.",
      "Consistent habits build uncommon wealth.",
      "The path to wealth is simple, but not easy.",
      "Debt is a tax on your future self.",
      "Live like others won't today, so you can live like others can't tomorrow.",
      "Financial peace doesn't come from acquisition, but from appreciation.",
      "The first step to getting rich is knowing where you stand.",
      "Your budget isn't just numbers—it's your priorities in action.",
      "Smart money decisions are made in advance, not in the moment.",
      "Wealth is measured in time, not dollars.",
      "Every dollar in your budget needs a purpose.",
      "The only bad budget is no budget at all.",
      "Money problems are behavior problems, not math problems.",
      "Generational wealth begins with generational knowledge.",
      "Financial intelligence is the new currency.",
      "The greatest return on investment is in yourself.",
      "Budgeting is writing your future in today's numbers.",
      "Financial growth comes from intentional actions, not incidental ones.",
      "Wealth building isn't a sprint; it's a marathon with a plan.",
      "The true measure of wealth is having what money can't buy.",
      "Spend on appreciating assets, not depreciating liabilities.",
      "Compound interest is the eighth wonder of the world.",
      "Build assets that work while you sleep.",
      "Your financial habits determine your financial altitude.",
      "Money isn't everything, but it affects everything.",
      "The millionaire mindset begins with millionaire habits.",
      "Financial security isn't luck—it's intentional design.",
      "A financial plan without action is just a wish.",
      "Be smart with the money you have, not the money you wish for.",
      "Your financial health is as important as your physical health.",
      "Legacy wealth comes from legacy thinking.",
      "Track it, hack it, stack it, max it.",
      "Rich isn't what you spend, but what you keep.",
      "The formula is simple: Earn. Save. Invest. Repeat.",
      "Spend less than you earn, invest the difference.",
      "Financial stability is more valuable than momentary luxury.",
      "Better a small budget followed exactly than no budget at all.",
      "The root of financial success is delayed gratification.",
      "Your financial future is created by today's decisions.",
      "Margin in your finances creates freedom in your life.",
      "Automate your finances to align with your intentions.",
      "The best returns come from long-term thinking.",
      "Knowledge builds wealth faster than labor.",
      "Financial independence is built with consistent effort, not occasional brilliance.",
      "Money isn't the goal; money is the tool for reaching goals.",
      "It's not how much you make, but how much you keep that determines wealth.",
      "Wealth accumulation is a series of small, smart decisions over time.",
      "Always prepare for lean times during abundant ones.",
      "The wealthy buy assets while the poor buy liabilities.",
      "A fool and his money are invited everywhere.",
      "Money doesn't buy happiness, but it does buy options.",
      "Save like a pessimist, invest like an optimist.",
      "Life's financial storms require more than an umbrella.",
      "Tomorrow's wealth is built on today's self-control.",
      "Regular investing is the path to irregular wealth.",
      "Simplicity in finances leads to clarity in life.",
      "Build multiple streams of income, not just one river.",
      "A wealthy mindset precedes a wealthy bank account.",
      "Time in the market beats timing the market.",
      "Pay yourself first—your future depends on it.",
      "Financial planning isn't predicting the future, it's preparing for it.",
      "The best financial gift is teaching financial literacy.",
      "Wealth isn't about having a lot, but needing very little.",
      "The most valuable financial asset is resilience.",
      "True financial freedom is having enough.",
      "Plan like you'll live forever, spend like there's no tomorrow.",
      "Knowledge grows wealth faster than interest.",
      "Financial peace comes from living within your harvest.",
      "The most valuable currency is not money, but time.",
      "Focus on value creation, not just income generation.",
      "Avoid debt like it's a disease, because financially, it is.",
      "Live within your means and your future self will thank you.",
      "Financial security isn't about luck—it's about preparation.",
      "Wealth is the ability to say 'no' to things that don't matter.",
      "Success is using money as a tool, not becoming its servant.",
      "Every expense is a vote for the life you want to live.",
      "The secret to having money is to save money.",
      "Financial intelligence begins with financial awareness.",
      "Build your fortress of financial security one brick at a time.",
      "The discipline of saving creates the freedom of choice.",
      "A financial plan is a road map to your dreams."
    ];
    
    // Generate a random index based on the current time
    const randomIndex = Math.floor(Date.now() % quotes.length);
    quoteRef.current = quotes[randomIndex];
    
    // Get the greeting based on time of day
    const hour = new Date().getHours();
    
    // Check localStorage for any saved user information
    let salutation = "human";
    try {
      if (typeof localStorage !== 'undefined') {
        const storedProfileData = localStorage.getItem('profileForm');
        const storedUserInfo = storedProfileData ? JSON.parse(storedProfileData) : null;
        
        if (storedUserInfo) {
          // Preferred format is "Title LastName" (e.g., "Mr. Kweli")
          if (storedUserInfo.title && storedUserInfo.lastName) {
            salutation = `${storedUserInfo.title} ${storedUserInfo.lastName}`;
          } 
          // Fallback to just title and first name if last name isn't available
          else if (storedUserInfo.title && storedUserInfo.firstName) {
            salutation = `${storedUserInfo.title} ${storedUserInfo.firstName}`;
          }
          // Fallback to just the last name
          else if (storedUserInfo.lastName) {
            salutation = storedUserInfo.lastName;
          }
          // Last fallback to the first name
          else if (storedUserInfo.firstName) {
            salutation = storedUserInfo.firstName;
          }
          
          // Store the phonetic breakdown if available, for the speech synthesis
          if (storedUserInfo.phoneticLastName) {
            // We'll use this variable in the speech synthesis section
            // Using localStorage for this instead of window object
            localStorage.setItem('phoneticLastName', storedUserInfo.phoneticLastName);
          }
        }
      }
    } catch (error) {
      console.error("Error retrieving user profile data:", error);
    }
    
    if (hour < 12) {
      greetingRef.current = `Good Morning, ${salutation}. Welcome to Elexkay. `;
    } else if (hour < 18) {
      greetingRef.current = `Good Afternoon, ${salutation}. Welcome to Elexkay. `;
    } else {
      greetingRef.current = `Good Evening, ${salutation}. Welcome to Elexkay. `;
    }
    
    // Also update the displayed greeting on the page
    let timeBasedGreeting = '';
    if (hour < 12) {
      timeBasedGreeting = 'Good Morning';
    } else if (hour < 18) {
      timeBasedGreeting = 'Good Afternoon';
    } else {
      timeBasedGreeting = 'Good Evening';
    }
    
    // Set the greeting text with the user's name
    setGreetingText(`${timeBasedGreeting}, ${salutation}`); // This sets the visible greeting on the page
    
    // Speak the greeting and quote with a woman's voice
    if (synth.current) {
      const speakText = () => {
        const utterance = new SpeechSynthesisUtterance(greetingRef.current + quoteRef.current);
        
        // Get available voices
        let voices = synth.current?.getVoices() || [];
        
        // If no voices are available yet, wait for them to load
        if (voices.length === 0) {
          // One-time event listener for voiceschanged
          window.speechSynthesis.addEventListener('voiceschanged', () => {
            voices = synth.current?.getVoices() || [];
            selectVoiceAndSpeak();
          }, { once: true });
        } else {
          // Voices already loaded
          selectVoiceAndSpeak();
        }
        
        function selectVoiceAndSpeak() {
          console.log("Available voices:", voices.map(v => v.name).join(", "));

          // Save all voices for the voice selector
          setAvailableVoices(voices);
          
          // First play the welcome sound melody
          playWelcomeSound();
          
          // Important: Make sure we can use the voice directly in this function
          let voiceForImmediate = null;
          
          // Check if we need to use phonetic breakdown for last name
          const phoneticLastName = localStorage.getItem('phoneticLastName');
          if (phoneticLastName && greetingRef.current) {
            // Replace the actual last name with the phonetic version in the greeting
            // This is tricky since we don't know the actual last name here, but we can try with the salutation
            const words = greetingRef.current.split(' ');
            // The user's name usually appears in the second or third position in the greeting
            // Example: "Good Morning Mr. Kweli" -> try to replace "Kweli" with phonetic version
            const salutationWords = salutation.split(' ');
            
            // If it's a multi-word salutation (title + name), we want to preserve the title
            if (salutationWords.length > 1) {
              // The last word in the salutation is likely the last name
              const lastName = salutationWords[salutationWords.length - 1];
              
              console.log("Using phonetic pronunciation for last name:", phoneticLastName);
              // Replace the last name in the greeting with phonetic version
              greetingRef.current = greetingRef.current.replace(lastName, phoneticLastName);
            }
          }
          
          // Priority lists for different platforms
          // Desktop priorities - focus on African (especially Nigerian) and British voices first as requested
          const desktopVoicePriorities = [
            // Nigerian voices (highest priority) - STRICT matching for Ezinne
            'Ezinne', 'Microsoft Ezinne Online', 'Microsoft Ezinne', 
            // Other female Nigerian/African voices (high priority)
            'Chioma', 'Nneka', 'Adeola', 'Tessa', 
            // Female South African voices
            'Tessa South Africa', 'Female South Africa', 'ZA Female',
            // British voices (third priority)
            'Microsoft Libby Online', 'Microsoft Ryan Online', 'British', 'UK English',
            'English (United Kingdom)', 'Google UK English Female', 'Google UK English Male',
            'en-GB', 'Microsoft Susan', 'Microsoft George', 'Microsoft Hazel',
            // Other quality voices as fallbacks
            'Samantha', 'Google US English Female', 'Ava', 'Lily', 'Victoria',
            'Microsoft Zira', 'Karen', 'Moira', 'Allison', 'Amelie', 
            'Serena', 'Princess', 'Nicky', 'Olivia', 'Veena', 'Fiona', 'Meena', 
            'Samantha (Enhanced)', 'Lisa', 'Amy'
          ];
          
          // iOS-specific priorities - prioritize African (especially Nigerian) voices, then British voices
          const iosVoicePriorities = [
            // Nigerian voices (highest priority)
            'Ezinne', 'Nigerian', 'Nigeria', 'Yoruba', 'Igbo', 'Hausa', 'Lagos',
            // Other African voices (high priority)
            'Tessa', 'South Africa', 'ZA', 'en-ZA', 'Kenya', 'Swahili', 'Ghana', 'Akan',
            'Amharic', 'Ethiopia', 'Afrikaans', 'Zulu', 'Africa', 'African', 'Chioma', 'Nneka', 'Adeola',
            // British voices (third priority)
            'British', 'English (UK)', 'UK', 'English (United Kingdom)', 
            'Libby', 'Daniel British', 'Tessa British', 
            // Common iOS voices as fallbacks (most common on iOS)
            'Samantha', 'Samantha (Enhanced)', 'Samantha (Premium)', 
            'Karen', 'Moira', 'Allison', 'Susan', 'Ava',
            'Victoria', 'Serena', 'Siri Voice 2', 'Siri Female', 'Alex'
          ];
          
          // Android-specific priorities - prioritize African (especially Nigerian) voices, then British voices
          const androidVoicePriorities = [
            // Nigerian voices first
            'Ezinne', 'Nigerian', 'Nigeria', 'Yoruba', 'Igbo', 'Hausa', 'Lagos',
            // Other African voices
            'Tessa', 'South Africa', 'ZA', 'en-ZA', 'Kenya', 'Swahili', 'Ghana', 'Akan',
            'Amharic', 'Ethiopia', 'Afrikaans', 'Zulu', 'Africa', 'African', 'Chioma', 'Nneka', 'Adeola',
            // South African English voice (commonly available on Android)
            'en-ZA-Standard-Female', 'en-ZA-Wavenet-Female', 'en-ZA-Female',
            // British voices next
            'British', 'Google UK English Female', 'Google UK English Male',
            'en-GB', 'en-GB-Standard-Female', 'en-GB-Wavenet-Female',
            'English UK Female', 'English (UK) Female', 'UK English',
            // Common Android voice patterns
            'Google US English Female', 'Google US English Male',
            'en-US-Standard-Female', 'en-US-Wavenet-Female',
            'Android Female', 'English US Female', 'English (US) Female'
          ];
          
          // Fallback priorities for any platform
          const fallbackVoicePriorities = [
            'Female', 'Woman', 'Girl', 'en-US', 'en-GB', 
            'English Female', 'English US', 'English'
          ];
          
          // Select the appropriate priority list based on detected platform
          let primaryVoicePriorities: string[] = [];
          let secondaryVoicePriorities: string[] = [];
          
          // Platform-specific voice selection strategy
          if (platformType === 'ios') {
            console.log("Using iOS-specific voice priorities");
            primaryVoicePriorities = iosVoicePriorities;
            secondaryVoicePriorities = [...androidVoicePriorities, ...desktopVoicePriorities];
          } else if (platformType === 'android') {
            console.log("Using Android-specific voice priorities");
            primaryVoicePriorities = androidVoicePriorities;
            secondaryVoicePriorities = [...iosVoicePriorities, ...desktopVoicePriorities];
          } else {
            console.log("Using desktop-specific voice priorities");
            primaryVoicePriorities = desktopVoicePriorities;
            secondaryVoicePriorities = [...iosVoicePriorities, ...androidVoicePriorities];
          }
          
          // Combine all priorities with a sensible fallback order
          const softFemaleVoicePriorities = [
            ...primaryVoicePriorities, 
            ...secondaryVoicePriorities,
            ...fallbackVoicePriorities
          ];
          
          // Try platform-specific stored voices first
          if (typeof localStorage !== 'undefined') {
            const platformSavedVoice = localStorage.getItem(`selectedVoice_${platformType}`);
            if (platformSavedVoice) {
              console.log(`Checking for platform-specific saved voice: ${platformSavedVoice}`);
              const voice = voices.find(v => v.name === platformSavedVoice);
              if (voice) {
                console.log(`Found platform-specific saved voice for ${platformType}: ${voice.name}`);
                setSelectedVoiceName(voice.name);
                voiceForImmediate = voice;
                // Don't return here, we need to set the voice directly on utterance for immediate playback
              } else {
                console.log(`Platform-specific saved voice "${platformSavedVoice}" not available on this device`);
                
                // The saved voice isn't available - try to find a similar voice that might be available
                // This is especially important for mobile devices where voice availability varies greatly
                if (platformType === 'ios') {
                  // For iOS, prioritize finding these common voices:
                  const iosRecommendedVoices = ['Samantha', 'Karen', 'Tessa', 'Moira'];
                  for (const recommendedVoice of iosRecommendedVoices) {
                    const similarVoice = voices.find(v => 
                      v.name === recommendedVoice || 
                      v.name.includes(recommendedVoice)
                    );
                    if (similarVoice) {
                      console.log(`Found alternative iOS voice: ${similarVoice.name}`);
                      setSelectedVoiceName(similarVoice.name);
                      // Also save this as the new platform preference
                      localStorage.setItem(`selectedVoice_${platformType}`, similarVoice.name);
                      return;
                    }
                  }
                  
                  // If no recommended voice found, look for South African voice as a fallback
                  const southAfricanVoice = voices.find(v => 
                    (v.lang && v.lang.includes('ZA')) || v.name.toLowerCase().includes('africa')
                  );
                  if (southAfricanVoice) {
                    console.log(`Found South African fallback voice: ${southAfricanVoice.name}`);
                    setSelectedVoiceName(southAfricanVoice.name);
                    localStorage.setItem(`selectedVoice_${platformType}`, southAfricanVoice.name);
                    return;
                  }
                } else if (platformType === 'android') {
                  // For Android, look for English or British voices first
                  const androidHighPriorityVoices = voices.filter(v => 
                    v.name.includes('Female') || 
                    (v.lang && v.lang.includes('GB')) ||
                    (v.lang && v.lang.includes('ZA'))
                  );
                  
                  if (androidHighPriorityVoices.length > 0) {
                    const bestAndroidVoice = androidHighPriorityVoices[0];
                    console.log(`Found alternative Android voice: ${bestAndroidVoice.name}`);
                    setSelectedVoiceName(bestAndroidVoice.name);
                    localStorage.setItem(`selectedVoice_${platformType}`, bestAndroidVoice.name);
                    return;
                  }
                }
              }
            } else {
              console.log(`No platform-specific voice saved for ${platformType}`);
              
              // For mobile devices with no saved preference, auto-select a good option
              if (platformType === 'ios' || platformType === 'android') {
                // Try to automatically select a good voice for this platform
                let autoSelectedVoice = null;
                
                // For mobile devices, Karen is the default voice as requested by the user
                autoSelectedVoice = voices.find(v => v.name === 'Karen');
                
                // If Karen isn't available (especially on Android), try alternative voices
                if (!autoSelectedVoice) {
                  // For iOS
                  if (platformType === 'ios') {
                    autoSelectedVoice = voices.find(v => 
                      v.name === 'Samantha' || 
                      v.name === 'Tessa' || 
                      v.name === 'Moira'
                    );
                  }
                  // For Android
                  else if (platformType === 'android') {
                    autoSelectedVoice = voices.find(v => 
                      v.name.includes('Female') || 
                      (v.lang && v.lang.includes('ZA'))
                    );
                  }
                }
                
                if (autoSelectedVoice) {
                  console.log(`Auto-selecting voice for ${platformType}: ${autoSelectedVoice.name}`);
                  setSelectedVoiceName(autoSelectedVoice.name);
                  // Save this auto-selection for future use on this platform
                  localStorage.setItem(`selectedVoice_${platformType}`, autoSelectedVoice.name);
                  return;
                }
              }
            }
          }
          
          // If we have a previously selected voice, use that one
          let femaleVoice = null;
          
          // First check if we have a stored voice in state
          if (selectedVoiceName) {
            femaleVoice = voices.find(v => v.name === selectedVoiceName);
            if (femaleVoice) {
              console.log("Using previously selected voice:", femaleVoice.name);
              utterance.voice = femaleVoice;
            }
          }
          
          // If not, check localStorage
          if (!femaleVoice && typeof localStorage !== 'undefined') {
            const savedVoice = localStorage.getItem('selectedVoice');
            if (savedVoice) {
              femaleVoice = voices.find(v => v.name === savedVoice);
              if (femaleVoice) {
                // Update state to match localStorage
                setSelectedVoiceName(savedVoice);
                console.log("Using voice from localStorage:", femaleVoice.name);
                utterance.voice = femaleVoice;
              }
            }
          }
          
          // Otherwise, try to find a voice from our priority list
          if (!femaleVoice) {
            // Special handling for different platforms
            if (platformType === 'ios' || platformType === 'android') {
              // For mobile, try to use Karen first as the default voice
              const karenVoice = voices.find(v => v.name === 'Karen');
              if (karenVoice) {
                femaleVoice = karenVoice;
                console.log("Using Karen as default mobile voice");
                setSelectedVoiceName(karenVoice.name);
                localStorage.setItem(`selectedVoice_${platformType}`, karenVoice.name);
              }
            } else {
              // For desktop, strictly match Ezinne (to avoid male Nigerian voices)
              const ezinneVoice = voices.find(v => 
                v.name === 'Ezinne' || 
                v.name === 'Microsoft Ezinne Online' ||
                v.name === 'Microsoft Ezinne'
              );
              if (ezinneVoice) {
                femaleVoice = ezinneVoice;
                console.log("Using Ezinne as default desktop voice");
                setSelectedVoiceName(ezinneVoice.name);
                localStorage.setItem(`selectedVoice_${platformType}`, ezinneVoice.name);
              }
            }
            
            // If we couldn't find the platform-specific default voice, try the general priority list
            if (!femaleVoice) {
              for (const voiceName of softFemaleVoicePriorities) {
                const foundVoice = voices.find(v => 
                  v.name.includes(voiceName) || v.name === voiceName
                );
                
                if (foundVoice) {
                  femaleVoice = foundVoice;
                  console.log("Found priority voice:", femaleVoice.name);
                  break;
                }
              }
            }
          }
          
          // If no priority voice found, try to find any female voice by common indicators
          if (!femaleVoice) {
            femaleVoice = voices.find(voice => 
              voice.name.includes('female') || 
              voice.name.includes('woman') || 
              voice.name.includes('girl') ||
              voice.name.toLowerCase().includes('f ') ||
              voice.name.includes('Samantha') ||
              voice.name.includes('Victoria') ||
              voice.name.includes('Karen') ||
              voice.name.includes('Tessa') ||
              voice.name.includes('Google') && voice.name.includes('Female')
            );
          }
          
          // If still no female voice found, try to find a voice with female-like name
          if (!femaleVoice) {
            const femaleNames = [
              'alice', 'alicia', 'anna', 'ava', 'emily', 'emma', 'hannah', 
              'julie', 'laura', 'linda', 'lisa', 'mary', 'monica', 'moira',
              'nora', 'olivia', 'samantha', 'sarah', 'sophia', 'tessa', 'victoria',
              'zira', 'allison', 'amelie', 'audrey', 'celine', 'ellen', 'fiona',
              'joana', 'kate', 'kyoko', 'lekha', 'melina', 'nicky', 'princess',
              'rosa', 'shelley', 'sinji', 'susan', 'veena', 'yelda', 'yuna'
            ];
            
            femaleVoice = voices.find(voice => 
              femaleNames.some(name => voice.name.toLowerCase().includes(name))
            );
          }
          
          // Apply the voice if found
          if (femaleVoice) {
            utterance.voice = femaleVoice;
            console.log("Using voice:", femaleVoice.name);
          } else {
            // If all else fails, just pick a voice that sounds more feminine
            // (higher pitch tends to sound more feminine)
            const defaultVoice = voices.find(v => v.lang && v.lang.startsWith('en'));
            if (defaultVoice) {
              utterance.voice = defaultVoice;
              console.log("Using default English voice:", defaultVoice.name);
            } else {
              console.log("No suitable voice found, using browser default");
            }
          }
          
          // Set properties for a soft-spoken female voice
          utterance.rate = 0.9; // Slightly slower rate for a softer, more deliberate speaking style
          utterance.pitch = 1.15; // Slightly higher pitch but not too high (more natural feminine)
          utterance.volume = 0.95; // Slightly reduced volume for a softer tone
          
          // Set a soft voice by modifying the utterance
          if (femaleVoice) {
            // Fine-tune based on the voice we found
            if (femaleVoice.name.includes('Samantha') || femaleVoice.name.includes('Siri')) {
              // Samantha and Siri-like voices already sound good but can be toned down slightly
              utterance.rate = 0.85;
            } else if (femaleVoice.name.includes('Google')) {
              // Google voices may need more adjustment
              utterance.rate = 0.82;
              utterance.pitch = 1.05;
            }
          }
          
          // Speak the text
          synth.current?.speak(utterance);
        }
      };
      
      // Start the speech process with a small delay
      setTimeout(speakText, 800);
    }
    
    // 100 WPM = 100 * 5 = 500 characters per minute = 8.33 characters per second
    // So we need 1000ms / 8.33 = 120ms per character for 100 WPM (approximate)
    const typingSpeed = 120; // milliseconds per character (approx 100 WPM)
    
    let currentIndex = 0;
    const typingInterval = setInterval(() => {
      if (currentIndex <= quoteRef.current.length) {
        setTypedQuote(quoteRef.current.slice(0, currentIndex));
        currentIndex++;
      } else {
        clearInterval(typingInterval);
        setIsTyping(false);
      }
    }, typingSpeed);
    
    return () => {
      clearInterval(typingInterval);
      if (synth.current) {
        synth.current.cancel();
      }
    };
  }, []);

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
    },
  });
  
  // If user is already logged in, redirect to dashboard
  // We check this after initializing all hooks to avoid React hooks rules violations
  if (user) {
    return <Redirect to="/" />;
  }

  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };

  const onRegisterSubmit = (data: RegisterFormValues) => {
    registerMutation.mutate(data);
  };

  return (
    <div className="flex min-h-screen">
      {/* Voice guide modal */}
      <VoiceGuideModal
        open={showVoiceGuide}
        onOpenChange={setShowVoiceGuide}
        platformType={platformType}
      />
      
      {/* Left column with authentication forms */}
      <div className="w-full md:w-1/2 p-6 md:p-10 flex items-center justify-center text-white">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <h1 className="text-3xl font-bold mb-1">
              {greetingText}
            </h1>
            <h2 className="text-2xl font-semibold mb-6 text-blue-200">Welcome to Elexkay™</h2>
            <p className="text-xl italic min-h-[100px]">
              {typedQuote}{isTyping && <span className="ml-1 inline-block w-2 h-4 bg-white animate-pulse"></span>}
            </p>
            
            {/* Voice controls */}
            <div className="flex items-center justify-center space-x-2">
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-xs text-blue-300 hover:text-blue-100"
                onClick={() => setShowVoiceSelector(!showVoiceSelector)}
              >
                <Volume2 className="h-3 w-3 mr-1" />
                Change Voice
              </Button>
              
              {isMobileDevice && !hasEzinneVoice && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-xs text-blue-300 hover:text-blue-100"
                  onClick={() => setShowVoiceGuide(true)}
                >
                  <Download className="h-3 w-3 mr-1" />
                  Get Nigerian Voice
                </Button>
              )}
            </div>
            
            {/* Voice selector dropdown */}
            {showVoiceSelector && (
              <div className="mt-2 p-3 bg-slate-900/70 backdrop-blur-sm rounded-md border border-blue-900/50 max-h-[300px] overflow-y-auto">
                <h4 className="text-sm font-medium mb-2 text-blue-200">
                  Select a voice:
                  {platformType === 'ios' || platformType === 'android' ? (
                    <span className="block text-xs text-blue-300 mt-1">
                      Note: Mobile devices have limited voice options. Microsoft Ezinne is only available on desktop.
                    </span>
                  ) : null}
                </h4>
                
                {/* Add a color legend for voice types */}
                <div className="flex flex-wrap gap-2 text-[10px] mb-2">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-500 mr-1 rounded-full"></div>
                    <span className="text-green-300">Nigerian/African</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-blue-500 mr-1 rounded-full"></div>
                    <span className="text-blue-300">British</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-amber-500 mr-1 rounded-full"></div>
                    <span className="text-amber-300">Mobile Friendly</span>
                  </div>
                </div>
                
                {/* Platform message and section title */}
                <div className="mb-2 mt-3 pb-1 border-b border-blue-900/30">
                  <span className="text-xs text-amber-300 font-medium">
                    {platformType === 'ios' 
                      ? "iOS Voices" 
                      : platformType === 'android' 
                        ? "Android Voices" 
                        : "Desktop Voices"}
                  </span>
                </div>
                
                {/* For mobile devices, create a section of recommended voices first */}
                {(platformType === 'ios' || platformType === 'android') && (
                  <div className="mb-3">
                    <div className="text-xs font-medium mb-1 text-amber-300">
                      Recommended Mobile Voices
                    </div>
                    <div className="space-y-1 mb-2">
                      {availableVoices
                        .filter(voice => {
                          // iOS-specific recommended voices
                          if (platformType === 'ios') {
                            return ['Samantha', 'Karen', 'Tessa', 'Moira'].some(name => 
                              voice.name === name || voice.name.includes(name)
                            );
                          }
                          // Android-specific recommended voices
                          if (platformType === 'android') {
                            return (
                              voice.name.includes('Female') || 
                              voice.name.includes('UK') || 
                              voice.name.includes('British') ||
                              voice.name.includes('Tessa') || 
                              (voice.lang && voice.lang.includes('ZA'))
                            );
                          }
                          return false;
                        })
                        .map(voice => (
                          <div
                            key={`recommended-${voice.name}-${voice.voiceURI || ""}`}
                            className={`text-xs p-1.5 rounded cursor-pointer hover:bg-blue-900/30 ${
                              selectedVoiceName === voice.name ? 'bg-blue-800/50 font-medium' : ''
                            } ${
                              voice.name === 'Karen' 
                                ? 'border-l-2 border-amber-600 bg-amber-900/30 pl-2' 
                                : 'border-l-2 border-amber-500 pl-2'
                            }`}
                            onClick={() => {
                              setSelectedVoiceName(voice.name);
                              
                              // Save the selected voice to localStorage for persistence - both general and platform-specific
                              if (typeof localStorage !== 'undefined') {
                                // Save general preference
                                localStorage.setItem('selectedVoice', voice.name);
                                
                                // Save platform-specific preference as well
                                localStorage.setItem(`selectedVoice_${platformType}`, voice.name);
                                console.log(`Saved voice "${voice.name}" for platform "${platformType}"`);
                              }
                              
                              // Speak a test phrase with this voice
                              if (synth.current) {
                                synth.current.cancel(); // Cancel any ongoing speech
                                const testUtterance = new SpeechSynthesisUtterance("Hello, I'm your financial assistant.");
                                testUtterance.voice = voice;
                                
                                // Adjust properties based on detected voice type
                                let rate = 0.85;
                                let pitch = 1.15;
                                
                                // iOS-specific voice tuning
                                if (platformType === 'ios') {
                                  if (voice.name === 'Samantha') {
                                    rate = 0.88;
                                    pitch = 1.05;
                                  } else if (voice.name === 'Karen') {
                                    rate = 0.82;
                                    pitch = 1.08;
                                  } else if (voice.name === 'Tessa') {
                                    // Tessa could be South African on some devices
                                    rate = 0.84;
                                    pitch = 1.10;
                                  }
                                } 
                                // Android-specific voice tuning
                                else if (platformType === 'android') {
                                  rate = 0.80; // Android voices tend to speak faster
                                  pitch = 1.10;
                                }
                                
                                testUtterance.rate = rate;
                                testUtterance.pitch = pitch;
                                testUtterance.volume = 0.95;
                                synth.current.speak(testUtterance);
                              }
                            }}
                          >
                            <div className="flex items-center justify-between">
                              <span>{voice.name}</span>
                              <span className="text-[10px] bg-amber-900/40 px-1 rounded text-amber-300">
                                {voice.name === 'Karen' ? 'Default' : 'Recommended'}
                              </span>
                            </div>
                            {/* Add locale/region info for voice identification */}
                            {voice.lang && (
                              <span className="block text-[10px] text-blue-300 mt-0.5">
                                {voice.lang}
                                {voice.name.toLowerCase().includes('tessa') && ['en-ZA'].includes(voice.lang) ? ' • South African' : ''}
                              </span>
                            )}
                            {/* Special note for Karen voice */}
                            {voice.name === 'Karen' && (
                              <span className="block text-[10px] text-amber-300 mt-0.5 italic">
                                Default mobile voice for best compatibility
                              </span>
                            )}
                          </div>
                        ))}
                    </div>
                  </div>
                )}
                
                {/* Section title for all voices */}
                <div className="mb-1 text-xs font-medium text-blue-300">
                  All Available Voices
                </div>
                <div className="space-y-1">
                  {availableVoices
                    .filter(voice => voice.lang?.startsWith('en') || voice.name.includes('English'))
                    .sort((a, b) => {
                      // Prioritize sorting African (especially Nigerian) and British voices first
                      const aNigerian = a.name.toLowerCase().includes('nigeria') || a.name.toLowerCase().includes('ezinne');
                      const bNigerian = b.name.toLowerCase().includes('nigeria') || b.name.toLowerCase().includes('ezinne');
                      
                      // Check for other African voices (South African is most common)
                      const aAfrican = a.name.toLowerCase().includes('africa') || 
                                     (a.lang && a.lang.includes('ZA')) || 
                                     a.name.toLowerCase().includes('tessa') ||
                                     a.name.toLowerCase().includes('swahili') ||
                                     a.name.toLowerCase().includes('zulu') ||
                                     a.name.toLowerCase().includes('ghana') ||
                                     a.name.toLowerCase().includes('kenya');
                                     
                      const bAfrican = b.name.toLowerCase().includes('africa') || 
                                     (b.lang && b.lang.includes('ZA')) || 
                                     b.name.toLowerCase().includes('tessa') ||
                                     b.name.toLowerCase().includes('swahili') ||
                                     b.name.toLowerCase().includes('zulu') ||
                                     b.name.toLowerCase().includes('ghana') ||
                                     b.name.toLowerCase().includes('kenya');
                                     
                      const aBritish = a.name.toLowerCase().includes('british') || (a.lang && a.lang.includes('GB'));
                      const bBritish = b.name.toLowerCase().includes('british') || (b.lang && b.lang.includes('GB'));
                      
                      // For mobile devices, prioritize common mobile voices
                      if (platformType === 'ios' || platformType === 'android') {
                        const aMobileFriendly = ['Samantha', 'Karen', 'Tessa', 'Moira'].some(
                          name => a.name === name || a.name.includes(name)
                        );
                        const bMobileFriendly = ['Samantha', 'Karen', 'Tessa', 'Moira'].some(
                          name => b.name === name || b.name.includes(name)
                        );
                        
                        if (aMobileFriendly && !bMobileFriendly) return -1;
                        if (!aMobileFriendly && bMobileFriendly) return 1;
                      }
                      
                      // Order: Nigerian > Other African > British > Others
                      if (aNigerian && !bNigerian) return -1;
                      if (!aNigerian && bNigerian) return 1;
                      if (aAfrican && !bAfrican && !bNigerian) return -1;
                      if (!aAfrican && bAfrican && !aNigerian) return 1;
                      if (aBritish && !bBritish && !bNigerian && !bAfrican) return -1;
                      if (!aBritish && bBritish && !aNigerian && !aAfrican) return 1;
                      
                      return a.name.localeCompare(b.name);
                    })
                    .map(voice => {
                      // Determine voice type and styling
                      const isNigerian = voice.name.toLowerCase().includes('nigeria') || voice.name.toLowerCase().includes('ezinne');
                      const isAfrican = voice.name.toLowerCase().includes('africa') || 
                                     (voice.lang && voice.lang.includes('ZA')) || 
                                     voice.name.toLowerCase().includes('tessa') ||
                                     voice.name.toLowerCase().includes('swahili') ||
                                     voice.name.toLowerCase().includes('zulu') ||
                                     voice.name.toLowerCase().includes('ghana') ||
                                     voice.name.toLowerCase().includes('kenya');
                      const isBritish = voice.name.toLowerCase().includes('british') || (voice.lang && voice.lang.includes('GB'));
                      const isMobileFriendly = ['Samantha', 'Karen', 'Tessa', 'Moira'].some(
                        name => voice.name === name || voice.name.includes(name)
                      );
                      
                      let borderClass = '';
                      if (isNigerian) {
                        borderClass = 'border-l-2 border-green-500 pl-2';
                      } else if (isAfrican) {
                        borderClass = 'border-l-2 border-green-500 pl-2';
                      } else if (isBritish) {
                        borderClass = 'border-l-2 border-blue-500 pl-2';
                      } else if (isMobileFriendly && (platformType === 'ios' || platformType === 'android')) {
                        borderClass = 'border-l-2 border-amber-500 pl-2';
                      }
                      
                      return (
                        <div
                          key={`${voice.name}-${voice.voiceURI || ""}`}
                          className={`text-xs p-1.5 rounded cursor-pointer hover:bg-blue-900/30 ${
                            selectedVoiceName === voice.name ? 'bg-blue-800/50 font-medium' : ''
                          } ${borderClass}`}
                          onClick={() => {
                            setSelectedVoiceName(voice.name);
                            
                            // Save the selected voice to localStorage for persistence - both general and platform-specific
                            if (typeof localStorage !== 'undefined') {
                              // Save general preference
                              localStorage.setItem('selectedVoice', voice.name);
                              
                              // Save platform-specific preference as well
                              localStorage.setItem(`selectedVoice_${platformType}`, voice.name);
                              console.log(`Saved voice "${voice.name}" for platform "${platformType}"`);
                            }
                            
                            // Speak a test phrase with this voice
                            if (synth.current) {
                              synth.current.cancel(); // Cancel any ongoing speech
                              const testUtterance = new SpeechSynthesisUtterance("Hello, I'm your financial assistant.");
                              testUtterance.voice = voice;
                              
                              // Adjust properties based on detected voice type
                              let rate = 0.85;
                              let pitch = 1.15;
                              
                              // iOS-specific voice tuning
                              if (platformType === 'ios') {
                                if (voice.name === 'Samantha') {
                                  // Samantha on iOS sounds good with these settings
                                  rate = 0.88;
                                  pitch = 1.05;
                                } else if (voice.name === 'Karen') {
                                  rate = 0.82;
                                  pitch = 1.08;
                                } else if (voice.name === 'Tessa') {
                                  // Tessa could be South African on some devices
                                  rate = 0.84;
                                  pitch = 1.10;
                                }
                              } 
                              // Android-specific voice tuning
                              else if (platformType === 'android') {
                                rate = 0.80; // Android voices tend to speak faster
                                pitch = 1.10;
                              }
                              
                              testUtterance.rate = rate;
                              testUtterance.pitch = pitch;
                              testUtterance.volume = 0.95;
                              synth.current.speak(testUtterance);
                            }
                          }}
                        >
                          <div className="flex items-center justify-between">
                            <span>{voice.name}</span>
                            {isMobileFriendly && (platformType === 'ios' || platformType === 'android') && (
                              <span className="text-[10px] bg-amber-900/40 px-1 rounded text-amber-300">Mobile Friendly</span>
                            )}
                          </div>
                          {/* Add enhanced locale/region info for voice identification */}
                          {voice.lang && (
                            <span className="block text-[10px] text-blue-300 mt-0.5">
                              {voice.lang}
                              {isNigerian ? ' • Nigerian' : 
                               isAfrican && voice.lang.includes('ZA') ? ' • South African' :
                               isAfrican ? ' • African' : 
                               isBritish ? ' • British' : ''}
                            </span>
                          )}
                        </div>
                      );
                    })}
                </div>
                
                <div className="flex justify-between mt-3 pt-2 border-t border-blue-900/30">
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-xs"
                    onClick={() => {
                      setShowVoiceSelector(false);
                      // Replay the greeting and quote with the selected voice
                      if (synth.current && greetingRef.current && quoteRef.current) {
                        synth.current.cancel(); // Cancel any ongoing speech
                        const voice = availableVoices.find(v => v.name === selectedVoiceName);
                        const replayUtterance = new SpeechSynthesisUtterance(greetingRef.current + quoteRef.current);
                        
                        if (voice) {
                          replayUtterance.voice = voice;
                          
                          // Adjust properties based on platform and voice
                          let rate = 0.85;
                          let pitch = 1.15;
                          
                          // Platform-specific voice tuning
                          if (platformType === 'ios') {
                            if (voice.name === 'Samantha') {
                              rate = 0.88;
                              pitch = 1.05;
                            } else if (voice.name === 'Karen') {
                              rate = 0.82;
                              pitch = 1.08;
                            }
                          } else if (platformType === 'android') {
                            rate = 0.80; // Android voices tend to speak faster
                            pitch = 1.10;
                          } else {
                            // Desktop-specific adjustments
                            if (voice.name.includes('Ezinne')) {
                              rate = 0.82;
                              pitch = 1.10;
                            } else if (voice.name.includes('Microsoft')) {
                              rate = 0.85;
                              pitch = 1.12;
                            }
                          }
                          
                          replayUtterance.rate = rate;
                          replayUtterance.pitch = pitch;
                        } else {
                          // Default values if no voice found
                          replayUtterance.rate = 0.85;
                          replayUtterance.pitch = 1.15;
                        }
                        
                        replayUtterance.volume = 0.95;
                        synth.current.speak(replayUtterance);
                      }
                    }}
                  >
                    Replay Greeting
                  </Button>
                  <Button
                    size="sm"
                    className="text-xs"
                    onClick={() => setShowVoiceSelector(false)}
                  >
                    Close
                  </Button>
                </div>
              </div>
            )}
          </div>

          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "login" | "register")}>
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            
            {/* Try Me Demo Button */}
            <div className="flex justify-center mb-6">
              <Button
                type="button"
                variant="outline"
                size="lg"
                className="w-full transition-all hover:bg-blue-600 hover:text-white border-blue-500 text-blue-500 font-medium flex items-center justify-center gap-2"
                onClick={() => demoAccessMutation.mutate()}
                disabled={demoAccessMutation.isPending}
              >
                {demoAccessMutation.isPending ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <span className="text-lg">👋</span>
                )}
                {demoAccessMutation.isPending ? "Accessing Demo..." : "Try Me - No Login Required"}
              </Button>
            </div>
            
            <TabsContent value="login">
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Enter your username" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} placeholder="Enter your password" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : null}
                    Login
                  </Button>
                </form>
              </Form>
            </TabsContent>
            
            <TabsContent value="register">
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                  <FormField
                    control={registerForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Choose a username" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} placeholder="Choose a password" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirm Password</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} placeholder="Confirm your password" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : null}
                    Create Account
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {/* Right column with hero section */}
      <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-[#0A0F2C] to-[#161B40] text-white items-center justify-center p-10">
        <div className="max-w-md">
          <h2 className="text-3xl font-bold mb-4">Take Control of Your Finances</h2>
          <p className="mb-6">
            Track your bills, schedule payments, and manage your finances all in one place.
            Take control of your financial life with our comprehensive tools.
          </p>
          <ul className="space-y-2">
            <li className="flex items-center">
              <span className="text-red-500 mr-2">✓</span> Bill tracking with automated status updates
            </li>
            <li className="flex items-center">
              <span className="text-red-500 mr-2">✓</span> Payment scheduling with multiple frequency options
            </li>
            <li className="flex items-center">
              <span className="text-red-500 mr-2">✓</span> Credit score monitoring from three major bureaus
            </li>
            <li className="flex items-center">
              <span className="text-red-500 mr-2">✓</span> Credential storage for easy account access
            </li>
            <li className="flex items-center">
              <span className="text-red-500 mr-2">✓</span> Customizable payment strategies
            </li>
          </ul>
        </div>
      </div>
      {/* Voice Guide Modal - shows when Ezinne voice isn't available on mobile */}
      <VoiceGuideModal 
        open={showVoiceGuide} 
        onOpenChange={setShowVoiceGuide} 
        platformType={platformType}
      />
    </div>
  );
}