import { ArrowLeft, Mail } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function HelpPage() {
  return (
    <div className="container max-w-5xl mx-auto py-8 px-4">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Link href="/">
            <Button variant="outline" size="icon" className="border-white/20 bg-black/30 hover:bg-black/50">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Help & Support</h1>
        </div>
        <a 
          href="mailto:help@elexkay.com"
          className="flex items-center gap-2 px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white"
        >
          <Mail className="h-4 w-4" />
          <span>Contact Support</span>
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <div className="md:col-span-12 card-container">
          <h2 className="text-xl font-semibold mb-4">Features & Help Guide</h2>
          
          <Accordion type="single" collapsible className="w-full">
            {/* Dashboard */}
            <AccordionItem value="dashboard">
              <AccordionTrigger className="text-lg">Dashboard</AccordionTrigger>
              <AccordionContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Monthly Overview</h3>
                  <p>
                    The main dashboard provides a comprehensive overview of your monthly bills 
                    and financial obligations. It displays totals, upcoming drafts, and bill 
                    status at a glance.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Draft This Pay Period</h3>
                  <p>
                    This amount represents the total funds needed for bills due in your current 
                    pay period. This includes bill amounts, additional payments, and a billing 
                    cushion (if set).
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Monthly Due</h3>
                  <p>
                    Shows the total of all bills for the current month, including the billing 
                    cushion percentage. This helps you understand your total monthly obligations.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Bill Status Toggle</h3>
                  <p>
                    Click on a bill's status to cycle through different states:
                  </p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li><span className="font-medium">Upcoming</span>: Bills that are not yet due</li>
                    <li><span className="font-medium">Active</span>: Bills that are currently being processed</li>
                    <li><span className="font-medium">Paid</span>: Bills that have been paid</li>
                    <li><span className="font-medium">Skip</span>: Bills to exclude from the current period</li>
                    <li><span className="font-medium">Due</span>: Bills that are due but not yet paid</li>
                  </ul>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            {/* Payment Strategy and Settings */}
            <AccordionItem value="payment-strategy">
              <AccordionTrigger className="text-lg">Payment Strategy & Settings</AccordionTrigger>
              <AccordionContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Payment Strategy</h3>
                  <p>
                    Choose between two different payment strategies to manage your bills:
                  </p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>
                      <span className="font-medium">Proactive</span>: Distributes ALL monthly bills evenly 
                      across pay periods, helping you save ahead for bills due later in the month.
                    </li>
                    <li>
                      <span className="font-medium">Reactive</span>: Only includes bills due in the current 
                      pay period. This helps if you want to only focus on immediate obligations.
                    </li>
                  </ul>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Pay Frequency</h3>
                  <p>
                    Configure how often you receive income:
                  </p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li><span className="font-medium">Bi-Weekly</span>: Every two weeks</li>
                    <li><span className="font-medium">Semi-Monthly</span>: Twice a month, usually on fixed dates</li>
                    <li><span className="font-medium">Monthly</span>: Once per month</li>
                    <li><span className="font-medium">Weekly</span>: Every week</li>
                  </ul>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Billing Cushion</h3>
                  <p>
                    The billing cushion adds a percentage to your total bill amounts. This 
                    provides extra funds for unexpected price increases or variable bills.
                    Default is 2%, but you can adjust this in Settings.
                  </p>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            {/* Bill Management */}
            <AccordionItem value="bill-management">
              <AccordionTrigger className="text-lg">Bill Management</AccordionTrigger>
              <AccordionContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Adding Bills</h3>
                  <p>
                    Create new bills by clicking the "Add Bill" button. You can specify:
                  </p>
                  <ul className="list-disc pl-6 space-y-1">
                    <li>Name and amount of the bill</li>
                    <li>Due day (date within the month)</li>
                    <li>Payment method</li>
                    <li>Website URL for easy access to payment portal</li>
                    <li>Additional payment amount (added to base amount)</li>
                    <li>Account credentials for reference</li>
                  </ul>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Annual Bills</h3>
                  <p>
                    Toggle a bill as "Annual" to specify it only occurs once per year.
                    Set the month and year when it's due. Annual bills only appear in 
                    calculations during their specified month.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Auto Draft</h3>
                  <p>
                    Toggle this option for bills that are automatically deducted from your account.
                    This helps you track which bills need manual payment and which are automatic.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Import Bills</h3>
                  <p>
                    Bulk import bills from various file formats, including CSV, JSON, and others.
                    The system will extract information from the files and create bills automatically.
                  </p>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            {/* Stock and News Tracking */}
            <AccordionItem value="stock-news">
              <AccordionTrigger className="text-lg">Stock & News Tracking</AccordionTrigger>
              <AccordionContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Stock Ticker</h3>
                  <p>
                    The stock ticker at the bottom of the page shows real-time prices and changes
                    for the stocks you're watching. Data is refreshed automatically every 5 minutes
                    from Yahoo Finance.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Financial News</h3>
                  <p>
                    The news ticker displays the latest financial news headlines. These updates
                    are refreshed periodically to keep you informed about market events that may
                    affect your finances.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-md font-medium">Stock Settings</h3>
                  <p>
                    In the settings page, you can add or remove stocks from your watchlist.
                    Search for stocks by symbol or company name, and select which ones you
                    want to track on the ticker.
                  </p>
                </div>
                

              </AccordionContent>
            </AccordionItem>
            
            {/* Mobile Compatibility */}
            <AccordionItem value="mobile">
              <AccordionTrigger className="text-lg">Mobile Compatibility</AccordionTrigger>
              <AccordionContent className="space-y-2">
                <p>
                  The application is designed to work on mobile devices, with a responsive
                  interface that adapts to different screen sizes. On smaller screens, tables
                  are replaced with card views for better readability.
                </p>
                <p>
                  If you experience any issues with the mobile view, please contact support
                  at help@elexkay.com.
                </p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </div>
    </div>
  );
}