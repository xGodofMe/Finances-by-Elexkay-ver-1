import { useEffect, useState, useRef } from "react";
import { 
  getBills, 
  fetchBills,
  getSettings, 
  updateSettings, 
  addBill, 
  updateBill, 
  deleteBill,
  subscribe,
  initializeStore,
  Bill,
  Settings
} from "@/lib/store";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { StatusBadge } from "@/components/ui/status-badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Edit, Trash, Plus, Upload, FileUp, FileText, MoreVertical, CheckSquare, UserPlus, FileInput } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { formatCurrency, getOrdinal } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function BillManagement() {
  const [bills, setBills] = useState<Bill[]>([]);
  const [settings, setSettings] = useState<Settings>(getSettings());
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState("all");
  const [editingBill, setEditingBill] = useState<Bill | null>(null);
  const [isAddingBill, setIsAddingBill] = useState(false);
  const [billToDelete, setBillToDelete] = useState<string | number | null>(null);
  const [selectedBills, setSelectedBills] = useState<(string | number)[]>([]);
  const [isMultiSelectMode, setIsMultiSelectMode] = useState(false);
  const [sortColumn, setSortColumn] = useState<string>("name");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [isBulkAddDialogOpen, setIsBulkAddDialogOpen] = useState(false);
  const [bulkBills, setBulkBills] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isBulkAdding, setIsBulkAdding] = useState(false);
  const [bulkAddProgress, setBulkAddProgress] = useState(0);
  const [importResults, setImportResults] = useState<{
    success?: boolean;
    imported?: number;
    failed?: number;
    errors?: string[];
    bills?: any[];
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const updateState = async () => {
      setLoading(true);
      
      try {
        // Always fetch bills directly from server to ensure latest data
        const freshBills = await fetchBills();
        setBills(freshBills);
        setSettings(getSettings());
        
        // Initialize the store if needed
        if (freshBills.length === 0) {
          await initializeStore();
          // Get the updated data after initialization
          const updatedBills = await fetchBills();
          setBills(updatedBills);
          setSettings(getSettings());
        }
      } catch (error) {
        console.error("Error updating bill state:", error);
      } finally {
        setLoading(false);
      }
    };

    // Initial update
    updateState();

    // Subscribe to store updates
    const unsubscribe = subscribe(async () => {
      // Use the local getBills for fast UI updates
      setBills(getBills());
      setSettings(getSettings());
      
      // Then fetch the latest bills from the server for accuracy
      try {
        const freshBills = await fetchBills();
        setBills(freshBills);
      } catch (error) {
        console.error("Error fetching bills in subscription:", error);
      }
      // Don't set loading here as it would flash the loading state during updates
    });
    
    return unsubscribe;
  }, []);

  const handleSettingsChange = async (field: keyof Settings, value: string) => {
    const updatedSettings = { ...settings, [field]: value };
    setSettings(updatedSettings);
    await updateSettings(updatedSettings);
  };

  const handleBillChange = (field: keyof Bill, value: any) => {
    if (editingBill) {
      setEditingBill({ ...editingBill, [field]: value });
    }
  };

  const handleSaveBill = async () => {
    if (editingBill) {
      try {
        if (editingBill.id) {
          await updateBill(editingBill.id, editingBill);
        } else {
          await addBill(editingBill);
        }
        
        // Refresh bills list to show the updated data
        await fetchBills();
        
        // Close the dialog
        setEditingBill(null);
        
        // Reset isAddingBill after successfully saving
        setIsAddingBill(false);
        
        // Show success toast
        toast({
          title: editingBill.id ? "Bill updated" : "Bill added",
          description: `Successfully ${editingBill.id ? "updated" : "added"} bill: ${editingBill.name}`,
          variant: "default",
        });
      } catch (error) {
        // Show error toast
        toast({
          title: "Error",
          description: `Failed to ${editingBill.id ? "update" : "add"} bill`,
          variant: "destructive",
        });
      }
    }
  };

  const handleAddBill = () => {
    setEditingBill({
      name: "",
      amount: "",
      dueDay: "",
      method: "",
      hidden: false,
      autoDraft: false,
      isAnnual: false,
      annualMonth: new Date().getMonth() + 1 + "", // Current month as string (1-12)
      annualYear: new Date().getFullYear() + ""    // Current year as string
    });
    setIsAddingBill(true);
  };

  const handleEditBill = (bill: Bill) => {
    setEditingBill({ ...bill });
    setIsAddingBill(false);
  };

  const { toast } = useToast();
  
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteProgress, setDeleteProgress] = useState(0);

  const handleDeleteConfirm = async () => {
    if (billToDelete) {
      setIsDeleting(true);
      setLoading(true); // Set loading state for the UI
      try {
        await deleteBill(billToDelete);
        toast({
          title: "Bill deleted",
          description: "The bill has been successfully deleted.",
          variant: "default"
        });
        setBillToDelete(null);
      } catch (error) {
        console.error("Error deleting bill:", error);
        toast({
          title: "Error",
          description: "Failed to delete bill. Please try again.",
          variant: "destructive"
        });
      } finally {
        setIsDeleting(false);
        setLoading(false); // Reset loading state
      }
    } else if (selectedBills.length > 0) {
      setIsDeleting(true);
      setLoading(true); // Set loading state for the UI
      try {
        // Calculate progress increment per bill
        const progressIncrement = 100 / selectedBills.length;
        
        // Delete all selected bills
        for (let i = 0; i < selectedBills.length; i++) {
          const billId = selectedBills[i];
          await deleteBill(billId);
          
          // Update progress after each deletion
          setDeleteProgress((i + 1) * progressIncrement);
        }
        
        toast({
          title: "Bills deleted",
          description: `Successfully deleted ${selectedBills.length} bills.`,
          variant: "default"
        });
        
        // Clear selections and exit multi-select mode
        setSelectedBills([]);
        setIsMultiSelectMode(false);
      } catch (error) {
        console.error("Error deleting multiple bills:", error);
        toast({
          title: "Error",
          description: "Failed to delete some bills. Please try again.",
          variant: "destructive"
        });
      } finally {
        setIsDeleting(false);
        setDeleteProgress(0);
        setLoading(false); // Reset loading state
      }
    }
  };
  
  // Toggle multi-select mode
  const toggleMultiSelectMode = () => {
    setIsMultiSelectMode(!isMultiSelectMode);
    setSelectedBills([]);
  };
  
  // Toggle bill selection
  const toggleBillSelection = (billId: string | number) => {
    if (selectedBills.includes(billId)) {
      setSelectedBills(selectedBills.filter(id => id !== billId));
    } else {
      setSelectedBills([...selectedBills, billId]);
    }
  };
  
  // Select/deselect all bills
  const toggleSelectAll = () => {
    if (selectedBills.length === filteredBills.length) {
      setSelectedBills([]);
    } else {
      setSelectedBills(filteredBills.map(bill => bill.id!).filter(Boolean));
    }
  };
  
  const handleImportBills = () => {
    setIsImportDialogOpen(true);
    setImportResults(null);
    setUploadProgress(0);
  };
  
  const uploadFile = async (file: File) => {
    if (!file) return;
    
    // First set the uploading flag and initial progress
    // This needs to happen before any async operations
    setUploading(true);
    setLoading(true); // Also set the main loading state
    setUploadProgress(10); // Start progress
    
    // Small delay to ensure the UI updates before heavy processing starts
    await new Promise(resolve => setTimeout(resolve, 50));
    
    try {
      // Create form data
      const formData = new FormData();
      formData.append('file', file);
      
      // Simulate progress - in a real app you might use upload progress events
      // Use a slower increment and longer interval for more visible progress animation
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          const newProgress = prev + 3; // Smaller increments
          if (newProgress >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return newProgress;
        });
      }, 150); // Longer interval
      
      // Send the request - using fetch directly instead of apiRequest
      const response = await fetch('/api/bills/import', {
        method: 'POST',
        body: formData,
        // No Content-Type header - browser will set it with boundary for FormData
      });
      
      // Clear interval and set to 100%
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      // Parse the JSON response
      const result = await response.json();
      
      // Update with response data
      setImportResults(result);
      
      // Show toast based on result
      if (result.success) {
        // Fetch the latest bills directly from the server
        const freshBills = await fetchBills();
        setBills(freshBills);
        
        // Show the progress at 100% for a moment before closing
        // so the user can see the progress complete
        if (result.imported > 0) {
          // Delay closing the dialog so user can see the 100% complete animation
          setTimeout(() => {
            setIsImportDialogOpen(false);
          }, 1000); // Keep dialog open for 1 second after completion
        }
        
        toast({
          title: "Import Successful",
          description: `Successfully imported ${result.imported} bills.${result.failed ? ` ${result.failed} bills failed to import.` : ''}`,
          variant: "default"
        });
      } else {
        toast({
          title: "Import Failed",
          description: result.error || "Failed to import bills. Check the errors for details.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Error importing bills:", error);
      toast({
        title: "Import Error",
        description: "An error occurred while importing bills.",
        variant: "destructive"
      });
      setImportResults({
        success: false,
        errors: ["Network or server error occurred."]
      });
    } finally {
      setUploading(false);
      setLoading(false); // Reset the main loading state
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Handle file selection from input
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await uploadFile(file);
    }
  };
  
  // Handle drag and drop events
  const handleDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };
  
  const handleDrop = async (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      await uploadFile(file);
    }
  };

  // Filter bills based on the selected filter
  const filteredBills = bills.filter(bill => {
    switch (filter) {
      case "active":
        return !bill.hidden;
      case "hidden":
        return bill.hidden;
      case "auto":
        return bill.autoDraft;
      case "annual":
        return !!bill.isAnnual;
      default:
        return true;
    }
  });
  
  // Function to handle column header click for sorting
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      // If already sorting by this column, toggle direction
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      // Otherwise, sort by this column in ascending order
      setSortColumn(column);
      setSortDirection("asc");
    }
  };
  
  // Sort bills based on current sort settings
  const sortedBills = [...filteredBills].sort((a, b) => {
    let aValue, bValue;
    
    // Get the values to compare based on the sort column
    switch (sortColumn) {
      case "name":
        aValue = a.name.toLowerCase();
        bValue = b.name.toLowerCase();
        break;
      case "amount":
        aValue = parseFloat(a.amount);
        bValue = parseFloat(b.amount);
        break;
      case "dueDay":
        aValue = parseInt(a.dueDay);
        bValue = parseInt(b.dueDay);
        break;
      case "method":
        aValue = a.method?.toLowerCase() || "";
        bValue = b.method?.toLowerCase() || "";
        break;
      case "autoDraft":
        aValue = a.autoDraft ? 1 : 0;
        bValue = b.autoDraft ? 1 : 0;
        break;
      case "status":
        // Sort by annual status first, then by hidden status
        if (a.isAnnual !== b.isAnnual) {
          aValue = a.isAnnual ? 1 : 0;
          bValue = b.isAnnual ? 1 : 0;
        } else if (a.isAnnual && b.isAnnual) {
          // For annual bills, sort by year and month
          const aYear = parseInt(a.annualYear || "0");
          const bYear = parseInt(b.annualYear || "0");
          if (aYear !== bYear) {
            aValue = aYear;
            bValue = bYear;
          } else {
            // Same year, sort by month
            aValue = parseInt(a.annualMonth || "0");
            bValue = parseInt(b.annualMonth || "0");
          }
        } else {
          // Regular status sort
          aValue = a.hidden ? "hidden" : "active";
          bValue = b.hidden ? "hidden" : "active";
        }
        break;
      default:
        aValue = a.name.toLowerCase();
        bValue = b.name.toLowerCase();
    }
    
    // Compare the values based on sort direction
    if (sortDirection === "asc") {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });

  return (
    <div className="container mx-auto p-4 md:p-6 min-h-screen">
      {/* Payment Settings removed from here - now managed exclusively in the Settings page */}

      {/* Bill Management */}
      <div className="mb-6 card-container overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">
            Manage Bills
            {loading && (
              <span className="ml-2 inline-block">
                <span className="animate-pulse">Loading...</span>
              </span>
            )}
          </h2>
          <div className="flex items-center gap-2">
            <Select
              value={filter}
              onValueChange={setFilter}
            >
              <SelectTrigger className="bg-blue-900 border-gray-700 w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-[250px] overflow-y-auto">
                <SelectItem value="all">All Bills</SelectItem>
                <SelectItem value="active">Active Bills</SelectItem>
                <SelectItem value="hidden">Hidden Bills</SelectItem>
                <SelectItem value="auto">Auto-Draft</SelectItem>
                <SelectItem value="annual">Annual Bills</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              {isMultiSelectMode ? (
                <>
                  <Button
                    className="bg-yellow-700 hover:bg-yellow-800"
                    onClick={toggleMultiSelectMode}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="bg-red-700 hover:bg-red-800"
                    onClick={() => setBillToDelete(null)} // null here will trigger multi-delete
                    disabled={selectedBills.length === 0}
                  >
                    <Trash className="h-4 w-4 mr-1" /> Delete Selected ({selectedBills.length})
                  </Button>
                </>
              ) : (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button className="bg-blue-700 hover:bg-blue-800">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-blue-950 border-gray-700 text-white">
                    <DropdownMenuLabel>Bill Actions</DropdownMenuLabel>
                    <DropdownMenuSeparator className="bg-gray-700" />
                    <DropdownMenuItem onClick={handleAddBill} className="hover:bg-blue-900 cursor-pointer">
                      <Plus className="h-4 w-4" /> Add Bill
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setIsBulkAddDialogOpen(true)} className="hover:bg-blue-900 cursor-pointer">
                      <UserPlus className="h-4 w-4" /> Bulk Add
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={handleImportBills} className="hover:bg-blue-900 cursor-pointer">
                      <FileInput className="h-4 w-4" /> Import Bills
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-gray-700" />
                    <DropdownMenuItem onClick={toggleMultiSelectMode} className="hover:bg-blue-900 cursor-pointer">
                      <CheckSquare className="h-4 w-4" /> Multi-Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>
        </div>

        <div>
          {loading ? (
            <div className="my-8 flex flex-col items-center">
              <div className="text-center mb-4">Loading bills...</div>
              <Progress value={50} className="w-72 h-2 animate-pulse" />
            </div>
          ) : (
            <table className="min-w-full divide-y divide-white/10">
                <thead className="bg-blue-900 bg-opacity-50">
                  <tr>
                    {isMultiSelectMode && (
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      <div className="flex items-center">
                        <input 
                          type="checkbox" 
                          className="h-4 w-4 rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                          checked={selectedBills.length === filteredBills.length && filteredBills.length > 0}
                          onChange={toggleSelectAll}
                        />
                      </div>
                    </th>
                  )}
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("name")}
                  >
                    Name {sortColumn === "name" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("amount")}
                  >
                    Amount {sortColumn === "amount" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("dueDay")}
                  >
                    Due Day {sortColumn === "dueDay" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("method")}
                  >
                    Method {sortColumn === "method" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("autoDraft")}
                  >
                    Auto {sortColumn === "autoDraft" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th 
                    className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider cursor-pointer hover:text-white"
                    onClick={() => handleSort("status")}
                  >
                    Status {sortColumn === "status" && (sortDirection === "asc" ? "▲" : "▼")}
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-700">
                {sortedBills.length > 0 ? (
                  sortedBills.map((bill) => (
                    <tr key={bill.id}>
                      {isMultiSelectMode && (
                        <td className="px-4 py-3 whitespace-nowrap">
                          <input 
                            type="checkbox" 
                            className="h-4 w-4 rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                            checked={bill.id ? selectedBills.includes(bill.id) : false}
                            onChange={() => bill.id && toggleBillSelection(bill.id)}
                          />
                        </td>
                      )}
                      <td className="px-4 py-3 whitespace-nowrap">{bill.name}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {formatCurrency(Number(bill.amount))}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">{getOrdinal(parseInt(bill.dueDay))}</td>
                      <td className="px-4 py-3 whitespace-nowrap">{bill.method}</td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center">
                          <Switch 
                            checked={bill.autoDraft} 
                            onCheckedChange={async (checked) => {
                              if (bill.id) {
                                await updateBill(bill.id, { autoDraft: checked });
                              }
                            }}
                          />
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <StatusBadge status={bill.hidden ? "hidden" : "active"} />
                          {bill.isAnnual && (
                            <span className="text-xs text-purple-400 whitespace-nowrap">
                              Annual: {bill.annualMonth ? new Date(0, parseInt(bill.annualMonth) - 1).toLocaleString('default', { month: 'short' }) : ''}
                              {bill.annualYear ? ' ' + bill.annualYear : ''}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm flex gap-2">
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="h-8 w-8 bg-blue-700 hover:bg-blue-800"
                          onClick={() => handleEditBill(bill)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="icon" 
                          className="h-8 w-8 bg-red-700 hover:bg-red-800"
                          onClick={() => setBillToDelete(bill.id || "")}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="px-4 py-3 text-center text-gray-400">
                      No bills found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Add/Edit Bill Dialog */}
      <Dialog 
        open={editingBill !== null}
        onOpenChange={(open) => {
          if (!open) {
            setEditingBill(null);
            setIsAddingBill(false);
            // Refresh bills to ensure we have the latest data
            fetchBills();
          }
        }}
      >
        <DialogContent className="bg-white/[0.05] backdrop-blur-[20px] border-white/[0.18] text-white max-h-[90vh] overflow-y-auto rounded-[20px] shadow-[0_8px_32px_rgba(0,0,0,0.37)]">
          <DialogHeader>
            <DialogTitle>{isAddingBill ? "Add New Bill" : "Edit Bill"}</DialogTitle>
            <DialogDescription className="text-gray-400">
              Fill out the details below to {isAddingBill ? "add a new" : "update the"} bill.
            </DialogDescription>
          </DialogHeader>
          {editingBill && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Bill Name</Label>
                <Input
                  id="name"
                  className="bg-blue-900 border-gray-700"
                  placeholder="e.g. Rent, Electricity"
                  value={editingBill.name}
                  onChange={(e) => handleBillChange("name", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  className="bg-blue-900 border-gray-700"
                  placeholder="0.00"
                  value={editingBill.amount}
                  onChange={(e) => handleBillChange("amount", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="dueDay">Due Day</Label>
                <Input
                  id="dueDay"
                  type="number"
                  min="1"
                  max="31"
                  className="bg-blue-900 border-gray-700"
                  placeholder="1-31"
                  value={editingBill.dueDay}
                  onChange={(e) => handleBillChange("dueDay", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="method">Payment Method</Label>
                <Input
                  id="method"
                  className="bg-blue-900 border-gray-700"
                  placeholder="e.g. Credit Card, Bank Transfer"
                  value={editingBill.method}
                  onChange={(e) => handleBillChange("method", e.target.value)}
                />
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch
                    id="autoDraft"
                    checked={editingBill.autoDraft}
                    onCheckedChange={(checked) => handleBillChange("autoDraft", checked)}
                  />
                  <Label htmlFor="autoDraft">Auto Draft</Label>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch
                    id="hidden"
                    checked={editingBill.hidden}
                    onCheckedChange={(checked) => handleBillChange("hidden", checked)}
                  />
                  <Label htmlFor="hidden">Hide Bill</Label>
                </div>
              </div>

              {/* Annual Bill Section */}
              {/* Additional Payment Section */}
              <div className="col-span-1 md:col-span-2 pt-4 border-t border-gray-700">
                <div className="space-y-2">
                  <Label htmlFor="additionalPayment">Additional Payment</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="additionalPayment"
                      type="number"
                      step="0.01"
                      className="bg-blue-900 border-gray-700"
                      placeholder="0.00"
                      value={editingBill.additionalPayment || ""}
                      onChange={(e) => handleBillChange("additionalPayment", e.target.value)}
                    />
                    <div className="text-xs text-gray-400">
                      Total: {formatCurrency(Number(editingBill.amount) + Number(editingBill.additionalPayment || 0))}
                    </div>
                  </div>
                  <div className="text-xs text-gray-400">
                    (Additional payment adds to the base amount without changing it)
                  </div>
                </div>
              </div>

              {/* Account Credentials Section */}
              <div className="col-span-1 md:col-span-2 pt-4 border-t border-gray-700">
                <h3 className="text-md font-medium mb-3">Account Credentials</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <Input
                      id="username"
                      className="bg-blue-900 border-gray-700"
                      placeholder="Username for this bill"
                      value={editingBill.username || ""}
                      onChange={(e) => handleBillChange("username", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      className="bg-blue-900 border-gray-700"
                      placeholder="Email for this account"
                      value={editingBill.email || ""}
                      onChange={(e) => handleBillChange("email", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input
                      id="password"
                      type="password"
                      className="bg-blue-900 border-gray-700"
                      placeholder="Password for this account"
                      value={editingBill.password || ""}
                      onChange={(e) => handleBillChange("password", e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Annual Bill Section */}
              <div className="col-span-1 md:col-span-2 pt-4 border-t border-gray-700">
                <div className="flex items-center gap-2 mb-4">
                  <Switch
                    id="isAnnual"
                    checked={!!editingBill.isAnnual}
                    onCheckedChange={(checked) => handleBillChange("isAnnual", checked)}
                  />
                  <Label htmlFor="isAnnual">Annual Bill</Label>
                  <div className="ml-2 text-xs text-gray-400">
                    (Annual bills only appear in calculations during their specified month/year)
                  </div>
                </div>

                {editingBill.isAnnual && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="annualMonth">Month</Label>
                      <Select
                        value={editingBill.annualMonth || ""}
                        onValueChange={(value) => handleBillChange("annualMonth", value)}
                      >
                        <SelectTrigger className="bg-blue-900 border-gray-700">
                          <SelectValue placeholder="Select month" />
                        </SelectTrigger>
                        <SelectContent className="max-h-[250px] overflow-y-auto">
                          <SelectItem value="1">January</SelectItem>
                          <SelectItem value="2">February</SelectItem>
                          <SelectItem value="3">March</SelectItem>
                          <SelectItem value="4">April</SelectItem>
                          <SelectItem value="5">May</SelectItem>
                          <SelectItem value="6">June</SelectItem>
                          <SelectItem value="7">July</SelectItem>
                          <SelectItem value="8">August</SelectItem>
                          <SelectItem value="9">September</SelectItem>
                          <SelectItem value="10">October</SelectItem>
                          <SelectItem value="11">November</SelectItem>
                          <SelectItem value="12">December</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="annualYear">Year</Label>
                      <Select
                        value={editingBill.annualYear || ""}
                        onValueChange={(value) => handleBillChange("annualYear", value)}
                      >
                        <SelectTrigger className="bg-blue-900 border-gray-700">
                          <SelectValue placeholder="Select year" />
                        </SelectTrigger>
                        <SelectContent className="max-h-[250px] overflow-y-auto">
                          <SelectItem value={(new Date().getFullYear()).toString()}>
                            {new Date().getFullYear()}
                          </SelectItem>
                          <SelectItem value={(new Date().getFullYear() + 1).toString()}>
                            {new Date().getFullYear() + 1}
                          </SelectItem>
                          <SelectItem value={(new Date().getFullYear() + 2).toString()}>
                            {new Date().getFullYear() + 2}
                          </SelectItem>
                          <SelectItem value={(new Date().getFullYear() + 3).toString()}>
                            {new Date().getFullYear() + 3}
                          </SelectItem>
                          <SelectItem value={(new Date().getFullYear() + 4).toString()}>
                            {new Date().getFullYear() + 4}
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setEditingBill(null)}
              className="bg-gray-700 hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button 
              type="button"
              className="bg-blue-700 hover:bg-blue-800"
              onClick={handleSaveBill}
            >
              Save Bill
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog 
        open={billToDelete !== null || (selectedBills.length > 0 && isMultiSelectMode)}
        onOpenChange={(open) => {
          if (!open) {
            setBillToDelete(null);
            if (isMultiSelectMode) {
              setSelectedBills([]);
            }
          }
        }}
      >
        <AlertDialogContent className="bg-white/[0.05] backdrop-blur-[20px] border-white/[0.18] text-white max-h-[90vh] overflow-y-auto rounded-[20px] shadow-[0_8px_32px_rgba(0,0,0,0.37)]">
          <AlertDialogHeader>
            <AlertDialogTitle>
              {isDeleting ? (selectedBills.length > 0 ? "Deleting Bills..." : "Deleting Bill...") : "Are you sure?"}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-400">
              {isDeleting 
                ? (selectedBills.length > 0 
                    ? `Deleting ${selectedBills.length} bills. Please wait...` 
                    : "Deleting bill. Please wait...")
                : (billToDelete !== null 
                    ? "This action cannot be undone. This will permanently delete the bill."
                    : `This action cannot be undone. This will permanently delete ${selectedBills.length} bills.`)
              }
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          {isDeleting && selectedBills.length > 0 && (
            <div className="my-4">
              <Progress value={deleteProgress} className="h-2 w-full" />
              <div className="text-xs text-gray-400 mt-2 text-right">
                {Math.round(deleteProgress)}% complete
              </div>
            </div>
          )}
          
          <AlertDialogFooter>
            {!isDeleting && (
              <>
                <AlertDialogCancel className="bg-gray-700 hover:bg-gray-800 text-white">
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction 
                  className="bg-red-700 hover:bg-red-800"
                  onClick={handleDeleteConfirm}
                >
                  Delete
                </AlertDialogAction>
              </>
            )}
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Import Bills Dialog */}
      <Dialog
        open={isImportDialogOpen}
        onOpenChange={(open) => {
          // Prevent closing dialog during upload
          if (uploading) return;
          
          if (!open) {
            setIsImportDialogOpen(false);
            setImportResults(null);
            setUploadProgress(0);
          }
        }}
      >
        <DialogContent className="bg-white/[0.05] backdrop-blur-[20px] border-white/[0.18] text-white max-w-md max-h-[90vh] overflow-y-auto rounded-[20px] shadow-[0_8px_32px_rgba(0,0,0,0.37)]">
          <DialogHeader>
            <DialogTitle>{uploading ? "Uploading File..." : "Import Bills"}</DialogTitle>
            <DialogDescription className="text-gray-400">
              {uploading 
                ? "Please wait while your file is being processed..." 
                : "Upload a CSV or JSON file containing bills data to import"}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {!importResults ? (
              <>
                <Card className="bg-blue-900 bg-opacity-50 border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-sm font-medium">Upload File</CardTitle>
                    <CardDescription className="text-xs text-gray-400">
                      All file types accepted (.csv, .json, .txt, .pdf, images, etc.)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-center w-full">
                      <label 
                        htmlFor="file-upload" 
                        className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer border-gray-600 bg-blue-950 hover:bg-blue-900"
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                      >
                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                          <FileText className="w-8 h-8 mb-2 text-gray-400" />
                          <p className="mb-2 text-sm text-gray-400">
                            <span className="font-semibold">Click to upload</span> or drag and drop
                          </p>
                          <p className="text-xs text-gray-500">Any file type (max. 10MB)</p>
                        </div>
                        <input 
                          id="file-upload" 
                          type="file" 
                          className="hidden" 
                          onChange={handleFileChange}
                          ref={fileInputRef}
                          disabled={uploading}
                        />
                      </label>
                    </div>
                  </CardContent>
                  {uploading && (
                    <CardFooter className="flex flex-col gap-2">
                      <div className="flex justify-between w-full">
                        <div className="text-xs text-gray-400">
                          Uploading and processing...
                        </div>
                        <div className="text-xs text-gray-400">
                          {Math.round(uploadProgress)}%
                        </div>
                      </div>
                      <Progress value={uploadProgress} className="w-full h-2" />
                    </CardFooter>
                  )}
                </Card>
                
                <div className="text-sm text-gray-400 p-2 border border-gray-700 rounded-md bg-blue-950 bg-opacity-50">
                  <div className="font-medium mb-1">Supported formats:</div>
                  <div className="text-xs space-y-1">
                    <p>• CSV/Excel: Files with headers like name, amount, dueDay, etc.</p>
                    <p>• JSON: Array of bill objects</p>
                    <p>• Text: System will extract bill information from text</p>
                    <p>• Images/PDF/Other: Will create a bill based on filename</p>
                  </div>
                </div>
              </>
            ) : (
              <div className="space-y-4">
                <div className={`p-4 rounded-md ${importResults.success ? 'bg-green-950 text-green-400' : 'bg-red-950 text-red-400'}`}>
                  {importResults.success ? (
                    <div className="flex flex-col gap-2">
                      <div className="font-medium">Import Successful!</div>
                      <div>Successfully imported {importResults.imported} bills.</div>
                      {importResults.failed && importResults.failed > 0 && (
                        <div className="text-yellow-400">{importResults.failed} bills failed to import.</div>
                      )}
                    </div>
                  ) : (
                    <div className="flex flex-col gap-2">
                      <div className="font-medium">Import Failed</div>
                      {importResults.errors && importResults.errors.length > 0 && (
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          {importResults.errors.map((error, index) => (
                            <li key={index}>{error}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )}
                </div>
                
                {importResults.success && importResults.bills && importResults.bills.length > 0 && (
                  <div className="max-h-60 overflow-y-auto border border-gray-700 rounded-md">
                    <table className="min-w-full divide-y divide-gray-700">
                      <thead className="bg-blue-900 bg-opacity-50">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-400">Name</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-400">Amount</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-400">Due Day</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-700">
                        {importResults.bills.map((bill, index) => (
                          <tr key={index}>
                            <td className="px-4 py-2 text-sm">{bill.name}</td>
                            <td className="px-4 py-2 text-sm">{formatCurrency(Number(bill.amount))}</td>
                            <td className="px-4 py-2 text-sm">{getOrdinal(parseInt(bill.dueDay))}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                
                <div className="flex justify-center gap-2">
                  <Button 
                    onClick={() => {
                      setImportResults(null);
                      setUploadProgress(0);
                    }}
                  >
                    Import Another File
                  </Button>
                  <Button
                    variant="default"
                    className="bg-green-700 hover:bg-green-800"
                    onClick={() => {
                      setIsImportDialogOpen(false);
                      setImportResults(null);
                      setUploadProgress(0);
                    }}
                  >
                    View Bills
                  </Button>
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsImportDialogOpen(false)}
              className="border-gray-600"
              disabled={uploading}
            >
              {importResults?.success ? "Close" : "Cancel"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Add Bills Dialog */}
      <Dialog
        open={isBulkAddDialogOpen}
        onOpenChange={(open) => {
          // Prevent closing dialog during processing
          if (isBulkAdding) return;
          
          if (!open) {
            setIsBulkAddDialogOpen(false);
            setBulkBills([]);
          }
        }}
      >
        <DialogContent className="bg-white/[0.05] backdrop-blur-[20px] border-white/[0.18] text-white max-w-4xl max-h-[90vh] overflow-y-auto rounded-[20px] shadow-[0_8px_32px_rgba(0,0,0,0.37)]">
          <DialogHeader>
            <DialogTitle>
              {isBulkAdding ? "Adding Bills..." : "Bulk Add Bills"}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              {isBulkAdding 
                ? `Processing ${bulkBills.length} bills. Please wait...`
                : "Add multiple bills at once to save time"
              }
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="flex justify-between items-center">
              <h3 className="text-md font-medium">Bill Entries ({bulkBills.length})</h3>
              <Button
                size="sm"
                className="bg-blue-700 hover:bg-blue-800"
                disabled={isBulkAdding}
                onClick={() => {
                  // Add a new empty bill to the list
                  setBulkBills([...bulkBills, {
                    name: "",
                    amount: "",
                    dueDay: "",
                    method: "",
                    hidden: false,
                    autoDraft: false,
                    isAnnual: false
                  }]);
                }}
              >
                <Plus className="h-4 w-4 mr-1" /> Add Row
              </Button>
            </div>

            {bulkBills.length === 0 ? (
              <div className="text-center py-6 text-gray-400">
                <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No bills added yet. Click "Add Row" to start adding bills.</p>
              </div>
            ) : (
              <div className="border border-gray-700 rounded-md overflow-hidden">
                <table className="min-w-full divide-y divide-gray-700">
                  <thead className="bg-blue-900 bg-opacity-50">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-400">Name</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-400">Amount</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-400">Due Day</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-400">Method</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-400">Auto</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-400">Annual</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-400">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-700">
                    {bulkBills.map((bill, index) => (
                      <tr key={index}>
                        <td className="px-2 py-2">
                          <Input
                            className="bg-blue-900 border-gray-700 h-8"
                            placeholder="Bill name"
                            value={bill.name}
                            disabled={isBulkAdding}
                            onChange={(e) => {
                              const newBills = [...bulkBills];
                              newBills[index].name = e.target.value;
                              setBulkBills(newBills);
                            }}
                          />
                        </td>
                        <td className="px-2 py-2">
                          <Input
                            className="bg-blue-900 border-gray-700 h-8"
                            placeholder="0.00"
                            type="number"
                            step="0.01"
                            value={bill.amount}
                            disabled={isBulkAdding}
                            onChange={(e) => {
                              const newBills = [...bulkBills];
                              newBills[index].amount = e.target.value;
                              setBulkBills(newBills);
                            }}
                          />
                        </td>
                        <td className="px-2 py-2">
                          <Input
                            className="bg-blue-900 border-gray-700 h-8"
                            placeholder="1-31"
                            type="number"
                            min="1"
                            max="31"
                            value={bill.dueDay}
                            disabled={isBulkAdding}
                            onChange={(e) => {
                              const newBills = [...bulkBills];
                              newBills[index].dueDay = e.target.value;
                              setBulkBills(newBills);
                            }}
                          />
                        </td>
                        <td className="px-2 py-2">
                          <Input
                            className="bg-blue-900 border-gray-700 h-8"
                            placeholder="Payment method"
                            value={bill.method}
                            disabled={isBulkAdding}
                            onChange={(e) => {
                              const newBills = [...bulkBills];
                              newBills[index].method = e.target.value;
                              setBulkBills(newBills);
                            }}
                          />
                        </td>
                        <td className="px-2 py-2">
                          <div className="flex justify-center">
                            <Switch
                              checked={bill.autoDraft}
                              disabled={isBulkAdding}
                              onCheckedChange={(checked) => {
                                const newBills = [...bulkBills];
                                newBills[index].autoDraft = checked;
                                setBulkBills(newBills);
                              }}
                            />
                          </div>
                        </td>
                        <td className="px-2 py-2">
                          <div className="flex justify-center">
                            <Switch
                              checked={bill.isAnnual}
                              disabled={isBulkAdding}
                              onCheckedChange={(checked) => {
                                const newBills = [...bulkBills];
                                newBills[index].isAnnual = checked;
                                setBulkBills(newBills);
                              }}
                            />
                          </div>
                        </td>
                        <td className="px-2 py-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 bg-red-700 hover:bg-red-800"
                            disabled={isBulkAdding}
                            onClick={() => {
                              const newBills = [...bulkBills];
                              newBills.splice(index, 1);
                              setBulkBills(newBills);
                            }}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {bulkBills.length > 0 && (
              <div className="bg-blue-900 bg-opacity-50 border border-gray-700 rounded-md p-3 text-sm text-gray-300">
                <p className="mb-1">Tips:</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>Fill out all required fields (Name, Amount, Due Day, Method)</li>
                  <li>Due Day must be between 1-31</li>
                  <li>Annual bills will need month/year details after adding</li>
                </ul>
              </div>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setIsBulkAddDialogOpen(false)}
              className="border-gray-600"
              disabled={isBulkAdding}
            >
              Cancel
            </Button>
            {isBulkAdding ? (
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-400">
                  Adding bills: {Math.round(bulkAddProgress)}%
                </span>
                <Progress value={bulkAddProgress} className="w-20 h-2" />
              </div>
            ) : (
              <Button
                variant="default"
                className="bg-green-700 hover:bg-green-800"
                disabled={bulkBills.length === 0}
                onClick={async () => {
                  try {
                    // Validate bills
                    const invalidBills = bulkBills.filter(
                      bill => !bill.name || !bill.amount || !bill.dueDay || !bill.method
                    );
                    
                    if (invalidBills.length > 0) {
                      toast({
                        title: "Validation Error",
                        description: `${invalidBills.length} bills are missing required fields.`,
                        variant: "destructive"
                      });
                      return;
                    }
                    
                    // Start progress tracking
                    setIsBulkAdding(true);
                    setBulkAddProgress(0);
                    
                    // Add each bill with progress tracking
                    let successCount = 0;
                    const progressIncrement = 100 / bulkBills.length;
                    
                    for (let i = 0; i < bulkBills.length; i++) {
                      try {
                        await addBill(bulkBills[i]);
                        successCount++;
                      } catch (error) {
                        console.error("Failed to add bill:", error);
                      }
                      
                      // Update progress after each bill
                      setBulkAddProgress((i + 1) * progressIncrement);
                    }
                    
                    toast({
                      title: "Bills Added",
                      description: `Successfully added ${successCount} of ${bulkBills.length} bills.`,
                      variant: "default"
                    });
                    
                    setIsBulkAddDialogOpen(false);
                    setBulkBills([]);
                  } catch (error) {
                    console.error("Error adding bills:", error);
                    toast({
                      title: "Error",
                      description: "Failed to add bills. Please try again.",
                      variant: "destructive"
                    });
                  } finally {
                    setIsBulkAdding(false);
                    setBulkAddProgress(0);
                  }
                }}
              >
                Add {bulkBills.length} {bulkBills.length === 1 ? 'Bill' : 'Bills'}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
