import { createContext, ReactNode, useContext } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { insertUserSchema, User as SelectUser } from "@shared/schema";
import { getQueryFn, apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { playLogoutSoundAndMessage } from "../lib/audio-utils";
import { useLocation } from "wouter";

type AuthContextType = {
  user: SelectUser | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<SelectUser, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<SelectUser, Error, RegisterData>;
  demoAccessMutation: UseMutationResult<SelectUser, Error, void>;
};

type LoginData = Pick<SelectUser, "username" | "password">;
type RegisterData = { username: string; password: string; confirmPassword: string; };

export const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<SelectUser | null, Error>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData): Promise<SelectUser> => {
      const result = await apiRequest<SelectUser>("POST", "/api/login", credentials);
      if (!result) throw new Error("Authentication failed");
      return result;
    },
    onSuccess: async (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      
      // Import and initialize the store immediately after login
      // This solves the issue where bills don't appear until visiting the manage bills page
      const { initializeStore } = await import("@/lib/store");
      await initializeStore();
      
      // Prefetch bills and settings for dashboard view
      queryClient.prefetchQuery({ queryKey: ["/api/bills"] });
      queryClient.prefetchQuery({ queryKey: ["/api/settings"] });
      
      // Start background music by manipulating YouTube player if it exists
      // This forces music to play on login, addressing the issue where music doesn't automatically start
      setTimeout(() => {
        try {
          // Try to find YouTube player instance and force it to play
          const ytPlayer = document.querySelector('iframe[src*="youtube.com"]');
          if (ytPlayer) {
            console.log("Found YouTube player iframe on login success, triggering user interaction");
            
            // Force a click event on the player button to initiate playback
            const playerButton = document.querySelector('.fixed.bottom-3.right-3 button');
            if (playerButton && playerButton instanceof HTMLElement) {
              console.log("Triggering YouTube player button click to start music");
              setTimeout(() => {
                // Click to unmute if currently muted
                if (playerButton.querySelector('span')?.textContent === '🔇') {
                  playerButton.click();
                }
              }, 2000);
            }
          } else {
            console.log("YouTube player not found on login success");
          }
        } catch (err) {
          console.error("Error starting background music:", err);
        }
      }, 3000);
      
      toast({
        title: "Login successful",
        description: `Welcome back, ${user.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid username or password",
        variant: "destructive",
      });
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (credentials: RegisterData): Promise<SelectUser> => {
      if (credentials.password !== credentials.confirmPassword) {
        throw new Error("Passwords don't match");
      }
      
      const { confirmPassword, ...userData } = credentials;
      const result = await apiRequest<SelectUser>("POST", "/api/register", userData);
      if (!result) throw new Error("Registration failed");
      return result;
    },
    onSuccess: (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Registration successful",
        description: `Welcome, ${user.username}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Unable to create account",
        variant: "destructive",
      });
    },
  });

  // Demo access mutation - provides access to a read-only demo account
  const demoAccessMutation = useMutation({
    mutationFn: async (): Promise<SelectUser> => {
      const result = await apiRequest<SelectUser>("GET", "/api/demo-access");
      if (!result) throw new Error("Demo access failed");
      return result;
    },
    onSuccess: async (user: SelectUser) => {
      queryClient.setQueryData(["/api/user"], user);
      
      // Import and initialize the store immediately after demo login
      const { initializeStore } = await import("@/lib/store");
      await initializeStore();
      
      // Prefetch bills and settings for dashboard view
      queryClient.prefetchQuery({ queryKey: ["/api/bills"] });
      queryClient.prefetchQuery({ queryKey: ["/api/settings"] });
      
      toast({
        title: "Demo Access Granted",
        description: "Welcome to the demo account! You can explore all features safely.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Demo access failed",
        description: error.message || "Unable to access demo account",
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async (): Promise<void> => {
      // Set a flag to prevent playing the sound twice (once here, once on the logout success page)
      localStorage.setItem('logoutAudioPlayed', 'true');
      
      // Play the logout sound and message before the actual logout request
      // This ensures the sound plays before navigating away
      playLogoutSoundAndMessage();
      
      // Small delay to let the chime sound start before sending the request
      await new Promise(resolve => setTimeout(resolve, 300));
      
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      // Invalidate all queries to force refetch on next access
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/credit-scores"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stocks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/news"] });
      
      // Redirect to the dedicated logout success page
      navigate("/logout-success");
      
      toast({
        title: "Logged out",
        description: "You have been successfully logged out",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
        demoAccessMutation,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}