import { useState, useEffect } from 'react';

// Custom hook to detect voices and show the guide when appropriate
export function useVoiceGuide() {
  const [hasEzinneVoice, setHasEzinneVoice] = useState<boolean>(false);
  const [isMobileDevice, setIsMobileDevice] = useState<boolean>(false);
  const [platformType, setPlatformType] = useState<'ios' | 'android' | 'desktop'>('desktop');
  const [showVoiceGuide, setShowVoiceGuide] = useState<boolean>(false);

  // Detect device type and check for voice availability
  useEffect(() => {
    // Detect device platform
    const detectPlatform = () => {
      if (typeof window === 'undefined' || !navigator) return { isMobile: false, platform: 'desktop' };
      
      const userAgent = navigator.userAgent;
      
      // Detect if this is a mobile device
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
      setIsMobileDevice(isMobile);
      
      // Detect specific platform
      const isIOS = /iPad|iPhone|iPod/.test(userAgent);
      const isAndroid = /Android/i.test(userAgent);
      
      let platform: 'ios' | 'android' | 'desktop' = 'desktop';
      
      if (isIOS) {
        platform = 'ios';
        console.log("iOS device detected");
      } else if (isAndroid) {
        platform = 'android';
        console.log("Android device detected");
      }
      
      setPlatformType(platform);
      
      // Store platform in localStorage for persistent experience
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('platformType', platform);
      }
      
      console.log(`Device detection: Mobile: ${isMobile}, Platform: ${platform}`);
      return { isMobile, platform };
    };
    
    const { isMobile } = detectPlatform();

    // Check for voice availability if speech synthesis is supported
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      // Function to check for Nigerian voice availability
      const checkEzinneAvailability = () => {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length === 0) return; // Voices not loaded yet
        
        // Check for Ezinne specifically - exact name match
        const hasEzinne = voices.some(voice => 
          voice.name === 'Ezinne' || 
          voice.name === 'Microsoft Ezinne Online' || 
          voice.name === 'Microsoft Ezinne'
        );
        
        // Update state
        setHasEzinneVoice(hasEzinne);
        
        // Show guide if on mobile AND Ezinne is NOT available
        // But only if user hasn't dismissed it before
        if (isMobile && !hasEzinne) {
          const hideVoiceGuide = localStorage.getItem('hideVoiceGuide') === 'true';
          if (!hideVoiceGuide) {
            console.log("Mobile device without Ezinne voice detected - showing voice guide");
            // Slight delay to make sure the page is fully loaded
            setTimeout(() => {
              setShowVoiceGuide(true);
            }, 1500);
          }
        }

        // Log available voices for debugging
        console.log(`Available voices: ${voices.length}`);
        console.log(`Nigerian voices available: ${hasEzinne ? 'Yes' : 'No'}`);
        if (voices.length < 10) {
          // Log all voices if there are just a few
          console.log("All voices:", voices.map(v => v.name));
        } else {
          // Log just English voices if there are many
          const englishVoices = voices.filter(v => v.lang && v.lang.startsWith('en'));
          console.log("English voices:", englishVoices.map(v => v.name));
        }
      };
      
      // Run the check now and whenever voices change
      checkEzinneAvailability();
      
      // Also set up listener for when voices change/load
      const voicesChangedHandler = () => {
        checkEzinneAvailability();
      };
      
      window.speechSynthesis.addEventListener('voiceschanged', voicesChangedHandler);
      
      // Cleanup
      return () => {
        window.speechSynthesis.removeEventListener('voiceschanged', voicesChangedHandler);
      };
    }
  }, []);

  return {
    hasEzinneVoice,
    isMobileDevice,
    platformType,
    showVoiceGuide,
    setShowVoiceGuide
  };
}