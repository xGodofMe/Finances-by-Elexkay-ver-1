import { sql } from 'drizzle-orm';
import { db, pool } from '../server/db';

async function applyNewsSchema() {
  try {
    console.log('Creating news table...');
    
    // Create the news table
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS news (
        id SERIAL PRIMARY KEY,
        "userId" INTEGER NOT NULL,
        title TEXT NOT NULL,
        source TEXT NOT NULL,
        url TEXT NOT NULL,
        "publishedAt" TIMESTAMP DEFAULT NOW(),
        hidden BOOLEAN DEFAULT FALSE
      )
    `);
    
    console.log('News table created successfully!');
  } catch (error) {
    console.error('Error creating news table:', error);
  } finally {
    await pool.end();
  }
}

applyNewsSchema();