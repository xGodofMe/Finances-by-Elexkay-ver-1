-- Create LXK user
INSERT INTO users (username, password, isAdmin)
VALUES ('LXK', '74c18a9d29dfc8a09b59c055ac3952f5e0b5ec90600112df73aeaa49d2be17a0d3d5b9c55d2db1b0e0bdf2a9ef3bd79fcaecd76a6a19c7e0b66aea5f55f7c0b1.a7aa4bb91cec5e8dd5a58f6b7b8eed39', false);

-- Get the user ID
DO $$
DECLARE
  lxk_id INTEGER;
BEGIN
  SELECT id INTO lxk_id FROM users WHERE username = 'LXK';
  
  -- Create settings
  INSERT INTO settings (userId, payFrequency, lastPayDate, billingCushion, paymentStrategy, resetDate, autoResetEnabled)
  VALUES (lxk_id, 'Bi-Weekly', '2025-04-11T00:00:00.000Z', '2', 'Proactive', 1, true);
  
  -- Create default stock tickers
  INSERT INTO stocks (userId, symbol, companyName, price, change, changePercent, lastUpdated, hidden, isWatching)
  VALUES 
    (lxk_id, 'QQQ', 'Invesco QQQ Trust (NASDAQ)', '0', '0', '0', NOW(), false, true),
    (lxk_id, 'SPY', 'SPDR S&P 500 ETF Trust', '0', '0', '0', NOW(), false, true),
    (lxk_id, 'DIA', 'SPDR Dow Jones Industrial Average ETF', '0', '0', '0', NOW(), false, true);
  
  -- Create random bills for the user
  INSERT INTO bills (userId, name, amount, dueDay, method, status, website, username, password, hidden, autoDraft, isAnnual)
  VALUES 
    (lxk_id, 'Rent', '1500', '1', 'Online', 'upcoming', 'https://www.example-rent.com', 'user_rent', 'pass_rent', false, true, false),
    (lxk_id, 'Electric', '150', '15', 'Online', 'upcoming', 'https://www.electricutilities.com', 'user_elec', 'pass_elec', false, false, false),
    (lxk_id, 'Water', '75', '10', 'Online', 'paid', 'https://waterservice.com', 'user_water', 'pass_water', false, true, false),
    (lxk_id, 'Internet', '89', '22', 'Online', 'upcoming', 'https://www.internetprovider.com', 'user_net', 'pass_net', false, false, false),
    (lxk_id, 'Cell Phone', '120', '18', 'Online', 'due', 'https://www.cellprovider.com', 'user_cell', 'pass_cell', false, true, false),
    (lxk_id, 'Netflix', '19', '5', 'Online', 'active', 'https://www.netflix.com', 'user_netflix', 'pass_netflix', false, true, false),
    (lxk_id, 'Car Insurance', '200', '12', 'Online', 'upcoming', 'https://www.insuranceco.com', 'user_car', 'pass_car', false, false, false),
    (lxk_id, 'Gym Membership', '50', '20', 'Online', 'active', 'https://www.gymfitness.com', 'user_gym', 'pass_gym', false, true, false),
    (lxk_id, 'Credit Card', '250', '25', 'Online', 'upcoming', 'https://www.creditcardco.com', 'user_cc', 'pass_cc', false, false, false),
    (lxk_id, 'Student Loan', '325', '28', 'Online', 'upcoming', 'https://www.studentloan.gov', 'user_loan', 'pass_loan', false, false, false);
END $$;