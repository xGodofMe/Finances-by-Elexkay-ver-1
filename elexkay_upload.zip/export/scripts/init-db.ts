import { db } from "../server/db";
import { bills, users, settings } from "../shared/schema";
import { eq } from "drizzle-orm";

async function main() {
  console.log("Initializing database...");

  // Create default user if it doesn't exist
  const users_result = await db.select().from(users).where(eq(users.username, "user"));
  let user = users_result[0];
  
  if (!user) {
    const result = await db.insert(users).values({
      username: "user",
      password: "password"
    }).returning();
    user = result[0];
    console.log("Created default user:", user);
  } else {
    console.log("Default user already exists");
  }

  // Clear existing bills for this user
  await db.delete(bills).where(eq(bills.userId, user.id));
  console.log("Cleared existing bills");

  // Create default settings for this user if they don't exist
  const settings_result = await db.select().from(settings).where(eq(settings.userId, user.id));
  const existingSettings = settings_result[0];
  
  if (!existingSettings) {
    await db.insert(settings).values({
      userId: user.id,
      paymentStrategy: "Proactive",
      payFrequency: "Bi-Weekly",
      lastPayDate: new Date().toISOString().slice(0, 10)
    });
    console.log("Created default settings");
  } else {
    console.log("Settings already exist");
  }

  // Add all the bills from the provided list
  const billsData = [
    { name: "EZ Pass", amount: "50.00", dueDay: "1", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "Mortgage", amount: "2276.34", dueDay: "1", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "HOA", amount: "250.00", dueDay: "1", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "HRSD (Water)", amount: "100.00", dueDay: "17", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "Spectrum", amount: "130.00", dueDay: "26", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "Dominion", amount: "150.00", dueDay: "17", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "Hulu", amount: "7.00", dueDay: "16", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "USAA Insurance", amount: "210.00", dueDay: "20", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "iCloud", amount: "3.00", dueDay: "20", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "YouTube", amount: "23.00", dueDay: "8", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "Verizon Phone", amount: "200.00", dueDay: "22", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "Storage", amount: "62.00", dueDay: "22", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Netflix", amount: "20.00", dueDay: "25", method: "Citi Card", hidden: false, autoDraft: false, userId: user.id },
    { name: "Bofa", amount: "180.00", dueDay: "25", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Cap 1 Savor", amount: "41.00", dueDay: "20", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Apple Card", amount: "0.00", dueDay: "30", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Netnet", amount: "200.00", dueDay: "11", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "USAA CC", amount: "20.00", dueDay: "11", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Shell CC", amount: "0.00", dueDay: "13", method: "Paid Off", hidden: false, autoDraft: false, userId: user.id },
    { name: "Kay Jewelers", amount: "35.00", dueDay: "21", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Star Card", amount: "100.00", dueDay: "18", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Cap 1, 1k", amount: "40.00", dueDay: "19", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Cap 1, 3k", amount: "110.00", dueDay: "19", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "American", amount: "110.00", dueDay: "21", method: "Bills", hidden: false, autoDraft: false, userId: user.id },
    { name: "Best Buy", amount: "0.00", dueDay: "28", method: "Paid Off", hidden: false, autoDraft: false, userId: user.id },
    { name: "Synchrony", amount: "332.00", dueDay: "28", method: "Bills", hidden: false, autoDraft: true, userId: user.id },
    { name: "Lowes", amount: "23.00", dueDay: "28", method: "Auto Payment", hidden: false, autoDraft: true, userId: user.id },
    { name: "Amazon CC", amount: "73.00", dueDay: "28", method: "Auto Payment", hidden: false, autoDraft: true, userId: user.id },
    { name: "Sams Club", amount: "17.00", dueDay: "28", method: "Auto Payment", hidden: false, autoDraft: true, userId: user.id },
    { name: "CareCredit", amount: "88.00", dueDay: "28", method: "Auto Payment", hidden: false, autoDraft: true, userId: user.id },
    { name: "Mercury+Sho", amount: "113.00", dueDay: "28", method: "Auto Payment", hidden: false, autoDraft: true, userId: user.id },
    { name: "Paramount+Sho", amount: "12.00", dueDay: "14", method: "Annual", hidden: false, autoDraft: false, userId: user.id },
    { name: "Amazon", amount: "140.00", dueDay: "16", method: "Annual", hidden: false, autoDraft: false, userId: user.id },
    { name: "Nest Aware", amount: "120.00", dueDay: "20", method: "Annual", hidden: false, autoDraft: false, userId: user.id },
    { name: "Microsoft", amount: "50.00", dueDay: "25", method: "Annual", hidden: false, autoDraft: false, userId: user.id },
    { name: "STARZ", amount: "44.00", dueDay: "25", method: "Annual", hidden: false, autoDraft: false, userId: user.id },
    { name: "HBO Max (Annu)", amount: "149.00", dueDay: "27", method: "Annual", hidden: false, autoDraft: false, userId: user.id }
  ];

  await db.insert(bills).values(billsData);
  console.log(`Added ${billsData.length} bills`);

  console.log("Database initialization complete");
}

main()
  .catch(console.error)
  .finally(() => process.exit(0));