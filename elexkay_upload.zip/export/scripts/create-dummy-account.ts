import { db } from "../server/db";
import { eq } from "drizzle-orm";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function createDummyAccount() {
  console.log("Starting dummy account creation...");
  
  // Check if user already exists
  const existingUser = await db.select().from(users).where(eq(users.username, "LXK")).execute();
  
  if (existingUser.length > 0) {
    console.log("User LXK already exists. Deleting and recreating...");
    
    // Delete existing user data
    const userId = existingUser[0].id;
    await db.delete(bills).where(eq(bills.userId, userId)).execute();
    await db.delete(stocks).where(eq(stocks.userId, userId)).execute();
    await db.delete(settings).where(eq(settings.userId, userId)).execute();
    await db.delete(users).where(eq(users.id, userId)).execute();
  }
  
  // Create the user
  const hashedPassword = await hashPassword("LXK");
  const [newUser] = await db
    .insert(users)
    .values({
      username: "LXK",
      password: hashedPassword,
      isAdmin: false
    })
    .returning();
  
  console.log(`Created user with ID: ${newUser.id}`);
  
  const userId = newUser.id;
  
  // Create settings
  await db.insert(settings).values({
    userId,
    payFrequency: "Bi-Weekly",
    lastPayDate: new Date().toISOString(),
    billingCushion: "2",
    paymentStrategy: "Proactive",
    resetDate: 1,
    autoResetEnabled: true
  });
  
  console.log("Created settings");
  
  // Create default stocks (NASDAQ, S&P 500, DOW)
  const defaultStocks = [
    {
      userId,
      symbol: "QQQ",
      companyName: "Invesco QQQ Trust (NASDAQ)",
      price: "0",
      change: "0",
      changePercent: "0",
      lastUpdated: new Date().toISOString(),
      hidden: false,
      isWatching: true
    },
    {
      userId,
      symbol: "SPY",
      companyName: "SPDR S&P 500 ETF Trust",
      price: "0",
      change: "0",
      changePercent: "0",
      lastUpdated: new Date().toISOString(),
      hidden: false,
      isWatching: true
    },
    {
      userId,
      symbol: "DIA",
      companyName: "SPDR Dow Jones Industrial Average ETF",
      price: "0",
      change: "0",
      changePercent: "0",
      lastUpdated: new Date().toISOString(),
      hidden: false,
      isWatching: true
    }
  ];
  
  for (const stock of defaultStocks) {
    await db.insert(stocks).values(stock);
  }
  
  console.log("Added default stock tickers");
  
  // Generate random bills
  const billNames = [
    "Rent", "Mortgage", "Electric", "Water", "Gas", "Internet", "Cable TV", 
    "Cell Phone", "Car Payment", "Car Insurance", "Health Insurance", 
    "Life Insurance", "Netflix", "Hulu", "Disney+", "Spotify", 
    "Gym Membership", "Credit Card", "Student Loan", "Personal Loan"
  ];
  
  const websites = [
    "https://www.example-rent.com", "https://www.mortgageco.com", "https://www.electricutilities.com",
    "https://waterservice.com", "https://www.gastility.com", "https://www.internetprovider.com",
    "https://www.cableservices.com", "https://www.cellprovider.com", "https://www.autofinance.com",
    "https://www.insuranceco.com", "https://www.healthinsurer.com", "https://www.lifeinsurance.com",
    "https://www.netflix.com", "https://www.hulu.com", "https://www.disneyplus.com",
    "https://www.spotify.com", "https://www.gymfitness.com", "https://www.creditcardco.com",
    "https://www.studentloan.gov", "https://www.personalloanprovider.com"
  ];
  
  // Shuffle the bill names to get random selection
  const shuffledBills = [...billNames].sort(() => 0.5 - Math.random());
  const numBills = 10; // Number of bills to create
  
  // Get today's date
  const today = new Date();
  const currentMonth = today.getMonth();
  const currentYear = today.getFullYear();
  
  for (let i = 0; i < numBills; i++) {
    const billName = shuffledBills[i];
    const website = websites[billNames.indexOf(billName)];
    
    // Random amount between $20 and $1000
    const amount = Math.floor(Math.random() * 980) + 20;
    
    // Random due day between 1 and 28
    const dueDay = Math.floor(Math.random() * 28) + 1;
    
    // Random status
    const statuses = ["paid", "upcoming", "active", "hidden", "skip", "due"];
    const statusIndex = Math.floor(Math.random() * statuses.length);
    const status = statuses[statusIndex];
    
    // Create a due date for this month
    const dueDate = new Date(currentYear, currentMonth, dueDay);
    
    // If due date is in the past, move to next month
    if (dueDate < today && status !== "paid") {
      dueDate.setMonth(dueDate.getMonth() + 1);
    }
    
    // Random username and password for the bill website
    const credentials = {
      username: `user_${Math.floor(Math.random() * 1000)}`,
      password: `pass_${Math.floor(Math.random() * 1000)}`
    };
    
    // Create the bill
    await db.insert(bills).values({
      userId,
      name: billName,
      amount: amount.toString(),
      dueDay: dueDay.toString(),
      method: "Online",
      status,
      website,
      username: credentials.username,
      password: credentials.password,
      hidden: false,
      autoDraft: Math.random() > 0.5,
      isAnnual: false
    });
  }
  
  console.log(`Created ${numBills} random bills`);
  console.log("Dummy account setup complete!");
}

function getCategory(billName: string): string {
  const categories: Record<string, string> = {
    "Rent": "Housing",
    "Mortgage": "Housing",
    "Electric": "Utilities",
    "Water": "Utilities",
    "Gas": "Utilities",
    "Internet": "Telecommunications",
    "Cable TV": "Entertainment",
    "Cell Phone": "Telecommunications",
    "Car Payment": "Transportation",
    "Car Insurance": "Insurance",
    "Health Insurance": "Insurance",
    "Life Insurance": "Insurance",
    "Netflix": "Entertainment",
    "Hulu": "Entertainment",
    "Disney+": "Entertainment",
    "Spotify": "Entertainment",
    "Gym Membership": "Health & Fitness",
    "Credit Card": "Debt",
    "Student Loan": "Debt",
    "Personal Loan": "Debt"
  };
  
  return categories[billName] || "Other";
}

// Run the function
createDummyAccount()
  .then(() => {
    console.log("Script completed successfully");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error:", error);
    process.exit(1);
  });