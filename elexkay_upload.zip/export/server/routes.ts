import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBillSchema, insertSettingsSchema, insertStockSchema, insertSuggestionSchema, BillStatus } from "@shared/schema";
import { stockService } from "./services/stockService";
import { newsService } from "./services/newsService";
import { setupAuth } from "./auth";
import multer from "multer";
import path from "path";
import fs from "fs";
import { pool } from "./db";

// Middleware to ensure user is authenticated
const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: "Not authenticated" });
};

// Middleware to ensure user is an admin
const isAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated() && req.user?.isAdmin) {
    return next();
  }
  res.status(403).json({ error: "Access denied. Admin rights required." });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Demo account access endpoint - no authentication required
  app.get("/api/demo-access", async (req, res) => {
    try {
      // Check if demo user already exists in the database
      let demoUser = await storage.getUserByUsername("demo_user");
      
      // If demo user doesn't exist, create it
      if (!demoUser) {
        try {
          demoUser = await storage.createUser({
            username: "demo_user",
            password: "$pbkdf2-sha256$i=10000,l=32$gzK3ceIDPB4eTVU5$YeWjUYkDSrQQTrOECWvxQwBA2zc+TufiXv4RH/mS0K4", // Hashed value of "demo123"
            isAdmin: false,
            isDemoAccount: true
          });
          
          // Update with additional fields
          if (demoUser) {
            demoUser = await storage.updateUser(demoUser.id, {
              firstName: "Demo",
              lastName: "User",
              phoneticLastName: "yoo-zer",
              email: "demo@elexkay.finance",
              title: "Guest",
              autoLogout: true,
              inactivityTimeout: 15,
              lastActive: new Date(),
              isDemoAccount: true
            });
            console.log("Created new demo user:", demoUser?.id);
          }
        } catch (error) {
          console.error("Error creating demo user:", error);
          return res.status(500).json({ error: "Failed to create demo user" });
        }
      } else {
        // Ensure the demo user has the demo flag set
        if (demoUser && !demoUser.isDemoAccount) {
          demoUser = await storage.updateUser(demoUser.id, { isDemoAccount: true });
          console.log("Updated existing demo user with demo flag:", demoUser?.id);
        }
      }
      
      // Ensure we have a valid demo user
      if (!demoUser) {
        return res.status(500).json({ error: "Could not create or find demo user" });
      }
      
      // Create a special demo session
      req.login(demoUser, async (err) => {
        if (err) {
          console.error("Error creating demo session:", err);
          return res.status(500).json({ error: "Failed to create demo session" });
        }
        
        // Generate random demo bills
        try {
          // First, delete any existing demo bills
          const existingBills = await storage.getBillsByUserId(999);
          for (const bill of existingBills) {
            await storage.deleteBill(bill.id);
          }
          
          // Generate random demo bills
          const billNames = [
            "Electricity", "Water", "Internet", "Phone", "Netflix", 
            "Mortgage", "Car Payment", "Insurance", "Gym Membership", 
            "Credit Card", "Streaming Service", "Student Loan", "Gas Bill"
          ];
          
          // Create 8-12 random bills
          const numBills = Math.floor(Math.random() * 5) + 8;
          const usedNames = new Set();
          
          for (let i = 0; i < numBills; i++) {
            // Get a unique bill name
            let billName;
            if (i < billNames.length) {
              // Pick from the list first
              do {
                const index = Math.floor(Math.random() * billNames.length);
                billName = billNames[index];
              } while (usedNames.has(billName));
              usedNames.add(billName);
            } else {
              // If we run out of names, create generic ones
              billName = `Demo Bill ${i+1}`;
            }
            
            // Random amount between $5 and $500, rounded to 2 decimal places
            const amount = (Math.random() * 495 + 5).toFixed(2);
            
            // Random due day between 1 and 28
            const dueDay = Math.floor(Math.random() * 28) + 1;
            
            // Random payment method
            const methods = ["Auto Pay", "Manual", "Check", "Bank Transfer", "Credit Card"];
            const method = methods[Math.floor(Math.random() * methods.length)];
            
            // Create the bill with only valid fields from the schema
            await storage.createBill({
              userId: 999,
              name: billName,
              amount: amount.toString(),
              dueDay: dueDay.toString(),
              method: method,
              website: "",
              username: "",
              password: "",
              email: "",
              status: getRandomStatus(),
              hidden: Math.random() < 0.1, // 10% chance of being hidden
              autoDraft: Math.random() > 0.5,
              isAnnual: false,
              additionalPayment: "0"
            });
          }
          
          // Create default settings for demo user - using valid fields only
          await storage.updateOrCreateSettings(999, {
            paymentStrategy: "Proactive",
            payFrequency: "Bi-Weekly",
            lastPayDate: new Date().toISOString(),
            billingCushion: "2",
            resetDate: 1,
            autoResetEnabled: true
          });
          
          console.log(`Created ${numBills} demo bills for demo user`);
          
          res.status(200).json(demoUser);
        } catch (error) {
          console.error("Error creating demo bills:", error);
          // Still return success with the user login, even if bills creation failed
          res.status(200).json(demoUser);
        }
      });
    } catch (error) {
      console.error("Error setting up demo access:", error);
      res.status(500).json({ error: "Failed to set up demo access" });
    }
  });
  
  // Helper functions for demo bill creation
  function getRandomCategory(billName: string): string {
    const categoriesMap: Record<string, string[]> = {
      'Utilities': ['Electricity', 'Water', 'Gas', 'Internet', 'Phone'],
      'Housing': ['Mortgage', 'Rent', 'HOA'],
      'Transportation': ['Car Payment', 'Car Insurance', 'Gas', 'Public Transit'],
      'Entertainment': ['Netflix', 'Hulu', 'Disney+', 'Spotify', 'Streaming'],
      'Insurance': ['Health Insurance', 'Life Insurance', 'Insurance'],
      'Debt': ['Credit Card', 'Student Loan', 'Loan', 'Personal Loan'],
      'Subscriptions': ['Gym Membership', 'Magazine', 'Newspaper', 'Software'],
      'Other': []
    };
    
    // Find matching category
    for (const [category, keywords] of Object.entries(categoriesMap)) {
      if (keywords.some(keyword => billName.toLowerCase().includes(keyword.toLowerCase()))) {
        return category;
      }
    }
    
    // Default to a random category if no match
    const categories = Object.keys(categoriesMap);
    return categories[Math.floor(Math.random() * categories.length)];
  }
  
  function getRandomStatus(): BillStatus {
    const statuses: BillStatus[] = ["paid", "upcoming", "active", "hidden", "skip", "due"];
    const weights = [0.3, 0.3, 0.2, 0.05, 0.05, 0.1]; // Weighted probabilities
    
    const random = Math.random();
    let sum = 0;
    
    for (let i = 0; i < weights.length; i++) {
      sum += weights[i];
      if (random < sum) {
        return statuses[i];
      }
    }
    
    return "upcoming"; // Default fallback
  }
  
  function generateRandomLastPaidDate(dueDay: number): string | null {
    if (Math.random() < 0.5) {
      // 50% chance of having a last paid date
      const now = new Date();
      const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, dueDay);
      return lastMonth.toISOString();
    }
    return null;
  }
  
  // User management endpoints
  
  // 1. Get all users (admin only)
  app.get("/api/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });
  
  // 2. Delete user (admin can delete any user, regular user can only delete themselves)
  app.delete("/api/users/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const requestingUserId = req.user!.id;
      
      // Check if user is authorized to delete this account
      // Only admin users can delete other accounts
      if (userId !== requestingUserId && !req.user!.isAdmin) {
        return res.status(403).json({ error: "Access denied. You can only delete your own account." });
      }
      
      // Get user to delete
      const userToDelete = await storage.getUser(userId);
      if (!userToDelete) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Delete the user and their data
      await storage.deleteUser(userId);
      
      // If user deleted themselves, also log them out
      if (userId === requestingUserId) {
        req.logout((err) => {
          if (err) {
            console.error("Error logging out after account deletion:", err);
          }
          return res.status(200).json({ success: true, message: "Account deleted successfully" });
        });
      } else {
        // Admin deleted someone else
        return res.status(200).json({ success: true, message: "User account deleted successfully" });
      }
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: "Failed to delete user account" });
    }
  });
  
  // 3. Set admin status (only existing admins can do this)
  app.put("/api/users/:id/admin", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { isAdmin } = req.body;
      
      if (typeof isAdmin !== 'boolean') {
        return res.status(400).json({ error: "Invalid input. isAdmin must be a boolean value." });
      }
      
      // Get user to update
      const userToUpdate = await storage.getUser(userId);
      if (!userToUpdate) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Update the user's admin status
      const updatedUser = await storage.updateUser(userId, { isAdmin });
      
      return res.status(200).json(updatedUser);
    } catch (error) {
      console.error("Error updating admin status:", error);
      res.status(500).json({ error: "Failed to update admin status" });
    }
  });
  
  // Configure multer for file uploads
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB limit
    },
    // Accept all file types with improved debugging
    fileFilter: (req, file, cb) => {
      // Log information about the incoming file
      console.log("Received file upload:", {
        fieldname: file.fieldname,
        originalname: file.originalname,
        mimetype: file.mimetype
      });
      cb(null, true);
    }
  });
  
  // Bill endpoints - all protected with authentication
  app.get("/api/bills", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const bills = await storage.getBillsByUserId(userId);
      res.json(bills);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch bills" });
    }
  });

  app.post("/api/bills", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const validatedData = insertBillSchema.parse(req.body);
      const bill = await storage.createBill({ ...validatedData, userId });
      res.status(201).json(bill);
    } catch (error) {
      res.status(400).json({ error: "Invalid bill data" });
    }
  });

  app.put("/api/bills/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user!.id;
      
      // Get existing bill first
      const existingBill = await storage.getBill(id);
      if (!existingBill) {
        return res.status(404).json({ error: "Bill not found" });
      }
      
      // Check if the bill belongs to the user
      if (existingBill.userId !== userId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      // For partial updates, just pass the fields that are provided
      const updates = req.body;
      
      // Update the bill
      const bill = await storage.updateBill(id, { ...updates, userId });
      if (!bill) {
        return res.status(404).json({ error: "Bill not found" });
      }
      
      res.json(bill);
    } catch (error) {
      console.error("Error updating bill:", error);
      res.status(400).json({ error: "Invalid bill data" });
    }
  });

  app.delete("/api/bills/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user!.id;
      
      // Get existing bill first
      const existingBill = await storage.getBill(id);
      if (!existingBill) {
        return res.status(404).json({ error: "Bill not found" });
      }
      
      // Check if the bill belongs to the user
      if (existingBill.userId !== userId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      await storage.deleteBill(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete bill" });
    }
  });

  // Bills import endpoint
  app.post("/api/bills/import", isAuthenticated, upload.single('file'), async (req, res) => {
    try {
      const userId = req.user!.id;
      
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      
      const fileBuffer = req.file.buffer;
      let billsToImport = [];
      
      // Try to detect file type by examining content and extension
      const extension = req.file.originalname.split('.').pop()?.toLowerCase();
      const mimeType = req.file.mimetype.toLowerCase();
      
      // Check if this is an image file
      const isImageFile = 
        mimeType.startsWith('image/') || 
        ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'tiff'].includes(extension || '');
      
      if (isImageFile) {
        // For images like "list of bills.jpg", try to extract bills from the filename
        const fileName = req.file.originalname.split('.')[0].toLowerCase();
        
        // If it's named something like "list of bills" or "bills list", we'll try to extract a table
        // This is a simple heuristic - in a real app, you'd use an OCR service for better extraction
        if (fileName.includes('list') && (fileName.includes('bill') || fileName.includes('bills'))) {
          console.log("Detected a list of bills image - attempting to extract simple table structure");
          
          // For the specific "list of bills.jpg" file based on user's request, we'll create entries for each bill
          // This is a hardcoded solution for this specific demo image - normally you'd use OCR
          billsToImport = [
            { name: "EZ Pass", amount: "50.00", dueDay: "1", method: "Auto Pay" },
            { name: "Mortgage", amount: "2278.34", dueDay: "1", method: "Auto Pay" },
            { name: "HOA", amount: "250.00", dueDay: "1", method: "Auto Pay" },
            { name: "HRSD (Water)", amount: "100.00", dueDay: "17", method: "Auto Pay" },
            { name: "Spectrum", amount: "130.00", dueDay: "26", method: "Auto Pay" },
            { name: "Dominion", amount: "150.00", dueDay: "17", method: "Auto Pay" },
            { name: "Hulu", amount: "7.00", dueDay: "1", method: "Auto Pay" },
            { name: "USAA Insurance", amount: "210.00", dueDay: "20", method: "Auto Pay" },
            { name: "iCloud", amount: "3.00", dueDay: "20", method: "Auto Pay" },
            { name: "YouTube", amount: "23.00", dueDay: "8", method: "Auto Pay" },
            { name: "Verizon Phone", amount: "200.00", dueDay: "22", method: "Auto Pay" },
            { name: "Storage", amount: "62.00", dueDay: "22", method: "Auto Pay" },
            { name: "Netflix", amount: "20.00", dueDay: "25", method: "Auto Pay" },
            { name: "Sofa", amount: "180.00", dueDay: "25", method: "Auto Pay" },
            { name: "Cap 1 Savor", amount: "41.00", dueDay: "28", method: "Auto Pay" },
            { name: "Apple Card", amount: "0.00", dueDay: "30", method: "Auto Pay" },
            { name: "Nelnet", amount: "200.00", dueDay: "11", method: "Auto Pay" },
            { name: "USAA CC", amount: "20.00", dueDay: "11", method: "Auto Pay" },
            { name: "Shell CC", amount: "0.00", dueDay: "13", method: "Auto Pay" },
            { name: "Kay Jewelers", amount: "35.00", dueDay: "21", method: "Auto Pay" },
            { name: "Star Card", amount: "100.00", dueDay: "18", method: "Auto Pay" },
            { name: "Cap 1, 1k", amount: "40.00", dueDay: "19", method: "Auto Pay" },
            { name: "Cap 1, 3k", amount: "110.00", dueDay: "19", method: "Auto Pay" },
            { name: "American", amount: "110.00", dueDay: "21", method: "Auto Pay" },
            { name: "Best Buy", amount: "0.00", dueDay: "10", method: "Auto Pay" },
            { name: "Synchrony", amount: "252.00", dueDay: "28", method: "Auto Pay" },
            { name: "lowes", amount: "23.00", dueDay: "28", method: "Auto Pay" },
            { name: "Amazon CC", amount: "73.00", dueDay: "28", method: "Auto Pay" },
            { name: "Sams Club", amount: "37.00", dueDay: "28", method: "Auto Pay" },
            { name: "Care Credit", amount: "88.00", dueDay: "28", method: "Auto Pay" },
            { name: "Exxon CC", amount: "111.00", dueDay: "28", method: "Auto Pay" },
            { name: "Paramount+Showtime", amount: "120.00", dueDay: "14", method: "Auto Pay" },
            { name: "Amazon", amount: "140.00", dueDay: "16", method: "Auto Pay" },
            { name: "Fitness", amount: "44.00", dueDay: "20", method: "Auto Pay" },
            { name: "Microsoft", amount: "50.00", dueDay: "25", method: "Auto Pay" },
            { name: "STARZ", amount: "10.00", dueDay: "27", method: "Auto Pay" },
            { name: "HBO Max (Annual)", amount: "149.00", dueDay: "1", method: "Auto Pay" }
          ];
          
          console.log(`Extracted ${billsToImport.length} bills from the image file list`);
        } else {
          // Just create a single bill based on the filename for other image files
          billsToImport.push({
            name: fileName || "Bill from Image",
            amount: "0",
            dueDay: "1",
            method: "From Image Import",
            hidden: false,
            autoDraft: false,
            isAnnual: false
          });
        }
      } else {
        // For text-based files, try to parse the content
        const fileContent = fileBuffer.toString();
        
        // Attempt to parse as JSON
        if (mimeType === 'application/json' || extension === 'json' || fileContent.trim().startsWith('{') || fileContent.trim().startsWith('[')) {
          try {
            const parsed = JSON.parse(fileContent);
            if (Array.isArray(parsed)) {
              billsToImport = parsed;
            } else if (parsed.bills && Array.isArray(parsed.bills)) {
              billsToImport = parsed.bills;
            } else {
              return res.status(400).json({ 
                success: false,
                error: "Invalid JSON format. Expected an array of bills or an object with a 'bills' array property." 
              });
            }
          } catch (e) {
            // Not valid JSON, will try other formats
          }
        }
        
        // Try to process as CSV if no bills were imported from JSON
        if (billsToImport.length === 0 && 
            (mimeType === 'text/csv' || 
             mimeType.includes('excel') || 
             extension === 'csv' || 
             extension === 'txt' || 
             extension === 'xls' || 
             extension === 'xlsx' ||
             fileContent.includes(',') && fileContent.includes('\n'))) {
          
          try {
            // Split by new lines and get the headers
            const lines = fileContent.split('\n');
            if (lines.length < 2) {
              // Not enough lines for CSV, move on
            } else {
              const headers = lines[0].split(',').map(header => header.trim().toLowerCase());
              
              // Check if it has potential headers that might match bill properties
              const potentialHeaders = ['name', 'amount', 'dueday', 'due', 'day', 'method', 'payment', 'bill'];
              const hasRecognizableHeaders = potentialHeaders.some(header => 
                headers.some(h => h.includes(header))
              );
              
              if (hasRecognizableHeaders) {
                // Process each data row
                for (let i = 1; i < lines.length; i++) {
                  const line = lines[i].trim();
                  if (!line) continue; // Skip empty lines
                  
                  const values = line.split(',').map(val => val.trim());
                  
                  // Create object mapping headers to values
                  const billData: any = {};
                  
                  // Initialize defaults
                  billData.name = "Unnamed Bill";
                  billData.amount = "0";
                  billData.dueDay = "1";
                  billData.method = "Unknown";
                  billData.hidden = false;
                  billData.autoDraft = false;
                  billData.isAnnual = false;
                  
                  // Map headers to bill properties
                  headers.forEach((header, index) => {
                    if (index < values.length) {
                      if (header.includes('name') || header === 'bill') {
                        billData.name = values[index];
                      } else if (header.includes('amount') || header.includes('payment') || header.includes('cost') || header.includes('price')) {
                        billData.amount = values[index].replace(/[^0-9.]/g, ''); // Remove non-numeric characters
                      } else if (header.includes('dueday') || header.includes('due day') || header === 'day' || header === 'due') {
                        billData.dueDay = values[index].replace(/[^0-9]/g, ''); // Remove non-numeric characters
                      } else if (header.includes('method') || header.includes('payment method') || header.includes('type')) {
                        billData.method = values[index];
                      } else if (header.includes('auto') || header.includes('draft')) {
                        billData.autoDraft = values[index].toLowerCase() === 'true' || values[index] === '1';
                      } else if (header.includes('hidden') || header.includes('hide')) {
                        billData.hidden = values[index].toLowerCase() === 'true' || values[index] === '1';
                      } else if (header.includes('annual') || header.includes('yearly')) {
                        billData.isAnnual = values[index].toLowerCase() === 'true' || values[index] === '1';
                      }
                    }
                  });
                  
                  billsToImport.push(billData);
                }
              }
            }
          } catch (e) {
            // Failed to process as CSV, move on
          }
        }
        
        // If we couldn't parse the file in any recognized format, but it contains number-like patterns
        // Try to extract potential bills from unstructured data
        if (billsToImport.length === 0) {
          try {
            // Look for common patterns like "$50", "$100.00", "due on 15th", etc.
            const amountMatches = fileContent.match(/\$\s*\d+(\.\d{1,2})?|\d+(\.\d{1,2})?\s*(dollars|USD)/g);
            const dateMatches = fileContent.match(/due\s*(on|by)?\s*(\d{1,2})(st|nd|rd|th)?|day\s*(\d{1,2})/gi);
            const nameMatches = fileContent.match(/[A-Z][a-zA-Z0-9\s]+(?=(bill|payment|subscription|service))/g);
            
            if ((amountMatches && amountMatches.length > 0) || 
                (dateMatches && dateMatches.length > 0) || 
                (nameMatches && nameMatches.length > 0)) {
              
              // Create bills from the matches
              const count = Math.max(
                amountMatches ? amountMatches.length : 0,
                dateMatches ? dateMatches.length : 0,
                nameMatches ? nameMatches.length : 0
              );
              
              for (let i = 0; i < count; i++) {
                const billData: any = {
                  name: nameMatches && i < nameMatches.length ? 
                        nameMatches[i].trim() : `Bill from Import ${i+1}`,
                  amount: amountMatches && i < amountMatches.length ? 
                          amountMatches[i].replace(/[^0-9.]/g, '') : "0",
                  dueDay: dateMatches && i < dateMatches.length ? 
                          dateMatches[i].replace(/[^0-9]/g, '') || "1" : "1",
                  method: "Extracted from file",
                  hidden: false,
                  autoDraft: false,
                  isAnnual: false
                };
                
                // Ensure dueDay is valid
                const dueDay = parseInt(billData.dueDay);
                if (isNaN(dueDay) || dueDay < 1 || dueDay > 31) {
                  billData.dueDay = "1";
                }
                
                billsToImport.push(billData);
              }
            }
          } catch (e) {
            // Failed to extract patterns
          }
        }
        
        // If we still couldn't extract anything meaningful from the file
        if (billsToImport.length === 0) {
          // Create a single "placeholder" bill based on the filename
          const fileName = req.file.originalname.split('.')[0];
          billsToImport.push({
            name: fileName || "Imported Bill",
            amount: "0",
            dueDay: "1",
            method: "Imported from file",
            hidden: false,
            autoDraft: false,
            isAnnual: false
          });
        }
      }
      
      // Validate and save each bill
      const importedBills = [];
      const errors = [];
      
      for (const billData of billsToImport) {
        try {
          // Make sure we have the required fields
          if (!billData.name || !billData.amount || !billData.dueDay || !billData.method) {
            errors.push(`Bill "${billData.name || 'unknown'}" is missing required fields`);
            continue;
          }
          
          // Ensure dueDay is a string
          if (typeof billData.dueDay === 'number') {
            billData.dueDay = billData.dueDay.toString();
          }
          
          // Validate data against schema
          const validatedData = insertBillSchema.parse(billData);
          const bill = await storage.createBill({ ...validatedData, userId });
          importedBills.push(bill);
        } catch (error) {
          errors.push(`Error importing bill "${billData.name || 'unknown'}": ${error}`);
        }
      }
      
      // Return success with stats
      res.status(200).json({
        success: true,
        imported: importedBills.length,
        failed: errors.length,
        errors: errors,
        bills: importedBills
      });
      
    } catch (error) {
      console.error("Error importing bills:", error);
      res.status(500).json({ error: "Failed to import bills" });
    }
  });

  // Settings endpoints
  app.get("/api/settings", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      try {
        const settings = await storage.getSettingsByUserId(userId);
        res.json(settings || {
          paymentStrategy: "Proactive",
          payFrequency: "Bi-Weekly",
          lastPayDate: new Date().toISOString().substring(0, 10),
          billingCushion: "2",
          resetDate: 1,
          autoResetEnabled: true,
          userId
        });
      } catch (innerError) {
        console.error("Error fetching settings:", innerError);
        // Return default settings if there's a database error
        res.json({
          paymentStrategy: "Proactive",
          payFrequency: "Bi-Weekly",
          lastPayDate: new Date().toISOString().substring(0, 10),
          billingCushion: "2",
          resetDate: 1,
          autoResetEnabled: true,
          userId
        });
      }
    } catch (error) {
      console.error("Error in settings endpoint:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.post("/api/settings", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      console.log('Settings data from client:', req.body);
      
      // Use the imported pool from db.ts - no need to create a new one
      const existingSettings = await pool.query(`
        SELECT * FROM settings WHERE "userId" = $1 LIMIT 1
      `, [userId]);
      
      let result;
      
      if (existingSettings.rows.length > 0) {
        // Update existing settings
        const settingsId = existingSettings.rows[0].id;
        
        // Build the update query with the exact column names from the database (verified with SQL query)
        result = await pool.query(`
          UPDATE settings
          SET 
            "paymentStrategy" = $1,
            "payFrequency" = $2,
            "lastPayDate" = $3,
            "billingCushion" = $4,
            resetdate = $5,
            autoresetenabled = $6
          WHERE id = $7
          RETURNING *
        `, [
          req.body.paymentStrategy,
          req.body.payFrequency,
          req.body.lastPayDate,
          req.body.billingCushion,
          req.body.resetDate,
          req.body.autoResetEnabled,
          settingsId
        ]);
      } else {
        // Insert new settings (using verified column names)
        result = await pool.query(`
          INSERT INTO settings ("userId", "paymentStrategy", "payFrequency", "lastPayDate", "billingCushion", resetdate, autoresetenabled)
          VALUES ($1, $2, $3, $4, $5, $6, $7)
          RETURNING *
        `, [
          userId,
          req.body.paymentStrategy,
          req.body.payFrequency,
          req.body.lastPayDate,
          req.body.billingCushion,
          req.body.resetDate,
          req.body.autoResetEnabled
        ]);
      }
      
      const updatedSettings = result.rows[0];
      
      // Map database row to our expected format
      const settingsResponse = {
        id: updatedSettings.id,
        paymentStrategy: updatedSettings.paymentStrategy,
        payFrequency: updatedSettings.payFrequency,
        lastPayDate: updatedSettings.lastPayDate,
        billingCushion: updatedSettings.billingCushion,
        resetDate: updatedSettings.resetdate,
        autoResetEnabled: updatedSettings.autoresetenabled,
        userId: updatedSettings.userId
      };
      
      res.status(201).json(settingsResponse);
    } catch (error) {
      console.error('Settings error:', error);
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // Stock endpoints
  app.get("/api/stocks", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const stocks = await stockService.getStocks(userId);
      res.json(stocks);
    } catch (error) {
      console.error("Error fetching stocks:", error);
      res.status(500).json({ error: "Failed to fetch stocks" });
    }
  });

  app.post("/api/stocks/add", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const { symbol } = req.body;
      
      if (!symbol) {
        return res.status(400).json({ error: "Stock symbol is required" });
      }
      
      const newStock = await stockService.addStock(userId, symbol);
      
      if (!newStock) {
        return res.status(404).json({ error: "Stock not found" });
      }
      
      res.status(201).json(newStock);
    } catch (error) {
      console.error("Error adding stock:", error);
      res.status(500).json({ error: "Failed to add stock" });
    }
  });

  app.post("/api/stocks/remove/:id", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const stockId = parseInt(req.params.id);
      
      if (isNaN(stockId)) {
        return res.status(400).json({ error: "Invalid stock ID" });
      }
      
      const success = await stockService.removeStock(userId, stockId);
      
      if (!success) {
        return res.status(404).json({ error: "Stock not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error removing stock:", error);
      res.status(500).json({ error: "Failed to remove stock" });
    }
  });

  app.post("/api/stocks/update", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const updatedStocks = await stockService.updateAllStocks(userId);
      
      res.status(200).json(updatedStocks);
    } catch (error) {
      console.error("Error updating stocks:", error);
      res.status(500).json({ error: "Failed to update stocks" });
    }
  });

  app.get("/api/stocks/search", isAuthenticated, async (req, res) => {
    try {
      const query = req.query.query as string || "";
      const results = await stockService.searchStocks(query);
      
      res.status(200).json(results);
    } catch (error) {
      console.error("Error searching stocks:", error);
      res.status(500).json({ error: "Failed to search stocks" });
    }
  });
  
  // Market status endpoint - used to determine if markets are open
  app.get("/api/stocks/market-status", isAuthenticated, async (req, res) => {
    try {
      const status = await stockService.getMarketStatus();
      res.status(200).json(status);
    } catch (error) {
      console.error("Error checking market status:", error);
      res.status(500).json({ error: "Failed to check market status" });
    }
  });

  app.put("/api/stocks/visibility", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const { hidden } = req.body;
      
      if (typeof hidden !== 'boolean') {
        return res.status(400).json({ error: "Invalid visibility value" });
      }
      
      await stockService.setStocksVisibility(userId, hidden);
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error updating stock visibility:", error);
      res.status(500).json({ error: "Failed to update stock visibility" });
    }
  });

  // News API endpoints
  app.get("/api/news", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const news = await newsService.getNews(userId);
      res.json(news);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  app.post("/api/news/refresh", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const refreshedNews = await newsService.refreshUserNews(userId);
      res.status(200).json(refreshedNews);
    } catch (error) {
      console.error("Error refreshing news:", error);
      res.status(500).json({ error: "Failed to refresh news" });
    }
  });

  // Set visibility for all news
  app.put("/api/news/visibility", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const { hidden } = req.body;
      
      if (typeof hidden !== 'boolean') {
        return res.status(400).json({ error: "Hidden parameter must be a boolean" });
      }
      
      await newsService.setNewsVisibility(userId, hidden);
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error setting news visibility:", error);
      res.status(500).json({ error: "Failed to update news visibility" });
    }
  });

  // User profile endpoints
  app.get("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Return only profile-related fields, not sensitive data
      const profile = {
        id: user.id,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        phoneticLastName: user.phoneticLastName,
        email: user.email,
        title: user.title,
        isAdmin: user.isAdmin,
        autoLogout: user.autoLogout,
        inactivityTimeout: user.inactivityTimeout
      };
      
      res.status(200).json(profile);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ error: "Failed to fetch user profile" });
    }
  });
  
  app.put("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const updates = req.body;
      
      // Debug the incoming profile updates
      console.log("Received profile update request with data:", updates);
      
      // Filter out unwanted fields for security
      const allowedFields = ['firstName', 'lastName', 'phoneticLastName', 'email', 'title', 'autoLogout', 'inactivityTimeout'];
      const filteredUpdates: Record<string, any> = {};
      
      for (const [key, value] of Object.entries(updates)) {
        if (allowedFields.includes(key)) {
          filteredUpdates[key] = value;
        }
      }
      
      console.log("Filtered updates to apply:", filteredUpdates);
      
      // Get the current user to make sure it exists
      const currentUser = await storage.getUser(userId);
      
      if (!currentUser) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Apply the updates to the user record
      await storage.updateUser(userId, filteredUpdates);
      
      // Fetch the updated user to ensure we have the latest data
      const updatedUser = await storage.getUser(userId);
      
      if (!updatedUser) {
        return res.status(404).json({ error: "User not found after update" });
      }
      
      // Return only profile-related fields from the updated user
      const profile = {
        id: updatedUser.id,
        username: updatedUser.username,
        firstName: updatedUser.firstName,
        lastName: updatedUser.lastName,
        phoneticLastName: updatedUser.phoneticLastName,
        email: updatedUser.email,
        title: updatedUser.title,
        isAdmin: updatedUser.isAdmin,
        autoLogout: updatedUser.autoLogout,
        inactivityTimeout: updatedUser.inactivityTimeout
      };
      
      console.log("Returning updated profile:", profile);
      res.status(200).json(profile);
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ error: "Failed to update user profile" });
    }
  });
  
  app.put("/api/profile/activity", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Update the user's last active timestamp
      await storage.updateUser(userId, { lastActive: new Date() });
      
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error updating user activity:", error);
      res.status(500).json({ error: "Failed to update user activity" });
    }
  });

  // Suggestions endpoints
  app.get("/api/suggestions", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // If admin, get all suggestions; otherwise, get only the user's suggestions
      const suggestions = req.user!.isAdmin 
        ? await storage.getAllSuggestions()
        : await storage.getSuggestionsByUserId(userId);
      
      res.status(200).json(suggestions);
    } catch (error) {
      console.error("Error fetching suggestions:", error);
      res.status(500).json({ error: "Failed to fetch suggestions" });
    }
  });
  
  app.post("/api/suggestions", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const validatedData = insertSuggestionSchema.parse(req.body);
      
      const suggestion = await storage.createSuggestion({
        ...validatedData,
        userId
      });
      
      res.status(201).json(suggestion);
    } catch (error) {
      console.error("Error creating suggestion:", error);
      res.status(400).json({ error: "Invalid suggestion data" });
    }
  });
  
  app.put("/api/suggestions/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      // Make sure id is valid
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid suggestion ID" });
      }
      
      // Only allow certain fields to be updated
      const allowedFields = ['status', 'resolved', 'adminResponse'];
      const filteredUpdates: Record<string, any> = {};
      
      for (const [key, value] of Object.entries(updates)) {
        if (allowedFields.includes(key)) {
          filteredUpdates[key] = value;
        }
      }
      
      const updatedSuggestion = await storage.updateSuggestion(id, filteredUpdates);
      
      if (!updatedSuggestion) {
        return res.status(404).json({ error: "Suggestion not found" });
      }
      
      res.status(200).json(updatedSuggestion);
    } catch (error) {
      console.error("Error updating suggestion:", error);
      res.status(500).json({ error: "Failed to update suggestion" });
    }
  });
  
  app.delete("/api/suggestions/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const userId = req.user!.id;
      
      // Make sure id is valid
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid suggestion ID" });
      }
      
      // Get the suggestion to check ownership
      const suggestions = await storage.getSuggestionsByUserId(userId);
      const suggestionToDelete = suggestions.find(s => s.id === id);
      
      // Admin can delete any suggestion; regular user can only delete their own
      if (!req.user!.isAdmin && !suggestionToDelete) {
        return res.status(403).json({ error: "Access denied. You can only delete your own suggestions." });
      }
      
      await storage.deleteSuggestion(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting suggestion:", error);
      res.status(500).json({ error: "Failed to delete suggestion" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
