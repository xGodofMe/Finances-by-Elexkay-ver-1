import { bills, settings, stocks, news, suggestions, type Bill, type InsertBill, type Settings, type InsertSettings, users, type User, type InsertUser, type Stock, type InsertStock, type News, type InsertNews, type Suggestion, type InsertSuggestion } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<void>;
  getAllUsers(): Promise<User[]>;
  
  // Bill methods
  getBill(id: number): Promise<Bill | undefined>;
  getBillsByUserId(userId: number): Promise<Bill[]>;
  createBill(bill: InsertBill & { userId: number }): Promise<Bill>;
  updateBill(id: number, updates: Partial<InsertBill & { userId: number }>): Promise<Bill | undefined>;
  deleteBill(id: number): Promise<void>;
  
  // Settings methods
  getSettingsByUserId(userId: number): Promise<Settings | undefined>;
  updateOrCreateSettings(userId: number, settings: InsertSettings): Promise<Settings>;
  
  // Stock methods
  getStock(id: number): Promise<Stock | undefined>;
  getStocksByUserId(userId: number): Promise<Stock[]>;
  createStock(stock: InsertStock): Promise<Stock>;
  updateStock(id: number, updates: Partial<InsertStock>): Promise<Stock | undefined>;
  deleteStock(id: number): Promise<void>;
  
  // News methods
  getNewsByUserId(userId: number): Promise<News[]>;
  createNews(newsItem: InsertNews & { userId: number }): Promise<News>;
  deleteNews(id: number): Promise<void>;
  
  // Suggestion methods
  getSuggestionsByUserId(userId: number): Promise<Suggestion[]>;
  getAllSuggestions(): Promise<Suggestion[]>;
  createSuggestion(suggestion: InsertSuggestion & { userId: number }): Promise<Suggestion>;
  updateSuggestion(id: number, updates: Partial<Suggestion>): Promise<Suggestion | undefined>;
  deleteSuggestion(id: number): Promise<void>;
  
  // Session store for authentication
  sessionStore: session.Store;
}

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }
  
  async getUser(id: number): Promise<User | undefined> {
    try {
      // Use a direct SQL query with explicit column names to avoid mapping issues
      const query = `
        SELECT id, username, password, "isAdmin", 
               first_name, last_name, phonetic_last_name, 
               email, title, auto_logout, inactivity_timeout, last_active
        FROM users 
        WHERE id = $1 
        LIMIT 1
      `;
      const result = await pool.query(query, [id]);
      
      // Convert to user object
      if (result.rows.length === 0) return undefined;
      
      const user = result.rows[0];
      
      // Return undefined if no user found
      if (!user) return undefined;
      
      // Convert raw database result to properly typed User object
      const rawUser = user as any; // Use any to access database field names directly
      
      return {
        id: user.id,
        username: user.username, 
        password: user.password,
        isAdmin: Boolean(rawUser.isAdmin ?? false), // Column is camelCase in DB
        firstName: rawUser.first_name ?? null,
        lastName: rawUser.last_name ?? null,
        phoneticLastName: rawUser.phonetic_last_name ?? null,
        email: rawUser.email ?? null,
        title: rawUser.title ?? null,
        autoLogout: Boolean(rawUser.auto_logout ?? true),
        inactivityTimeout: rawUser.inactivity_timeout ?? 15,
        lastActive: rawUser.last_active ?? null
      } as User;
    } catch (error) {
      console.error("Error in getUser:", error);
      
      // Try a more basic query if the first attempt fails
      try {
        // Use direct SQL as a last resort fallback with only basic fields
        const fallbackQuery = `
          SELECT id, username, password, "isAdmin"
          FROM users 
          WHERE id = $1 
          LIMIT 1
        `;
        const fallbackResult = await pool.query(fallbackQuery, [id]);
        
        if (fallbackResult.rows.length === 0) return undefined;
        
        const user = fallbackResult.rows[0];
        
        // Basic user with just essential fields
        const basicUser = {
          id: user.id,
          username: user.username,
          password: user.password,
          isAdmin: Boolean(user.isAdmin ?? false), // Only try isAdmin
        };
          
        if (!basicUser) return undefined;
        
        // Add missing fields with default values
        return {
          ...basicUser,
          firstName: null,
          lastName: null,
          phoneticLastName: null,
          email: null,
          title: null,
          autoLogout: true,
          inactivityTimeout: 15,
          lastActive: null
        } as User;
      } catch (secondError) {
        console.error("Critical error in getUser fallback:", secondError);
        return undefined;
      }
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      // Use an explicit SQL query with all column names to avoid mapping issues
      const query = `
        SELECT id, username, password, "isAdmin", 
               first_name, last_name, phonetic_last_name, 
               email, title, auto_logout, inactivity_timeout, last_active
        FROM users 
        WHERE username = $1 
        LIMIT 1
      `;
      const result = await pool.query(query, [username]);
      
      // Return undefined if no user found
      if (result.rows.length === 0) return undefined;
      
      const user = result.rows[0];
      
      // Format as User type with defaults for missing fields, using the exact column names from the database
      return {
        id: user.id,
        username: user.username,
        password: user.password,
        isAdmin: Boolean(user.isAdmin ?? false), // Column is actually named isAdmin in the database
        firstName: user.first_name ?? null,
        lastName: user.last_name ?? null,
        phoneticLastName: user.phonetic_last_name ?? null,
        email: user.email ?? null,
        title: user.title ?? null,
        autoLogout: Boolean(user.auto_logout ?? true),
        inactivityTimeout: user.inactivity_timeout ?? 15,
        lastActive: user.last_active ?? null
      } as User;
    } catch (error) {
      console.error("Error in getUserByUsername:", error);
      
      // Try a more basic query if the first attempt fails
      try {
        // Use direct SQL as a last resort fallback with only basic fields
        const fallbackQuery = `
          SELECT id, username, password, "isAdmin"
          FROM users 
          WHERE username = $1 
          LIMIT 1
        `;
        const fallbackResult = await pool.query(fallbackQuery, [username]);
        
        if (fallbackResult.rows.length === 0) return undefined;
        
        const user = fallbackResult.rows[0];
        
        // Basic user with just essential fields
        const basicUser = {
          id: user.id,
          username: user.username,
          password: user.password,
          isAdmin: Boolean(user.isAdmin ?? false), // Only try isAdmin
        };
          
        // Add missing fields with default values
        return {
          ...basicUser,
          firstName: null,
          lastName: null,
          phoneticLastName: null,
          email: null,
          title: null,
          autoLogout: true,
          inactivityTimeout: 15,
          lastActive: null
        } as User;
      } catch (secondError) {
        console.error("Critical error in getUserByUsername fallback:", secondError);
        return undefined;
      }
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    try {
      // Need to convert camelCase JavaScript properties to snake_case database columns
      const dbUpdates: Record<string, any> = {};
      
      // Only include properties that are actually in the updates object
      if (updates.username !== undefined) dbUpdates.username = updates.username;
      if (updates.password !== undefined) dbUpdates.password = updates.password;
      if (updates.isAdmin !== undefined) dbUpdates.isAdmin = updates.isAdmin; // Correct column name
      if (updates.firstName !== undefined) dbUpdates.first_name = updates.firstName;
      if (updates.lastName !== undefined) dbUpdates.last_name = updates.lastName;
      if (updates.phoneticLastName !== undefined) dbUpdates.phonetic_last_name = updates.phoneticLastName;
      if (updates.email !== undefined) dbUpdates.email = updates.email;
      if (updates.title !== undefined) dbUpdates.title = updates.title;
      if (updates.autoLogout !== undefined) dbUpdates.auto_logout = updates.autoLogout;
      if (updates.inactivityTimeout !== undefined) dbUpdates.inactivity_timeout = updates.inactivityTimeout;
      if (updates.lastActive !== undefined) dbUpdates.last_active = updates.lastActive;
      
      console.log("Updating user with:", dbUpdates);
      
      // Direct SQL to handle column names more explicitly
      const setClauses = Object.entries(dbUpdates).map(([col, _], i) => `${col} = $${i + 2}`);
      const updateValues = [id, ...Object.values(dbUpdates)];
      
      const updateQuery = `
        UPDATE users
        SET ${setClauses.join(', ')}
        WHERE id = $1
        RETURNING *
      `;
      
      console.log("Update user query:", updateQuery, "with values:", updateValues);
      
      const result = await pool.query(updateQuery, updateValues);
      const user = result.rows[0];
      
      // Return undefined if update failed
      if (!user) return undefined;
      
      // Map database snake_case column names to JavaScript camelCase properties
      return {
        id: user.id,
        username: user.username,
        password: user.password,
        isAdmin: Boolean(user.isAdmin ?? false), // Column is isAdmin
        firstName: user.first_name ?? null,
        lastName: user.last_name ?? null,
        phoneticLastName: user.phonetic_last_name ?? null,
        email: user.email ?? null,
        title: user.title ?? null,
        autoLogout: Boolean(user.auto_logout ?? true),
        inactivityTimeout: user.inactivity_timeout ?? 15,
        lastActive: user.last_active ?? null
      } as User;
    } catch (error) {
      console.error("Error updating user:", error);
      
      // If there's an error, try updating just the basic fields
      try {
        const safeUpdates: Record<string, any> = {};
        // Only include core properties with correct database column names
        if (updates.username !== undefined) safeUpdates.username = updates.username;
        if (updates.password !== undefined) safeUpdates.password = updates.password;
        if (updates.isAdmin !== undefined) safeUpdates.isAdmin = updates.isAdmin; // Column name is isAdmin
        
        console.log("Fallback update with safe fields:", safeUpdates);
        
        const [basicUser] = await db
          .update(users)
          .set(safeUpdates)
          .where(eq(users.id, id))
          .returning();
        
        if (!basicUser) return undefined;
        
        return {
          ...basicUser,
          firstName: updates.firstName ?? null,
          lastName: updates.lastName ?? null,
          phoneticLastName: updates.phoneticLastName ?? null,
          email: updates.email ?? null,
          title: updates.title ?? null,
          autoLogout: updates.autoLogout ?? true,
          inactivityTimeout: updates.inactivityTimeout ?? 15,
          lastActive: null
        } as User;
      } catch (secondError) {
        console.error("Critical error in updateUser fallback:", secondError);
        return undefined;
      }
    }
  }
  
  async deleteUser(id: number): Promise<void> {
    // Delete all related data for this user first (to maintain data integrity)
    await db.delete(bills).where(eq(bills.userId, id));
    await db.delete(settings).where(eq(settings.userId, id));
    await db.delete(stocks).where(eq(stocks.userId, id));
    await db.delete(news).where(eq(news.userId, id));
    await db.delete(suggestions).where(eq(suggestions.userId, id));
    
    // Finally, delete the user
    await db.delete(users).where(eq(users.id, id));
  }
  
  async getAllUsers(): Promise<User[]> {
    try {
      // Direct SQL approach with explicit column names to avoid mapping issues
      const query = `
        SELECT id, username, password, "isAdmin", 
               first_name, last_name, phonetic_last_name, 
               email, title, auto_logout, inactivity_timeout, last_active
        FROM users
      `;
      const result = await pool.query(query);
      
      // Format and map database snake_case column names to JavaScript camelCase properties
      return result.rows.map(user => ({
        id: user.id,
        username: user.username,
        password: user.password,
        isAdmin: Boolean(user.isAdmin ?? false), // Column is isAdmin, not is_admin
        firstName: user.first_name ?? null,
        lastName: user.last_name ?? null,
        phoneticLastName: user.phonetic_last_name ?? null,
        email: user.email ?? null,
        title: user.title ?? null,
        autoLogout: Boolean(user.auto_logout ?? true),
        inactivityTimeout: user.inactivity_timeout ?? 15,
        lastActive: user.last_active ?? null
      })) as User[];
    } catch (error) {
      console.error("Error in getAllUsers:", error);
      
      // Try a more basic query if columns don't exist
      try {
        // When using Drizzle, we need to be careful about the column name mapping
        const basicUsers = await db
          .select()
          .from(users)
          .then(rows => rows.map(user => {
            // Use any to bypass TypeScript checks for raw database results
            const rawUser = user as any;
            return {
              id: user.id,
              username: user.username,
              password: user.password,
              isAdmin: Boolean(user.isAdmin || (rawUser.is_admin ?? false)), // Handle both field name variations
            };
          }));
          
        // Add missing fields with default values
        return basicUsers.map(user => ({
          ...user,
          firstName: null,
          lastName: null,
          phoneticLastName: null,
          email: null,
          title: null,
          autoLogout: true,
          inactivityTimeout: 15,
          lastActive: null
        })) as User[];
      } catch (secondError) {
        console.error("Critical error in getAllUsers fallback:", secondError);
        return [];
      }
    }
  }

  async getBill(id: number): Promise<Bill | undefined> {
    const [bill] = await db.select().from(bills).where(eq(bills.id, id));
    return bill || undefined;
  }

  async getBillsByUserId(userId: number): Promise<Bill[]> {
    return db.select().from(bills).where(eq(bills.userId, userId));
  }

  async createBill(data: InsertBill & { userId: number }): Promise<Bill> {
    const [bill] = await db
      .insert(bills)
      .values(data)
      .returning();
    return bill;
  }

  async updateBill(id: number, updates: Partial<InsertBill & { userId: number }>): Promise<Bill | undefined> {
    const [bill] = await db
      .update(bills)
      .set(updates)
      .where(eq(bills.id, id))
      .returning();
    return bill || undefined;
  }

  async deleteBill(id: number): Promise<void> {
    await db.delete(bills).where(eq(bills.id, id));
  }

  async getSettingsByUserId(userId: number): Promise<Settings | undefined> {
    try {
      // Direct SQL approach - using the JavaScript property name with camelCase
      const query = `SELECT * FROM settings WHERE "userId" = $1 LIMIT 1`;
      const result = await pool.query(query, [userId]);
      
      if (result.rows.length === 0) {
        return undefined;
      }
      
      const setting = result.rows[0];
      
      // Convert database columns to JavaScript properties using the correct column names
      return {
        id: setting.id,
        paymentStrategy: setting.paymentStrategy ?? 'Proactive',
        payFrequency: setting.payFrequency ?? 'Bi-Weekly',
        lastPayDate: setting.lastPayDate,
        billingCushion: setting.billingCushion ?? '2',
        resetDate: setting.resetdate ?? 1,
        autoResetEnabled: setting.autoresetenabled ?? true,
        userId: setting.userId
      } as Settings;
    } catch (error) {
      console.error("Error in getSettingsByUserId:", error, "UserId:", userId);
      return undefined;
    }
  }

  async updateOrCreateSettings(userId: number, data: InsertSettings): Promise<Settings> {
    const existingSettings = await this.getSettingsByUserId(userId);
    
    // Database column names are in camelCase (confirmed with SQL query)
    const dbData: Record<string, any> = {};
    
    // Only include properties that are actually in the data object - using correct column names
    if (data.paymentStrategy !== undefined) dbData.paymentStrategy = data.paymentStrategy;
    if (data.payFrequency !== undefined) dbData.payFrequency = data.payFrequency;
    if (data.lastPayDate !== undefined) dbData.lastPayDate = data.lastPayDate;
    if (data.billingCushion !== undefined) dbData.billingCushion = data.billingCushion;
    if (data.resetDate !== undefined) dbData.resetdate = data.resetDate; // This one is lowercase
    if (data.autoResetEnabled !== undefined) dbData.autoresetenabled = data.autoResetEnabled; // This one is all lowercase
    
    console.log("Settings data for database:", dbData, "UserId:", userId);
    
    if (existingSettings) {
      // Direct SQL for update to handle column names properly
      const setClauses = Object.entries(dbData).map(([col, _], i) => `${col} = $${i + 2}`);
      const updateValues = [existingSettings.id, ...Object.values(dbData)];
      
      const updateQuery = `
        UPDATE settings
        SET ${setClauses.join(', ')}
        WHERE id = $1
        RETURNING *
      `;
      
      console.log("Update query:", updateQuery, "with values:", updateValues);
      
      const updateResult = await pool.query(updateQuery, updateValues);
      const updatedRow = updateResult.rows[0];
      
      // Convert the raw database row to the Settings type with the correct column names
      const updatedSettings: Settings = {
        id: updatedRow.id,
        paymentStrategy: updatedRow.paymentStrategy,
        payFrequency: updatedRow.payFrequency,
        lastPayDate: updatedRow.lastPayDate,
        billingCushion: updatedRow.billingCushion,
        resetDate: updatedRow.resetdate,
        autoResetEnabled: updatedRow.autoresetenabled,
        userId: updatedRow.userId
      };
      
      return updatedSettings;
    }
    
    // Fallback to direct SQL to avoid type issues with mismatched column names
    // Create query parts for columns and values - using the correct column name with quotes
    const columns = ['"userId"', ...Object.keys(dbData)];
    const values = [userId, ...Object.values(dbData)];
    const placeholders = values.map((_, i) => `$${i + 1}`);
    
    // Build the SQL query manually
    const query = `
      INSERT INTO settings (${columns.join(', ')})
      VALUES (${placeholders.join(', ')})
      RETURNING *
    `;
    
    const result = await pool.query(query, values);
    const row = result.rows[0];
    
    // Convert the raw database row to the Settings type with correct column names
    const newSettings: Settings = {
      id: row.id,
      paymentStrategy: row.paymentStrategy,
      payFrequency: row.payFrequency,
      lastPayDate: row.lastPayDate,
      billingCushion: row.billingCushion,
      resetDate: row.resetdate,
      autoResetEnabled: row.autoresetenabled,
      userId: row.userId
    };
    
    return newSettings;
  }

  // Stock methods
  async getStock(id: number): Promise<Stock | undefined> {
    const [stock] = await db.select().from(stocks).where(eq(stocks.id, id));
    return stock || undefined;
  }

  async getStocksByUserId(userId: number): Promise<Stock[]> {
    return db.select().from(stocks).where(eq(stocks.userId, userId));
  }

  async createStock(data: InsertStock & { userId: number }): Promise<Stock> {
    const [stock] = await db
      .insert(stocks)
      .values(data)
      .returning();
    return stock;
  }

  async updateStock(id: number, updates: Partial<InsertStock>): Promise<Stock | undefined> {
    const [stock] = await db
      .update(stocks)
      .set(updates)
      .where(eq(stocks.id, id))
      .returning();
    return stock || undefined;
  }

  async deleteStock(id: number): Promise<void> {
    await db.delete(stocks).where(eq(stocks.id, id));
  }

  // News methods
  async getNewsByUserId(userId: number): Promise<News[]> {
    return db.select().from(news).where(eq(news.userId, userId));
  }

  async createNews(data: InsertNews & { userId: number }): Promise<News> {
    const [newsItem] = await db
      .insert(news)
      .values(data)
      .returning();
    return newsItem;
  }

  async deleteNews(id: number): Promise<void> {
    await db.delete(news).where(eq(news.id, id));
  }

  // Suggestion methods
  async getSuggestionsByUserId(userId: number): Promise<Suggestion[]> {
    try {
      return await db.select().from(suggestions).where(eq(suggestions.userId, userId));
    } catch (error) {
      console.error("Error getting suggestions by user ID:", error);
      // Return empty array if the table doesn't exist or has a schema mismatch
      return [];
    }
  }

  async getAllSuggestions(): Promise<Suggestion[]> {
    try {
      return await db.select().from(suggestions);
    } catch (error) {
      console.error("Error getting all suggestions:", error);
      // Return empty array if the table doesn't exist or has a schema mismatch
      return [];
    }
  }

  async createSuggestion(data: InsertSuggestion & { userId: number }): Promise<Suggestion> {
    const [suggestion] = await db
      .insert(suggestions)
      .values(data)
      .returning();
    return suggestion;
  }

  async updateSuggestion(id: number, updates: Partial<Suggestion>): Promise<Suggestion | undefined> {
    const [suggestion] = await db
      .update(suggestions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(suggestions.id, id))
      .returning();
    return suggestion || undefined;
  }

  async deleteSuggestion(id: number): Promise<void> {
    await db.delete(suggestions).where(eq(suggestions.id, id));
  }
}

export const storage = new DatabaseStorage();