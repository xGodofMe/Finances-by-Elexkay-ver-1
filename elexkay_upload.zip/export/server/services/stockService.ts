import yahooFinance from 'yahoo-finance2';
import { storage } from '../storage';
import { InsertStock, Stock } from '@shared/schema';

interface StockQuote {
  symbol: string;
  companyName: string;
  price: string;
  change: string;
  changePercent: string;
}

export class StockService {
  async getStocks(userId: number): Promise<Stock[]> {
    try {
      // Fetch stocks from database for this user
      const stocks = await storage.getStocksByUserId(userId);
      return stocks || [];
    } catch (error) {
      console.error('Error fetching stocks:', error);
      throw new Error('Failed to fetch stocks');
    }
  }

  async setStocksVisibility(userId: number, hidden: boolean): Promise<void> {
    try {
      const stocks = await this.getStocks(userId);
      // Update all stocks' hidden property
      await Promise.all(
        stocks.map(stock => 
          storage.updateStock(stock.id, { hidden })
        )
      );
    } catch (error) {
      console.error('Error updating stocks visibility:', error);
      throw new Error('Failed to update stocks visibility');
    }
  }

  async addStock(userId: number, symbol: string): Promise<Stock | null> {
    try {
      // First, check if this stock already exists for the user
      const existingStocks = await this.getStocks(userId);
      const existingStock = existingStocks.find(s => 
        s.symbol.toLowerCase() === symbol.toLowerCase()
      );
      
      if (existingStock) {
        // If it exists but isn't being watched, update it
        if (!existingStock.isWatching) {
          const updatedStock = await storage.updateStock(existingStock.id, { isWatching: true });
          return updatedStock || existingStock; // Return updated or fallback to existing
        }
        return existingStock; // Already being watched
      }
      
      // Get stock data from Yahoo Finance
      const stockData = await this.fetchStockData(symbol);
      if (!stockData) {
        throw new Error(`No data found for symbol ${symbol}`);
      }
      
      // Create new stock with userId included
      const stockWithUserId = {
        symbol,
        companyName: stockData.companyName || "",
        price: stockData.price || "0",
        change: stockData.change || "0",
        changePercent: stockData.changePercent || "0%",
        userId,
        hidden: false,
        isWatching: true
      };
      
      return await storage.createStock(stockWithUserId);
    } catch (error) {
      console.error(`Error adding stock ${symbol}:`, error);
      throw new Error(`Failed to add stock ${symbol}`);
    }
  }

  async removeStock(userId: number, stockId: number): Promise<boolean> {
    try {
      const stock = await storage.getStock(stockId);
      if (!stock || stock.userId !== userId) {
        throw new Error('Stock not found or not authorized');
      }
      
      // Instead of deleting, just set isWatching to false
      const updatedStock = await storage.updateStock(stockId, { isWatching: false });
      return updatedStock !== null;
    } catch (error) {
      console.error(`Error removing stock:`, error);
      throw new Error('Failed to remove stock');
    }
  }

  async updateAllStocks(userId: number): Promise<Stock[]> {
    try {
      const stocks = await this.getStocks(userId);
      
      // Update each stock with latest data
      const updatedStocks = await Promise.all(
        stocks.map(async (stock) => {
          try {
            const newData = await this.fetchStockData(stock.symbol);
            if (newData) {
              // Update the stock data but handle lastUpdated in the database
              const updatedStock = await storage.updateStock(stock.id, {
                price: newData.price,
                change: newData.change,
                changePercent: newData.changePercent
              });
              return updatedStock || stock;
            }
            return stock;
          } catch (e) {
            console.error(`Failed to update stock ${stock.symbol}:`, e);
            return stock; // Keep original if update fails
          }
        })
      );
      
      return updatedStocks.filter(Boolean) as Stock[];
    } catch (error) {
      console.error('Error updating stocks:', error);
      throw new Error('Failed to update stocks');
    }
  }

  async searchStocks(query: string): Promise<StockQuote[]> {
    try {
      // Search for stocks using Yahoo Finance
      const results = await yahooFinance.search(query, { quotesCount: 10, newsCount: 0 });
      
      // Extract only the quotes
      const quotes = results.quotes || [];
      
      // Get detailed data for top results
      const detailedResults = await Promise.all(
        quotes
          .filter(quote => 'symbol' in quote && typeof quote.symbol === 'string')
          .slice(0, 5)
          .map(async quote => {
            try {
              // Use type assertion to access symbol safely
              const symbolValue = (quote as {symbol: string}).symbol;
              return await this.fetchStockData(symbolValue);
            } catch (e) {
              // Safe error logging with type assertion
              const symbolValue = 'symbol' in quote ? String((quote as any).symbol) : 'unknown';
              console.error(`Error fetching details for ${symbolValue}:`, e);
              return null;
            }
          })
      );
      
      return detailedResults.filter(Boolean) as StockQuote[];
    } catch (error) {
      console.error('Error searching stocks:', error);
      throw new Error('Failed to search stocks');
    }
  }

  async getMarketStatus(): Promise<{ isOpen: boolean }> {
    try {
      // Use S&P 500 ETF (SPY) as a reference to check market status
      const quote = await yahooFinance.quote('SPY');
      
      if (!quote) {
        throw new Error('Failed to fetch market data');
      }
      
      // Check if marketState is REGULAR, PRE, or POST
      const marketState = quote.marketState;
      
      // REGULAR means market is open
      const isOpen = marketState === 'REGULAR';
      
      return { isOpen };
    } catch (error) {
      console.error('Error checking market status:', error);
      
      // Default to a time-based check as fallback
      const now = new Date();
      const nyOptions = { timeZone: 'America/New_York' };
      const nyDate = new Date(now.toLocaleString('en-US', nyOptions));
      const day = nyDate.getDay();
      const hours = nyDate.getHours();
      const minutes = nyDate.getMinutes();
      
      // Market is closed on weekends (Saturday = 6, Sunday = 0)
      if (day === 0 || day === 6) {
        return { isOpen: false };
      }
      
      // Market is open from 9:30 AM to 4:00 PM ET on weekdays
      const isOpen = ((hours > 9 || (hours === 9 && minutes >= 30)) && hours < 16);
      
      return { isOpen };
    }
  }

  private async fetchStockData(symbol: string): Promise<StockQuote | null> {
    try {
      // Get the quote data
      const quote = await yahooFinance.quote(symbol);
      
      if (!quote || !quote.regularMarketPrice) {
        return null;
      }
      
      // Format the data
      return {
        symbol: quote.symbol,
        companyName: quote.shortName || quote.longName || quote.symbol,
        price: quote.regularMarketPrice.toFixed(2),
        change: quote.regularMarketChange?.toFixed(2) || '0.00',
        changePercent: quote.regularMarketChangePercent?.toFixed(2) || '0.00'
      };
    } catch (error) {
      console.error(`Error fetching data for ${symbol}:`, error);
      return null;
    }
  }
}

export const stockService = new StockService();