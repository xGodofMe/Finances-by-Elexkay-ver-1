// Credit Bureau API Integration Service
import { creditScores, type CreditScore, type InsertCreditScore } from '@shared/schema';
import { db } from '../db';
import { eq, desc } from 'drizzle-orm';

interface CreditBureauResponse {
  score: number | null;
  error?: string;
}

// Service to handle interactions with credit bureau APIs
export class CreditService {
  
  // Get latest credit scores for a user
  async getLatestCreditScores(userId: number): Promise<CreditScore | null> {
    const scores = await db
      .select()
      .from(creditScores)
      .where(eq(creditScores.userId, userId))
      .orderBy(desc(creditScores.date))
      .limit(1);
    
    return scores.length > 0 ? scores[0] : null;
  }
  
  // Get credit score history for a user
  async getCreditHistory(userId: number): Promise<CreditScore[]> {
    return db
      .select()
      .from(creditScores)
      .where(eq(creditScores.userId, userId))
      .orderBy(desc(creditScores.date));
  }
  
  // Set visibility of credit scores
  async setCreditScoreVisibility(userId: number, hidden: boolean): Promise<void> {
    await db
      .update(creditScores)
      .set({ hidden })
      .where(eq(creditScores.userId, userId));
  }
  
  // Save authentication tokens for credit bureaus
  async saveAuthTokens(userId: number, tokens: {
    experianToken?: string,
    equifaxToken?: string,
    transunionToken?: string
  }): Promise<void> {
    // Get the latest score entry or create a new one
    const latestScore = await this.getLatestCreditScores(userId);
    
    if (latestScore) {
      // Update existing record
      await db
        .update(creditScores)
        .set({
          ...tokens
        })
        .where(eq(creditScores.id, latestScore.id));
    } else {
      // Create new record with tokens only
      await db
        .insert(creditScores)
        .values({
          userId,
          ...tokens
        });
    }
  }
  
  // Fetch and update credit scores from all bureaus
  async updateAllCreditScores(userId: number): Promise<CreditScore | null> {
    const latestScore = await this.getLatestCreditScores(userId);
    
    if (!latestScore) {
      console.error("No credit score record found for user:", userId);
      return null;
    }
    
    // Fetch scores from all three bureaus
    const [experianResponse, equifaxResponse, transunionResponse] = await Promise.all([
      this.fetchExperianScore(latestScore.experianToken || undefined),
      this.fetchEquifaxScore(latestScore.equifaxToken || undefined),
      this.fetchTransunionScore(latestScore.transunionToken || undefined)
    ]);
    
    // Calculate changes since last record
    const experianChange = experianResponse.score !== null && latestScore.experianScore 
      ? experianResponse.score - latestScore.experianScore 
      : 0;
      
    const equifaxChange = equifaxResponse.score !== null && latestScore.equifaxScore 
      ? equifaxResponse.score - latestScore.equifaxScore 
      : 0;
      
    const transunionChange = transunionResponse.score !== null && latestScore.transunionScore 
      ? transunionResponse.score - latestScore.transunionScore 
      : 0;
    
    // Only update scores that came back successfully
    const updateData: Partial<InsertCreditScore> & {
      userId?: number
    } = {
      hidden: latestScore.hidden
    };
    
    if (experianResponse.score !== null) {
      updateData.experianScore = experianResponse.score;
    }
    
    if (equifaxResponse.score !== null) {
      updateData.equifaxScore = equifaxResponse.score;
    }
    
    if (transunionResponse.score !== null) {
      updateData.transunionScore = transunionResponse.score;
    }
    
    // Insert a new record with the updated scores
    const [newScore] = await db
      .insert(creditScores)
      .values({
        userId,
        ...updateData,
        experianToken: latestScore.experianToken,
        equifaxToken: latestScore.equifaxToken,
        transunionToken: latestScore.transunionToken
      })
      .returning();
    
    return newScore;
  }
  
  // Fetch score from Experian API
  private async fetchExperianScore(token?: string): Promise<CreditBureauResponse> {
    if (!token) {
      return { score: null, error: 'No authentication token available' };
    }
    
    try {
      // This would be replaced with actual API call
      // Using placeholder logic for now until we integrate with real API
      console.log("Attempting to fetch Experian score with token");
      return { score: 720 };
    } catch (error) {
      console.error('Error fetching Experian score:', error);
      return { score: null, error: 'Failed to fetch score from Experian' };
    }
  }
  
  // Fetch score from Equifax API
  private async fetchEquifaxScore(token?: string): Promise<CreditBureauResponse> {
    if (!token) {
      return { score: null, error: 'No authentication token available' };
    }
    
    try {
      // This would be replaced with actual API call
      // Using placeholder logic for now until we integrate with real API
      console.log("Attempting to fetch Equifax score with token");
      return { score: 715 };
    } catch (error) {
      console.error('Error fetching Equifax score:', error);
      return { score: null, error: 'Failed to fetch score from Equifax' };
    }
  }
  
  // Fetch score from TransUnion API
  private async fetchTransunionScore(token?: string): Promise<CreditBureauResponse> {
    if (!token) {
      return { score: null, error: 'No authentication token available' };
    }
    
    try {
      // This would be replaced with actual API call
      // Using placeholder logic for now until we integrate with real API
      console.log("Attempting to fetch TransUnion score with token");
      return { score: 730 };
    } catch (error) {
      console.error('Error fetching TransUnion score:', error);
      return { score: null, error: 'Failed to fetch score from TransUnion' };
    }
  }
}

export const creditService = new CreditService();