import { db } from "../db";
import { eq, and } from "drizzle-orm";
import { news, type News, type InsertNews } from "@shared/schema";

interface NewsItem {
  id?: number;
  userId?: number;
  title: string;
  source: string;
  url: string;
  publishedAt?: Date;
  hidden?: boolean;
}

export class NewsService {
  async getNews(userId: number): Promise<News[]> {
    return await db
      .select()
      .from(news)
      .where(and(eq(news.userId, userId)))
      .orderBy(news.publishedAt);
  }

  async addNews(userId: number, newsItems: NewsItem[]): Promise<News[]> {
    const result: News[] = [];
    
    for (const item of newsItems) {
      const [newItem] = await db
        .insert(news)
        .values({
          userId,
          title: item.title,
          source: item.source,
          url: item.url,
          hidden: false
        })
        .returning();

      if (newItem) {
        result.push(newItem);
      }
    }
    
    return result;
  }

  async removeNews(userId: number, newsId: number): Promise<boolean> {
    const deletedNews = await db
      .delete(news)
      .where(and(eq(news.id, newsId), eq(news.userId, userId)))
      .returning();
    
    return deletedNews.length > 0;
  }

  async setNewsVisibility(userId: number, hidden: boolean): Promise<void> {
    await db
      .update(news)
      .set({ hidden })
      .where(eq(news.userId, userId));
  }

  async fetchLatestFinancialNews(): Promise<NewsItem[]> {
    try {
      // Try to fetch from a real API if available
      const newsItems: NewsItem[] = [];
      
      // Fallback news in case API is not available or fails
      const fallbackNews: NewsItem[] = [
        {
          title: "Fed Signals Possible Rate Cut This Year",
          source: "Financial Times",
          url: "https://www.ft.com/content/markets",
        },
        {
          title: "S&P 500 Hits New All-Time High",
          source: "Wall Street Journal",
          url: "https://www.wsj.com/market-data",
        },
        {
          title: "Tech Stocks Rally Amid AI Optimism",
          source: "Bloomberg",
          url: "https://www.bloomberg.com/markets",
        },
        {
          title: "Inflation Numbers Better Than Expected",
          source: "CNBC",
          url: "https://www.cnbc.com/economy/",
        },
        {
          title: "Housing Market Showing Signs of Cooling",
          source: "Reuters",
          url: "https://www.reuters.com/business/finance/",
        },
        {
          title: "Oil Prices Drop on Supply Concerns",
          source: "MarketWatch",
          url: "https://www.marketwatch.com/investing/commodities",
        },
        {
          title: "Dollar Weakens Against Major Currencies",
          source: "Financial Times",
          url: "https://www.ft.com/currencies",
        },
        {
          title: "Retail Sales Surge in Q1 2025",
          source: "CNBC",
          url: "https://www.cnbc.com/retail/",
        },
        {
          title: "Earnings Season Shows Strong Corporate Profits",
          source: "Yahoo Finance",
          url: "https://finance.yahoo.com/earnings/",
        },
        {
          title: "Global Markets Rally on Economic Recovery Signs",
          source: "Bloomberg",
          url: "https://www.bloomberg.com/markets/stocks",
        }
      ];
      
      // For now, use the fallback news
      // In a production environment, we would replace this with a real API call
      return fallbackNews;
    } catch (error) {
      console.error("Error fetching financial news:", error);
      
      // Return minimal fallback data in case of error
      return [
        {
          title: "Markets Continue to Fluctuate in Current Economy",
          source: "Financial News",
          url: "https://www.reuters.com/business/finance/",
        }
      ];
    }
  }

  // Add this function to refresh all news for a user
  async refreshUserNews(userId: number): Promise<News[]> {
    try {
      // Fetch latest news
      const latestNews = await this.fetchLatestFinancialNews();
      
      // First, delete all existing news items for this user
      await db
        .delete(news)
        .where(eq(news.userId, userId));
      
      // Then add the new ones
      return await this.addNews(userId, latestNews);
    } catch (error) {
      console.error("Error refreshing news:", error);
      return [];
    }
  }
}

export const newsService = new NewsService();